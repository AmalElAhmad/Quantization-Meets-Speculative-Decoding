# Quantization Meets Speculative Decoding: Speed, Memory, Energy and Output Quality of Small Language Models on a T4 GPU

**Research question.** How do quantization level (FP16, INT8, and INT4) and decoding method (standard versus speculative
decoding) interact to affect inference speed, memory consumption, energy efficiency, and output quality in small language
models under different workload conditions, and how does quantization level affect token acceptance under speculative
decoding?

This repository contains the raw data, analysis code, results and notebooks of the study. The models are
**Qwen2.5-1.5B-Instruct (target)** and **Qwen2.5-0.5B-Instruct (draft)**, run on an NVIDIA Tesla T4 with FP16, INT8
(LLM.int8) and INT4 (NF4) weights from bitsandbytes, using Hugging Face assisted generation for speculative decoding.

Authors: Aziza Sarhan Al Sawwafi, Amal El Ahmad · United Arab Emirates University · course project CENG 742

---

## The study in one table

| Part | What it is | Size | Raw data | Results |
|---|---|---|---|---|
| **Pilot study** | First timed experiment; its findings shaped the design of the FULL experiment | 1,400 timed runs, 140 configurations | `data/raw/pilot/` | `results/pilot/` |
| **FULL experiment** | Main experiment: γ 2/4/8 × confidence vs fixed drafting × fixed 100 tokens vs natural stop × 6 prompts × 5 randomized blocks | 1,980 timed runs, 396 configurations | `data/raw/full/` | `results/full/` |
| **Prediction model** | Predicts SD time from rounds and draft tokens (T = t_check·rounds + t_draft·proposed), tested on configurations not used for fitting | – | uses the data above | `results/pilot/prediction/`, `results/full/prediction/` |

Both experiments ran on a Tesla T4 in Google Colab, with one Colab session per target precision. In the FULL experiment,
the model revisions are pinned (target `989aa7980e4cf806f80c7fef2b1adb7bc71aa306`, draft
`7ae557604adf67be50417f59c2c2f167def9a775`), the GPU clock is locked at 1590 MHz, and the software versions, clock-lock
result and model footprints are recorded per session in `data/raw/full/<precision>/protocol_*.json`.

---

## Reproducing the results

There are three levels. Levels 1 and 2 need **no GPU**. Each level can be run on its own.

### Level 1 · Regenerate every table and figure from the raw data (CPU, about 3 minutes)

```bash
git clone <repository URL> quantization-speculative-decoding     # or unzip quantization-speculative-decoding.zip
cd quantization-speculative-decoding
pip install -r requirements.txt
make all        # pilot study, pilot prediction, FULL experiment, FULL prediction -> results/
make test       # automatic checks (see "Automatic checks" below)
```

The gradient-boosting comparison (tables G1–G4) is not part of `make all`, because its grid search takes about
5–15 minutes. Run it on its own with `make full_gradient_boosting`.

Without `make` (for example on Windows), run the same commands directly:

```bash
python scripts/pilot_analysis.py   data/raw/pilot/timing data/raw/pilot/logging results/pilot
python scripts/pilot_figures.py    results/pilot
python scripts/pilot_prediction.py results/pilot results/pilot/prediction
python scripts/full_analysis.py    data/raw/full results/pilot results/full
python scripts/full_prediction.py  data/raw/full results/pilot results/full/prediction
python scripts/full_gradient_boosting.py data/raw/full results/full/prediction   # optional, about 5-15 minutes
python -m pytest -q tests
```

The scripts overwrite the files in `results/` with identical values. Afterwards `git status` shows no changes in the CSV,
JSON and TeX files; PDF figures differ only in their embedded creation time.

### Level 2 · Run the prediction model step by step (CPU, about 2 minutes, Colab or your own computer)

`notebooks/06_full_prediction_model.ipynb` explains and runs the FULL prediction model step by step. It includes a worked
example, shows the code of each step, writes all prediction tables and figures, compares them with the results stored in the repository, and saves everything in one ZIP file. The first cell describes four ways to run it:

1. **Colab, repository ZIP on Google Drive:** upload `quantization-speculative-decoding.zip` to *My Drive*, open the
   notebook in Colab and choose *Runtime → Run all*. The result ZIP downloads automatically and is also saved to *My Drive*.
2. **Colab, upload:** the same, with `REPO_SOURCE = "upload"`.
3. **Colab, from GitHub:** set `REPO_SOURCE = "github"` and `GITHUB_URL`.
4. **Your own computer:** `pip install -r requirements.txt jupyter`, then open the notebook and choose *Run All*.

The default Colab runtime (CPU) is enough. Colab's package versions differ from `requirements.txt`. The notebook records
them and reports the largest difference from the results stored in the repository. A test with older package versions gave a largest difference of 2 × 10⁻¹² percentage points.

### Level 3 · Re-run the GPU experiment (Colab, Tesla T4)

1. Open `notebooks/04_full_experiment_colab.ipynb` in Colab with a **T4 GPU** runtime and follow its first cell. Run one
   session per target precision (INT8, INT4, FP16). The notebook installs the versions in `requirements-gpu.txt`, locks the
   GPU clock, saves results after every run, and can resume after a disconnect.
2. Unzip each session's final ZIP into `data/raw/full/<precision>/` (`fp16`, `int8`, `int4`).
3. Open `notebooks/05_full_semantic_similarity_colab.ipynb` in Colab (T4 or CPU), upload the three final ZIPs, and put the
   resulting `semantic_scores.csv` and `semantic_scores_meta.json` into `data/raw/full/`.
4. Run Level 1.

New GPU runs will not reproduce the times exactly, because time depends on the individual GPU, the driver and the clock
behaviour. The generated texts are deterministic. In all configurations that the pilot study and the FULL experiment
share, the outputs and step counts were identical.

---

## What is in each folder

```
data/raw/pilot/timing/      the six timed pilot sessions (all_results.csv, summary.csv, protocol.json)
data/raw/pilot/logging/     pilot acceptance logs and GPU energy measurements (fp16, int8, int4)
data/raw/full/<precision>/  the FULL sessions: runs_v2.csv (one row per run), protocol_*.json, warmup_*.json, revisions.json
data/raw/full/              semantic_scores.csv and semantic_scores_meta.json (text-quality scores from notebook 05)
src/qsd/                    the analysis code (Python package)
    experiment.py             the GPU experiment (the same code that notebook 04 runs)
    full.py                   analysis of the FULL runs
    prediction.py             prediction model on the pilot study, and the fitting routine shared by both models
    prediction_full.py        prediction model on the FULL experiment (fully commented; explains the method choice)
    gradient_boosting.py      comparison: a flexible machine-learning model (gradient boosting) on the same tests
    semantic.py               text-quality scores (used by notebook 05)
scripts/                    the commands that the Makefile runs, and the scripts that build notebooks 04-06
notebooks/                  01-03 pilot study (Colab), 04 FULL experiment (Colab, T4), 05 text quality (Colab),
                            06 FULL prediction model (Colab or your own computer, CPU)
results/pilot/              pilot tables and figures; prediction/ = pilot prediction model
results/full/               FULL tables; prediction/ = FULL prediction model, including LaTeX tables
docs/                       data_dictionary.md: what every column of the raw data files means
                            drafting_mode_note.md: how Hugging Face drafting works (confidence vs fixed drafting)
tests/                      automatic checks, run with `make test`
```

Raw data files are never edited; they are exactly what the experiment notebooks wrote.

Result files are named by type, with a letter and a number:

| Prefix | Content | Folder |
|---|---|---|
| T | pilot tables (T1–T7) and pilot prediction tables (T8–T10) | `results/pilot/`, `results/pilot/prediction/` |
| V | FULL experiment tables (V1–V8) | `results/full/` |
| E | pilot vs FULL on the 39 configurations both experiments ran (E1 speculative, E2 standard decoding) | `results/full/` |
| P | FULL prediction model tables (P1–P6) | `results/full/prediction/` |
| G | gradient-boosting comparison for the prediction model (G1–G4) | `results/full/prediction/` |
| Fig, F | figures | each folder |

## Names used in the paper and in the repository

| In the paper | In the repository |
|---|---|
| Pilot study | `pilot` |
| FULL experiment | `full`; the run files keep their original name `runs_v2.csv` |
| Draft-Length Sensitivity Experiment / Workload and Output-Length Experiment (pilot) | `CORE` / `WORKLOAD` (column `stage` of the pilot raw data) |
| Matched Draft Precision / FP16 Draft Precision | `MATCHED` / `FIXED_FP16` (pilot), `draft_precision` (FULL) |
| Prediction model | `prediction`, `prediction_full` |

## Data filters in the pilot study

The analysis applies two filters to the pilot data. The raw files are not changed; the filters are applied in
`scripts/pilot_analysis.py` every time the results are computed. The FULL experiment needs no filters.

1. **Slow first runs.** When a GPU session starts, the first measurements can be slower than the rest, because the GPU
   has not yet reached its full clock speed. In the pilot study, this affected the first configuration measured in three
   sessions; all three were standard-decoding runs. For these three configurations only, runs that took more than 1.25
   times the fastest run of the same configuration are not used. The FULL experiment prevents the problem: before any
   timed run, each session warms up until three runs in a row agree within 3%.
2. **Memory of one interrupted session.** One pilot session (INT8 target, session `46a79b1049`) was stopped and then
   resumed in the same Colab runtime. After the restart, models from before the stop were still in GPU memory, so the
   memory readings of its 140 runs with an INT8 draft are too high. These 140 runs are left out of the **memory** results
   only; their times and outputs are used normally.

## Automatic checks (`make test`)

* **Exact reproduction:** every pilot table and every FULL table is regenerated from the raw data and compared with the
  stored version.
* **Prediction models:** the fitting recovers known values from artificial data, test configurations are never used for
  fitting, and the stored prediction results are reproduced.
* **Data and notebooks:** the raw data are complete, the experiment notebook contains exactly the tested experiment
  code, and every cell of the prediction notebook is valid Python.


One check is shown as *skipped* on a normal computer. It runs the GPU experiment logic on a tiny test model on the CPU
and needs two large packages that the analysis itself does not use. To run it as well, install them and test again:

    pip install torch --index-url https://download.pytorch.org/whl/cpu
    pip install transformers==5.18.0
    make test

No check is then skipped.

## License

Code (src/, scripts/, tests/, notebooks/, Makefile): MIT License, see `LICENSE`.
Data, results and documentation (data/, results/, docs/): CC BY 4.0, see `LICENSE-DATA`.
The Qwen2.5 models are not included; they are downloaded from Hugging Face under their own license.

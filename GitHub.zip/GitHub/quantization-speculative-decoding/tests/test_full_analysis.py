"""v2 analysis pipeline on a synthetic runs_v2.csv built from Stage 1-3 round times (known answer)."""
import subprocess, sys, numpy as np, pandas as pd
from conftest import ROOT
from qsd import full, experiment as E
from qsd.prediction import load_sd_configs, fit_round_times

def synth(pilot_out, folder):
    d1 = load_sd_configs(pilot_out / "sd_configs_full.csv")
    rng = np.random.default_rng(1); rows = []
    for tp in ["FP16", "INT8"]:
        des = E.Design(target_precision=tp, **E.PRESETS["QUICK"])
        for b, pos, c in des.schedule():
            L = 100
            if c["mode"] == "STANDARD":
                t = L * {"FP16": 0.036, "INT8": 0.154}[tp]; nv = npp = 0
            else:
                tr = d1[(d1.target_precision == tp) & (d1.draft_precision == c["draft_precision"])]
                f = fit_round_times(tr); nv = 45; npp = 90 if c["draft_mode"] == "confidence" else 4 * nv
                t = f["t_verify"] * nv + f["t_draft"] * npp
            rows.append(dict(c, target_precision=tp, block=b, position=pos, timed=b > 0, session_id=tp, task=E.PROMPTS[c["prompt_id"]]["task"],
                             time_s=t * rng.normal(1, 0.01), energy_j=t * 60, generated_tokens=L, n_verify_steps=nv, proposed_total=npp,
                             accepted_total=npp // 2, proposed_excl_last=npp, accepted_excl_last=npp // 2, sm_mhz_start=1590, temp_c_start=60,
                             throttle_start=0, output_hash=c["prompt_id"], output_text=f"answer for {c['prompt_id']} 28 tokyo",
                             answer_correct=E.answer_correct(f"answer for {c['prompt_id']} 28 tokyo", c["prompt_id"])))
        p = folder / tp; p.mkdir(parents=True)
        pd.DataFrame([x for x in rows if x["target_precision"] == tp]).to_csv(p / "runs_v2.csv", index=False)

def test_pipeline(pilot_out, tmp_path):
    synth(pilot_out, tmp_path / "runs")
    out = tmp_path / "out"
    subprocess.run([sys.executable, str(ROOT / "scripts/full_analysis.py"), str(tmp_path / "runs"), str(pilot_out), str(out)], check=True, capture_output=True)
    ck = pd.read_csv(out / "V1_checks.csv")
    assert set(ck.max_distinct_outputs_per_config) == {1} and set(ck.runs_per_config_min) == {5}
    ext = pd.read_csv(out / "V6b_external_test.csv")
    assert ext[(ext.subset == "all") & (ext.model == "M1")].MAPE_pct.iloc[0] < 2      # synthetic data built from the model
    s = pd.read_csv(out / "V2_speedup_configs.csv")
    assert len(s) == 6 * 1 * 2 + 6 * 2 * 2 and s.identical_to_standard.all()

def test_rouge():
    assert full.rouge_l("a b c d", "a b c d") == 1.0 and full.rouge_l("a b", "c d") == 0.0
    assert abs(full.rouge_l("the cat sat", "the cat ran") - 2 / 3) < 1e-9


def test_pilot_equivalence_tables_reproduce():
    """E1/E2 (pilot vs FULL on shared configurations) regenerate exactly from the raw FULL runs and the pilot results."""
    r = full.load_runs(str(ROOT / "data/raw/full"))
    e1, e2 = full.pilot_equivalence(str(ROOT / "results/pilot"), r, full.speedups(r))
    for name, new in [("E1_equivalence_sd_shared_configs.csv", e1), ("E2_equivalence_standard_shared_configs.csv", e2)]:
        pd.testing.assert_frame_equal(pd.read_csv(ROOT / "results/full" / name), new, check_exact=False, rtol=1e-12)
    assert len(e1) == 30 and len(e2) == 9


def test_full_tables_reproduce(tmp_path):
    """Every FULL table (V1-V8, E1-E2) regenerates from data/raw/full and equals the committed file."""
    subprocess.run([sys.executable, str(ROOT / "scripts/full_analysis.py"), str(ROOT / "data/raw/full"), str(ROOT / "results/pilot"),
                    str(tmp_path)], check=True, capture_output=True)
    committed = sorted(p.name for p in (ROOT / "results/full").glob("*.csv"))
    assert len(committed) >= 12
    for name in committed:
        pd.testing.assert_frame_equal(pd.read_csv(ROOT / "results/full" / name), pd.read_csv(tmp_path / name),
                                      check_exact=False, rtol=1e-9, obj=name)

"""Gradient-boosting comparison (Option C): the test rows never influence tuning or fitting, and the committed
error table is consistent with the committed predictions. The full grid search takes minutes, so the fitting checks
use a one-point grid; the full run is `make full_gradient_boosting`."""
import numpy as np
import pandas as pd
import pytest

from conftest import ROOT
from qsd import prediction_full as PF, gradient_boosting as GB

OUT = ROOT / "results/full/prediction"


@pytest.fixture(scope="module")
def d():
    return PF.load_configs(str(ROOT / "data/raw/full"))


@pytest.fixture
def small_grid(monkeypatch):
    monkeypatch.setattr(GB, "GRID", {"gb__n_estimators": [50], "gb__max_depth": [2], "gb__learning_rate": [0.1]})


def test_predictions_only_use_training_rows(d, small_grid):
    """Multiplying the measured time of the test rows by 10 must not change any gradient-boosting prediction."""
    train, test = d.prompt_id != "summary", d.prompt_id == "summary"
    d2 = d.copy(); d2.loc[test, "sd_lat_med"] *= 10
    for numeric in GB.INPUT_SETS.values():
        a, _ = GB.fit_predict(d[train], d[test], numeric)
        b, _ = GB.fit_predict(d2[train], d2[test], numeric)
        np.testing.assert_allclose(a, b)


def test_input_sets():
    """GB2 has exactly the information of M1 (rounds, proposed tokens) on top of GB1; neither sees the measured time."""
    assert set(GB.NUMERIC_GB2) - set(GB.NUMERIC_GB1) == {"n_verify_steps", "proposed_total"}
    assert "sd_lat_med" not in GB.CATEGORICAL + GB.NUMERIC_GB2


def test_committed_errors_match_committed_predictions():
    """G2 (errors) must be recomputable from G1 (predictions) with the shared error code."""
    pred = pd.read_csv(OUT / "G1_gb_predictions.csv")
    committed = pd.read_csv(OUT / "G2_gb_errors.csv")
    now = PF.error_table(pred, ci=False)
    m = committed.merge(now, on=["split", "model"], suffixes=("_c", "_n"))
    assert len(m) == len(now) == len(committed)
    np.testing.assert_allclose(m.MAPE_pct_c, m.MAPE_pct_n, rtol=1e-9)

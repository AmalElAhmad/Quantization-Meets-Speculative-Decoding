"""Raw data checks: the unmodified CSVs contain the documented design."""
import glob, pandas as pd
from conftest import ROOT

def load():
    return pd.concat([pd.read_csv(f) for f in glob.glob(str(ROOT / "data/raw/pilot/timing/*/all_results.csv"))], ignore_index=True)

KEYS = ["stage", "target_precision", "mode", "draft_strategy", "gamma", "prompt_id", "output_length"]

def test_rows_and_configs():
    r = load()
    assert len(r) == 1400
    g = r.groupby(KEYS, dropna=False)
    assert g.ngroups == 140
    assert (g.size() == 10).all()

def test_outputs_deterministic_within_config():
    r = load()
    assert r.groupby(KEYS, dropna=False).output_hash.nunique().max() == 1

def test_fixed_output_length():
    r = load()
    assert (r.generated_tokens == r.output_length).all()

def test_logging_hashes_match():
    v = pd.concat([pd.read_csv(f) for f in glob.glob(str(ROOT / "data/raw/pilot/logging/*/validation_acceptance.csv"))])
    assert len(v) == 140 and v.hash_matches_original.all()

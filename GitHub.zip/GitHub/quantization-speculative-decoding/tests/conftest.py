import sys, subprocess, pathlib, pytest
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

@pytest.fixture(scope="session")
def pilot_out(tmp_path_factory):
    """Regenerate Stage 3 outputs from the raw CSVs into a temp folder."""
    out = tmp_path_factory.mktemp("pilot")
    subprocess.run([sys.executable, str(ROOT / "scripts/pilot_analysis.py"), str(ROOT / "data/raw/pilot/timing"),
                    str(ROOT / "data/raw/pilot/logging"), str(out)], check=True, capture_output=True)
    return out

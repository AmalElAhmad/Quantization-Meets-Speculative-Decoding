"""Stage 4.2 model: recovers known parameters, has no train/test leakage, and reproduces committed results."""
import json, numpy as np, pandas as pd
from conftest import ROOT
from qsd import prediction as P

def synthetic(tv=0.05, td=0.02, n=40, seed=0):
    rng = np.random.default_rng(seed)
    nv = rng.integers(20, 120, n); npp = (nv * rng.uniform(1.5, 3, n)).astype(int)
    return pd.DataFrame(dict(n_verify_steps=nv, proposed_total=npp, sd_lat_med=tv * nv + td * npp))

def test_fit_recovers_parameters():
    c = P.fit_round_times(synthetic())
    assert abs(c["t_verify"] - 0.05) < 1e-9 and abs(c["t_draft"] - 0.02) < 1e-9 and c["a"] == 0

def test_fit_nonnegative():
    d = synthetic(); d["sd_lat_med"] = 0.05 * d.n_verify_steps  # true t_draft = 0
    c = P.fit_round_times(d)
    assert c["t_draft"] >= 0

def test_splits_no_leakage(pilot_out):
    d = P.load_sd_configs(pilot_out / "sd_configs_full.csv")
    for name, folds in P.splits(d).items():
        covered = pd.Series(False, index=d.index)
        for tr, te in folds:
            assert not (tr & te).any(), name
            covered |= te
        if name == "leave_one_workload_out":
            assert covered.all()
            for tr, te in folds:
                assert set(d[tr].prompt_id).isdisjoint(d[te].prompt_id)

def test_predictions_only_use_training_rows(pilot_out):
    """Changing the measured time of a test row must not change any prediction for that row."""
    d = P.load_sd_configs(pilot_out / "sd_configs_full.csv")
    tr, te = d.prompt_id != "summary", d.prompt_id == "summary"
    a = P.predict_split(d, tr, te)
    d2 = d.copy(); d2.loc[te, "sd_lat_med"] *= 10
    b = P.predict_split(d2, tr, te)
    for m in ["pred_B0", "pred_M1", "pred_M2", "pred_M1i"]:
        np.testing.assert_allclose(a[m], b[m])

def test_committed_results_reproduce(pilot_out, tmp_path):
    import subprocess, sys
    subprocess.run([sys.executable, str(ROOT / "scripts/pilot_prediction.py"), str(pilot_out), str(tmp_path)], check=True, capture_output=True)
    for name in ["T8_prediction_errors.csv", "T10_break_even_ratio.csv", "T9_direction_agreement.csv", "predictions_all_splits.csv"]:
        pd.testing.assert_frame_equal(pd.read_csv(ROOT / "results/pilot/prediction" / name), pd.read_csv(tmp_path / name), check_exact=False, rtol=1e-9)

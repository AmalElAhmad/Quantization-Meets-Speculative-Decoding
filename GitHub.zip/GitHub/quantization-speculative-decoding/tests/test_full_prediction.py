"""4.2 on FULL: the joint model recovers known parameters, no split leaks test data into training,
predictions do not depend on the test rows' measured times, and the committed CSVs are reproduced."""
import numpy as np
import pandas as pd
import pytest

from conftest import ROOT
from qsd import prediction_full as PF

RUNS = ROOT / "data/raw/full"


@pytest.fixture(scope="module")
def d():
    return PF.load_configs(str(RUNS))


def test_configs_complete(d):
    assert len(d) == 360 and d.groupby("pair").size().eq(72).all()


def test_joint_fit_recovers_parameters():
    """Synthetic data built with known per-precision times must be fitted exactly."""
    rng = np.random.default_rng(0)
    truth = dict(check_FP16=0.04, check_INT8=0.18, check_INT4=0.06, draft_FP16=0.03, draft_INT8=0.13, draft_INT4=0.045)
    rows = []
    for tp, dp in PF.PAIRS:
        for _ in range(30):
            r = int(rng.integers(5, 100)); p = int(r * rng.uniform(1, 6))
            rows.append(dict(target_precision=tp, draft_precision=dp, n_verify_steps=r, proposed_total=p,
                             sd_lat_med=truth[f"check_{tp}"] * r + truth[f"draft_{dp}"] * p))
    fit = PF.fit_joint(pd.DataFrame(rows))
    for k, v in truth.items():
        assert abs(fit[k] - v) < 1e-9, k


def test_splits_no_leakage(d):
    for name, folds in PF.splits(d).items():
        for train, test in folds:
            assert not (train & test).any(), name
    covered = np.zeros(len(d), bool)
    for train, test in PF.splits(d)["held_out_prompt"]:
        assert set(d[train].prompt_id).isdisjoint(d[test].prompt_id)
        covered |= test.to_numpy()
    assert covered.all()


def test_predictions_only_use_training_rows(d):
    """Multiplying the measured time of the test rows by 10 must not change any prediction."""
    train, test = d.prompt_id != "summary", d.prompt_id == "summary"
    a = PF.predict_split(d, train, test)
    d2 = d.copy(); d2.loc[test, "sd_lat_med"] *= 10
    b = PF.predict_split(d2, train, test)
    for m in PF.PER_PAIR_MODELS:
        np.testing.assert_allclose(a[f"pred_{m}"], b[f"pred_{m}"])


def test_draft_swap_never_sees_test_pair(d):
    """Changing every time of the held-out pair must not change its MJ predictions."""
    a = PF.draft_swap(d)
    for pair in ["INT8+FP16", "INT4+FP16"]:  # one at a time: each held-out pair is training data for the other
        d2 = d.copy(); d2.loc[d2.pair == pair, "sd_lat_med"] *= 10
        b = PF.draft_swap(d2)
        np.testing.assert_allclose(a[a.pair == pair].pred_MJ, b[b.pair == pair].pred_MJ)


def test_reproduces_committed_errors(d):
    committed = pd.read_csv(ROOT / "results/full/prediction/P2_errors.csv")
    now = PF.error_table(PF.run_all(d), ci=False)
    m = committed.merge(now, on=["split", "model"], suffixes=("_c", "_n"))
    assert len(m) == len(now)
    np.testing.assert_allclose(m.MAPE_pct_c, m.MAPE_pct_n, rtol=1e-9)


def test_tokens_per_round_formula():
    """k(alpha=0) = 1 (only the target's own token); k(alpha=1) = gamma + 1; k(0.5, 2) = 1 + 0.5 + 0.25."""
    assert PF.tokens_per_round(0.0, 4) == 1.0
    assert PF.tokens_per_round(1.0, 4) == 5.0
    assert abs(PF.tokens_per_round(0.5, 2) - 1.75) < 1e-12


def test_alpha_mle():
    """Rounds (proposed, accepted): (2,2) all accepted, (2,1) one accepted then rejected; last round is dropped."""
    log = "[[2, 2], [2, 1], [2, 0]]"
    assert abs(PF.alpha_mle([log]) - 3 / 4) < 1e-12


def test_ma_does_not_use_test_times(d):
    """MA predictions must not change when the measured times of the predicted configurations change."""
    pred = PF.run_all(d); ho = pred[pred.split == "held_out_prompt"]
    a = PF.analytical_acceptance(d, ho)
    d2 = d.copy(); m = (d2.prompt_id == "summary") & (d2.draft_mode == "fixed") & (d2.gamma > 2)
    d2.loc[m, "sd_lat_med"] *= 10
    b = PF.analytical_acceptance(d2, ho)
    sel = lambda x: x[(x.split == "MA_S1_new_gamma") & (x.prompt_id == "summary")].pred_MA.to_numpy()
    np.testing.assert_allclose(sel(a), sel(b))


def test_prediction_notebook_is_current_and_valid():
    """Notebook 06 must equal what its builder produces, and every code cell must be valid Python."""
    import ast, json, subprocess, sys
    nb_path = ROOT / "notebooks/06_full_prediction_model.ipynb"
    committed = nb_path.read_text()
    subprocess.run([sys.executable, str(ROOT / "scripts/build_prediction_notebook.py")], check=True, capture_output=True)
    assert nb_path.read_text() == committed, "run scripts/build_prediction_notebook.py"
    for cell in json.loads(committed)["cells"]:
        if cell["cell_type"] == "code":
            ast.parse(cell["source"])

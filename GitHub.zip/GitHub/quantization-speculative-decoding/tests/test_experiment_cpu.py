"""Dry run of the 4.1 experiment logic on CPU with tiny random Qwen2 models (no download, no GPU).
Checks: schedule design, fixed vs confidence drafting, step logging, resume, CSV schema. Skipped without transformers."""
import copy, string, pytest
torch = pytest.importorskip("torch")
transformers = pytest.importorskip("transformers")
from qsd import experiment as E


@pytest.fixture(scope="module")
def tiny():
    from tokenizers import Tokenizer, models, pre_tokenizers
    from transformers import PreTrainedTokenizerFast, Qwen2Config, Qwen2ForCausalLM
    chars = list(string.printable)
    vocab = {"<pad>": 0, "<eos>": 1, **{c: i + 2 for i, c in enumerate(chars)}}
    tk = Tokenizer(models.WordLevel(vocab, unk_token="<pad>")); tk.pre_tokenizer = pre_tokenizers.Split("", "isolated")
    tok = PreTrainedTokenizerFast(tokenizer_object=tk, pad_token="<pad>", eos_token="<eos>")
    tok.chat_template = "{% for m in messages %}{{ m['content'] }}{% endfor %}{% if add_generation_prompt %}>{% endif %}"
    cfg = Qwen2Config(vocab_size=len(vocab), hidden_size=32, intermediate_size=64, num_hidden_layers=2, num_attention_heads=2,
                      num_key_value_heads=1, eos_token_id=1, pad_token_id=0, max_position_embeddings=512)
    torch.manual_seed(0)
    target = Qwen2ForCausalLM(cfg).eval()
    draft_same = copy.deepcopy(target)           # identical weights -> every draft token accepted
    torch.manual_seed(1)
    draft_other = Qwen2ForCausalLM(cfg).eval()   # different weights -> low acceptance
    def prepare(text):
        s = tok.apply_chat_template([{"role": "user", "content": text}], tokenize=False, add_generation_prompt=True)
        return dict(tok(s, return_tensors="pt"))
    return tok, target, draft_same, draft_other, prepare


def test_design_counts():
    d = E.Design(target_precision="INT8", **E.PRESETS["QUICK"])
    cfgs = d.configs()
    assert len(cfgs) == 6 * (1 + 2 * 1 * 2)                    # 6 prompts x (standard + 2 drafts x 1 gamma x 2 modes)
    assert len({c["key"] for c in cfgs}) == len(cfgs)
    s = d.schedule()
    assert len(s) == len(cfgs) * (d.blocks + 1)
    orders = [[c["key"] for b, _, c in s if b == k] for k in range(3)]
    assert orders[0] != orders[1] != orders[2] and sorted(orders[0]) == sorted(orders[1])
    assert E.Design(target_precision="FP16").draft_list() == [("MATCHED", "FP16")]
    assert E.Design(target_precision="INT4").draft_list() == [("FIXED_FP16", "FP16"), ("MATCHED", "INT4")]
    assert 0 < E.estimate_minutes(d) < 300


def test_fixed_vs_confidence_drafting(tiny):
    tok, target, draft_same, draft_other, prepare = tiny
    inp = prepare("hello world"); log = E.StepLogger()
    E.set_draft_mode(draft_same, 4, "fixed")
    r, toks = E.generate_once(target, inp, "fixed20", draft_same, log)
    steps = __import__("json").loads(r["step_log"])
    assert len(toks) == 20
    assert all(p == 4 for p, _ in steps[:-1]), steps            # fixed: always gamma proposals (except the final cropped round)
    assert all(a == p for p, a in steps[:-1])                   # identical draft: all accepted
    ref, _ = E.generate_once(target, inp, "fixed20")
    assert r["output_hash"] == ref["output_hash"]               # greedy SD with identical draft == standard output
    E.set_draft_mode(draft_other, 4, "confidence")
    r2, _ = E.generate_once(target, inp, "fixed20", draft_other, log)
    assert r2["n_verify_steps"] > 0
    assert r2["proposed_total"] / r2["n_verify_steps"] < 4      # confidence rule stops low-confidence drafts early
    assert E.parse_length("natural30") == (30, False)


def test_run_and_resume(tiny, tmp_path):
    tok, target, draft_same, draft_other, prepare = tiny
    d = E.Design(target_precision="INT8", gammas=(2,), draft_modes=("confidence", "fixed"), prompts=("factual", "reasoning"),
                 length_modes=("fixed12", "natural12"), blocks=2)
    drafts = {"FP16": draft_same, "INT8": draft_other}
    out = tmp_path / "runs.csv"
    ended = []
    df = E.run_design(d, target, drafts, tok, prepare, out, "test", max_minutes=1e9, log=lambda *a: None, on_block_end=ended.append)
    assert ended == [0, 1, 2]                                    # callback once per completed block
    n = len(d.configs()) * (d.blocks + 1)
    assert len(df) == n and df.groupby(["key", "block"]).size().max() == 1
    assert set(df[df.block == 0].timed) == {False} and set(df[df.block > 0].timed) == {True}
    ended2 = []
    df2 = E.run_design(d, target, drafts, tok, prepare, out, "test", log=lambda *a: None, on_block_end=ended2.append)   # resume: nothing new
    assert ended2 == []
    assert len(df2) == n
    for col in ["time_s", "energy_j", "sm_mhz_start", "throttle_start", "n_verify_steps", "answer_correct", "output_text", "position"]:
        assert col in df.columns
    # deterministic outputs within a configuration across blocks
    assert df.groupby("key").output_hash.nunique().max() == 1


def test_notebook_embeds_current_module():
    import json
    from conftest import ROOT
    nb = json.loads((ROOT / "notebooks/04_full_experiment_colab.ipynb").read_text())
    cell = "".join(next(c["source"] for c in nb["cells"] if "".join(c["source"]).startswith("%%writefile experiment.py")))
    assert cell.split("\n", 1)[1].rstrip() == (ROOT / "src/qsd/experiment.py").read_text().rstrip(), "run scripts/build_experiment_notebook.py"


def test_full_preset_design(tiny, tmp_path):
    d = E.Design(target_precision="INT8", **E.PRESETS["FULL"])
    assert len(d.configs()) == 6 * 2 * (1 + 2 * 3 * 2) and min(b for b, _, _ in d.schedule()) == 1
    tok, target, draft_same, draft_other, prepare = tiny
    small = E.Design(target_precision="INT4", gammas=(2, 8), draft_modes=("fixed",), prompts=("factual",),
                     length_modes=("natural15",), blocks=1, warmup_block=False)
    df = E.run_design(small, target, {"FP16": draft_same, "INT4": draft_other}, tok, prepare, tmp_path / "r.csv", "t", log=lambda *a: None)
    assert len(df) == len(small.configs()) and df.timed.all() and "run_extra_memory_mb" in df
    assert (df.generated_tokens <= 15).all()

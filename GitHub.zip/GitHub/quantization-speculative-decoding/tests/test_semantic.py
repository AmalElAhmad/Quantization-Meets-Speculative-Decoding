"""Pairing logic for the quality scores, with dummy scorers (no model download)."""
import numpy as np, pandas as pd
from qsd import semantic as S, experiment as E

def runs():
    rows = []
    for tp in ["FP16", "INT8"]:
        for c in E.Design(target_precision=tp, **E.PRESETS["QUICK"]).configs():
            txt = f"{c['prompt_id']} answer" + ("" if tp == "FP16" else " q")
            rows.append(dict(c, target_precision=tp, timed=True, block=1, task=E.PROMPTS[c["prompt_id"]]["task"], output_text=txt))
    return pd.DataFrame(rows)

def test_pairs_and_scores():
    p = S.build_pairs(runs())
    # SD rows: 2 references each; INT8 standard: FP16 reference only; FP16 standard: none
    n_sd = 6 * 2 * 1 + 6 * 4 * 1
    assert len(p) == 2 * n_sd + 6
    assert set(p.reference) == {"same_precision_standard", "fp16_standard"}
    emb = lambda xs: np.array([[1.0, 0.0] if "q" not in x else [0.6, 0.8] for x in xs])
    s = S.score(p, lambda a, b: [1.0] * len(a), emb)
    same = s[s.reference == "same_precision_standard"]
    assert (same.rouge_l == 1).all() and np.allclose(same.embedding_cosine, 1)
    q = s[(s.reference == "fp16_standard") & (s.target_precision == "INT8")]
    assert np.allclose(q.embedding_cosine, 0.6) and (q.rouge_l < 1).all()

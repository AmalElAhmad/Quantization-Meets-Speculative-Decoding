"""Stage 3 tables regenerate exactly from the raw CSVs (and match the tables committed in results/pilot)."""
import glob, os, pandas as pd, pytest
from conftest import ROOT

TABLES = sorted(os.path.basename(f) for f in glob.glob(str(ROOT / "results/pilot/*.csv")))

def test_tables_present():
    assert len(TABLES) == 15

@pytest.mark.parametrize("name", TABLES)
def test_table_reproduces(pilot_out, name):
    pd.testing.assert_frame_equal(pd.read_csv(ROOT / "results/pilot" / name), pd.read_csv(pilot_out / name),
                                  check_exact=False, rtol=1e-9)

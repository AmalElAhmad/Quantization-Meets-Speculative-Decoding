# Note for the method section: drafting in transformers 5.18.0

`assistant_confidence_threshold` (default 0.4) stops a draft early when the draft model's probability for its next token
falls below the threshold. When scikit-learn is installed (it was: `sklearn_available: true` in the logging environment),
`AssistedCandidateGenerator.update_candidate_strategy` re-tunes this threshold after every verification round from an ROC
curve of past draft probabilities vs acceptance (false negatives weighted 3x). The threshold starts again at 0.4 for each
`generate()` call because the assistant generation config is copied per call.

Therefore the Stage 1-3 runs used **adaptive confidence-based drafting with an initial threshold of 0.4**, and gamma is a
maximum draft length. Setting the threshold to 0 disables both the stopping criterion and the adaptation, which gives
fixed-length drafting (verified on CPU in tests/test_experiment_cpu.py: every non-final round proposes exactly gamma tokens).
Source: transformers 5.18.0, generation/candidate_generator.py and generation/utils.py (ConfidenceCriteria is added only
when the threshold is > 0).

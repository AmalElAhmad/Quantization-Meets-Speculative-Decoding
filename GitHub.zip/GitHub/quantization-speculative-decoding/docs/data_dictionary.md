# Data dictionary

## data/raw/pilot/timing/<session>/all_results.csv (one row per timed run; 10 runs per configuration)
| column | meaning |
|---|---|
| time_s | measured wall time of one `generate()` call, GPU-synchronized (s) |
| generated_tokens | new tokens (always = output_length, because `min_new_tokens = max_new_tokens`) |
| peak_gpu_memory_mb | `torch.cuda.max_memory_allocated()` during the run (MB) |
| session_id | Colab session; one target precision per session |
| stage | CORE (Draft-Length Sensitivity Experiment) or WORKLOAD (Workload and Output-Length Experiment) |
| target_precision / draft_precision | FP16, INT8 (LLM.int8), INT4 (NF4); draft NONE for standard decoding |
| draft_strategy | MATCHED (Matched Draft Precision) or FIXED_FP16 (FP16 Draft Precision) |
| mode | STANDARD or SD |
| gamma | `num_assistant_tokens`: maximum draft length (adaptive confidence-based drafting may stop earlier) |
| prompt_id, output_length, input_tokens | prompt, requested new tokens, prompt tokens |
| output_hash | first 16 hex characters of SHA-256 of the generated token list |
| exact_match, token_agreement | SD output vs the first standard output of the same prompt and length |

## data/raw/pilot/logging/<precision>/
* `validation_acceptance.csv`: one untimed run per configuration, with an output-hash check, the per-round `step_log`
  [(proposed, accepted), ...], `n_verify_steps`, and acceptance (the final round is excluded because the length limit can crop it).
* `energy.csv`: NVML energy-counter readings, 3 runs per configuration (CORE + WORKLOAD at 100 tokens), plus idle power, SM clock and temperature.

## data/raw/full/<precision>/runs_v2.csv (FULL experiment; one row per timed run; blocks 1-5, no untimed warm-up block)
Adds: block, position (order within the block), draft_mode (confidence / fixed), length_mode (fixed100 / natural200),
energy_j for every run, SM/memory clock, temperature and throttle reasons at start and end, per-round step counts
from the timed run itself, output_text, answer_correct, and task.
Files from Colab: runs_v2.csv, protocol_<session>.json (versions, model revisions, clock-lock result, model footprints),
warmup_<session>.json, revisions.json.

## data/raw/full/semantic_scores.csv
Text-quality scores computed by notebook 05 after all FULL sessions: BERTScore F1 (roberta-large, layer 17, no rescaling)
and embedding cosine (all-MiniLM-L6-v2) of each configuration's output against standard decoding of the same precision
and against FP16 standard decoding. Model revisions are recorded in semantic_scores_meta.json.

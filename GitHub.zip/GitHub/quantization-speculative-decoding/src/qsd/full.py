"""Analysis of the FULL experiment (runs_v2.csv from each Colab session; report Section 4.1) + external test of the pilot prediction model.
All values produced here are 'measured' (times, energy, clocks) or 'calculated' (ratios, CIs, ROUGE-L, predictions
labelled 'predicted')."""
from __future__ import annotations

import glob
import os

import numpy as np
import pandas as pd

from .prediction import fit_round_times, PAIRS, SEED

B = 5000


def load_runs(folder: str) -> pd.DataFrame:
    """Read every runs_v2.csv below folder (one per precision session); keep timed rows only."""
    files = sorted(glob.glob(os.path.join(folder, "**", "runs_v2.csv"), recursive=True))
    assert files, f"no runs_v2.csv under {folder}"
    r = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
    r["gamma"] = pd.to_numeric(r["gamma"], errors="coerce")
    return r


def checks(r: pd.DataFrame) -> pd.DataFrame:
    """Completeness, determinism and GPU-state summary per target precision."""
    t = r[r.timed]
    rows = []
    for p, g in t.groupby("target_precision"):
        rows.append(dict(target_precision=p, sessions=g.session_id.nunique(), configs=g.key.nunique(), timed_runs=len(g),
                         runs_per_config_min=int(g.groupby("key").size().min()),
                         max_distinct_outputs_per_config=int(g.groupby("key").output_hash.nunique().max()),
                         sm_mhz_median=g.sm_mhz_start.median(), sm_mhz_min=g.sm_mhz_start.min(), sm_mhz_max=g.sm_mhz_start.max(),
                         temp_c_median=g.temp_c_start.median(), runs_throttled=int((g.throttle_start.fillna(0) > 1).sum()),
                         run_time_cv_median=float(g.groupby("key").time_s.agg(lambda s: s.std() / s.mean()).median())))
    return pd.DataFrame(rows)


def _boot_ratio(a, b, rng):
    a, b = np.asarray(a), np.asarray(b)
    r = np.median(a[rng.integers(0, len(a), (B, len(a)))], 1) / np.median(b[rng.integers(0, len(b), (B, len(b)))], 1)
    return np.percentile(r, [2.5, 97.5])


def speedups(r: pd.DataFrame) -> pd.DataFrame:
    """SD speedup = median standard time / median SD time (same precision, prompt, length mode), bootstrap 95% CI."""
    rng = np.random.default_rng(SEED)
    t = r[r.timed]
    rows = []
    sd = t[t["mode"] == "SD"]
    for k, g in sd.groupby(["target_precision", "draft_precision", "draft_strategy", "draft_mode", "gamma", "prompt_id", "length_mode"]):
        tp, dp, ds, dm, ga, pid, lm = k
        base = t[(t["mode"] == "STANDARD") & (t.target_precision == tp) & (t.prompt_id == pid) & (t.length_mode == lm)]
        if base.empty:
            continue
        lo, hi = _boot_ratio(base.time_s, g.time_s, rng)
        gen = g.generated_tokens.median()
        std_ms_tok = 1000 * (base.time_s / base.generated_tokens).median(); sd_ms_tok = 1000 * (g.time_s / g.generated_tokens).median()
        rows.append(dict(target_precision=tp, draft_precision=dp, draft_strategy=ds, draft_mode=dm, gamma=ga, prompt_id=pid,
                         std_ms_per_token=std_ms_tok, sd_ms_per_token=sd_ms_tok, speedup_per_token=std_ms_tok / sd_ms_tok,
                         task=g.task.iloc[0], length_mode=lm, n_sd=len(g), n_std=len(base), std_time_s=base.time_s.median(),
                         sd_time_s=g.time_s.median(), speedup=base.time_s.median() / g.time_s.median(), ci_lo=lo, ci_hi=hi,
                         std_energy_j=base.energy_j.median(), sd_energy_j=g.energy_j.median(),
                         energy_ratio=g.energy_j.median() / base.energy_j.median(),
                         generated_tokens=gen, std_generated_tokens=base.generated_tokens.median(),
                         n_verify_steps=g.n_verify_steps.median(), proposed_total=g.proposed_total.median(),
                         accepted_total=g.accepted_total.median(),
                         acceptance_rate=g.accepted_excl_last.sum() / max(g.proposed_excl_last.sum(), 1),
                         identical_to_standard=bool(set(g.output_hash) == set(base.output_hash))))
    s = pd.DataFrame(rows)
    if len(s):
        s["verdict"] = np.where(s.ci_lo > 1, "speedup", np.where(s.ci_hi < 1, "slowdown", "no clear difference"))
    return s


def speedup_summary(s: pd.DataFrame) -> pd.DataFrame:
    return s.groupby(["target_precision", "draft_precision", "draft_mode", "gamma", "length_mode"]).agg(
        configs=("speedup", "size"), speedup_median=("speedup", "median"), speedup_min=("speedup", "min"),
        speedup_max=("speedup", "max"), faster=("verdict", lambda v: int((v == "speedup").sum())),
        slower=("verdict", lambda v: int((v == "slowdown").sum())), energy_ratio_median=("energy_ratio", "median"),
        acceptance_rate_median=("acceptance_rate", "median"), proposed_per_round=("proposed_total", "sum"),
        rounds=("n_verify_steps", "sum"), identical=("identical_to_standard", "sum")).assign(
        proposed_per_round=lambda x: x.proposed_per_round / x.rounds).drop(columns="rounds").reset_index()


# ------------------------------------------------------------------------------------- quality
def rouge_l(a: str, b: str) -> float:
    """ROUGE-L F1 on lower-cased whitespace tokens (LCS based)."""
    x, y = str(a).lower().split(), str(b).lower().split()
    if not x or not y:
        return float("nan")
    prev = [0] * (len(y) + 1)
    for xi in x:
        cur = [0]
        for j, yj in enumerate(y):
            cur.append(prev[j] + 1 if xi == yj else max(prev[j + 1], cur[j]))
        prev = cur
    l = prev[-1]
    if l == 0:
        return 0.0
    p, r = l / len(x), l / len(y)
    return 2 * p * r / (p + r)


def quality(r: pd.DataFrame) -> pd.DataFrame:
    """Per configuration: answer correctness and ROUGE-L vs (a) same-precision standard output, (b) FP16 standard output."""
    t = r[r.timed].drop_duplicates(["target_precision", "key"])  # outputs are deterministic within a configuration
    ref_fp16 = t[(t["mode"] == "STANDARD") & (t.target_precision == "FP16")].set_index(["prompt_id", "length_mode"]).output_text
    ref_same = t[t["mode"] == "STANDARD"].set_index(["target_precision", "prompt_id", "length_mode"]).output_text
    rows = []
    for _, x in t.iterrows():
        k2 = (x.prompt_id, x.length_mode)
        rows.append(dict(target_precision=x.target_precision, mode=x["mode"], draft_precision=x.draft_precision,
                         draft_mode=x.draft_mode, gamma=x.gamma, prompt_id=x.prompt_id, task=x.task, length_mode=x.length_mode,
                         answer_correct=x.answer_correct,
                         rouge_l_vs_same_precision_standard=rouge_l(x.output_text, ref_same.get((x.target_precision,) + k2, "")),
                         rouge_l_vs_fp16_standard=rouge_l(x.output_text, ref_fp16[k2]) if k2 in ref_fp16.index else np.nan))
    return pd.DataFrame(rows)


# ------------------------------------------------------------------------------------- external test of 4.2
def external_test(v1_sd_configs: pd.DataFrame, s: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Round times fitted on ALL Stage 1-3 SD configurations (no v2 data) predict v2 median SD times.
    M1: v2 step counts (logged in the timed runs). B0: Stage 1-3 per-token rate x generated tokens."""
    rows = []
    for tp, dp in PAIRS:
        tr = v1_sd_configs[(v1_sd_configs.target_precision == tp) & (v1_sd_configs.draft_precision == dp)]
        te = s[(s.target_precision == tp) & (s.draft_precision == dp)].copy()
        if te.empty or tr.empty:
            continue
        c = fit_round_times(tr); rate = tr.sd_lat_med.sum() / tr.output_length.sum()
        te["pred_M1"] = c["t_verify"] * te.n_verify_steps + c["t_draft"] * te.proposed_total
        te["pred_B0"] = rate * te.generated_tokens
        rows.append(te)
    p = pd.concat(rows, ignore_index=True)
    rng = np.random.default_rng(SEED); out = []
    for keys, g in [(("all",), p)] + [((dm,), g) for dm, g in p.groupby("draft_mode")]:
        y = g.sd_time_s.to_numpy(); idx = rng.integers(0, len(g), (B, len(g)))
        for m in ["B0", "M1"]:
            ape = 100 * np.abs(g[f"pred_{m}"].to_numpy() - y) / y
            lo, hi = np.percentile(ape[idx].mean(1), [2.5, 97.5])
            out.append(dict(subset=keys[0], model=m, n=len(g), MAPE_pct=ape.mean(), MAPE_lo=lo, MAPE_hi=hi,
                            MAE_s=np.abs(g[f"pred_{m}"] - y).mean(), bias_s=(g[f"pred_{m}"] - y).mean()))
    return p, pd.DataFrame(out)


def order_effect(r: pd.DataFrame) -> pd.DataFrame:
    """Median of (run time / configuration median) by block and by position tercile - checks drift and order effects."""
    t = r[r.timed].copy()
    t["rel"] = t.time_s / t.groupby(["target_precision", "key"]).time_s.transform("median")
    t["pos_tercile"] = t.groupby(["target_precision", "block"]).position.transform(lambda s: pd.qcut(s, 3, labels=[1, 2, 3]))
    a = t.groupby(["target_precision", "block"]).rel.median().rename("median_rel_time").reset_index().assign(by="block")
    b = t.groupby(["target_precision", "pos_tercile"], observed=True).rel.median().rename("median_rel_time").reset_index().assign(by="position_tercile")
    return pd.concat([a.rename(columns={"block": "level"}), b.rename(columns={"pos_tercile": "level"})], ignore_index=True)


# ------------------------------------------------------------------------------------- memory (same runs)
def memory_table(folder: str, r: pd.DataFrame) -> pd.DataFrame:
    """Configuration memory = footprint(target) + footprint(draft used) + median extra memory of the timed runs.
    Footprints come from protocol_<session>.json of the same session (models are loaded once per session)."""
    import json
    fp = {}
    for f in glob.glob(os.path.join(folder, "**", "protocol_*.json"), recursive=True):
        p = json.load(open(f)); fp[p["session_id"]] = p["footprint_mb"]
    t = r[r.timed]
    if "run_extra_memory_mb" not in t:
        return pd.DataFrame()
    rows = []
    for (sid, key), g in t.groupby(["session_id", "key"]):
        x = g.iloc[0]; f = fp.get(sid, {})
        draft_fp = f.get(f"draft_{x.draft_precision}", 0.0) if x["mode"] == "SD" else 0.0
        extra = g.run_extra_memory_mb.median()
        rows.append(dict(session_id=sid, target_precision=x.target_precision, mode=x["mode"], draft_precision=x.draft_precision,
                         draft_mode=x.draft_mode, gamma=x.gamma, prompt_id=x.prompt_id, length_mode=x.length_mode,
                         target_footprint_mb=f.get("target", np.nan), draft_footprint_mb=draft_fp, run_extra_mb=extra,
                         config_memory_mb=f.get("target", np.nan) + draft_fp + extra))
    return pd.DataFrame(rows)


def pilot_equivalence(pilot_dir: str, r: pd.DataFrame, s: pd.DataFrame):
    """Pilot vs FULL on the configurations both experiments ran (reproducibility check; tables E1 and E2).

    Shared configurations: pilot WORKLOAD experiment at 100 tokens (prompts factual, summary, reasoning; gamma 2 and 4;
    adaptive confidence drafting, the only mode the pilot used) = FULL with draft_mode 'confidence' and length 'fixed100'.
    E1 (30 SD configurations) and E2 (9 standard configurations) put the pilot value (suffix 1) next to the FULL value
    (suffix 2): output hash, rounds (nv), proposed tokens (np), median time (t), speedup (sp, pilot CI lo1/hi1), verdict,
    SD output identical to standard (exact), acceptance (acc) and pilot memory (mem1; empty where the pilot memory
    filter excluded the run). tratio / ratio = FULL time / pilot time. All values measured or calculated.
    Inputs: pilot_dir = results/pilot (sd_configs_full.csv, all_configs_summary.csv); r = load_runs(); s = speedups(r).
    """
    p_sd = pd.read_csv(os.path.join(pilot_dir, "sd_configs_full.csv"))
    p_all = pd.read_csv(os.path.join(pilot_dir, "all_configs_summary.csv"))
    shared = lambda d: d[(d.stage == "WORKLOAD") & (d.output_length == 100)]
    p_sd, p_all = shared(p_sd), shared(p_all)
    timed = r[r.timed]
    # FULL output hash per configuration (outputs are deterministic, so the first timed run represents all 5)
    keys_sd = ["target_precision", "draft_precision", "draft_mode", "gamma", "prompt_id", "length_mode"]
    h_sd = timed[timed["mode"] == "SD"].groupby(keys_sd).output_hash.first().rename("hash2").reset_index()
    h_std = timed[timed["mode"] == "STANDARD"].groupby(["target_precision", "prompt_id", "length_mode"]).output_hash.first().rename("hash2").reset_index()

    # ---- E1: SD configurations
    f = s[(s.draft_mode == "confidence") & (s.length_mode == "fixed100")].merge(h_sd, on=keys_sd)
    p = p_sd.merge(p_all[p_all["mode"] == "SD"][["target_precision", "draft_precision", "g", "prompt_id", "output_hash"]],
                   on=["target_precision", "draft_precision", "g", "prompt_id"])
    m = p.merge(f, left_on=["target_precision", "draft_precision", "g", "prompt_id"],
                right_on=["target_precision", "draft_precision", "gamma", "prompt_id"], suffixes=("_1", "_2"))
    e1 = pd.DataFrame(dict(tp=m.target_precision, dp=m.draft_precision, g=m.g, pid=m.prompt_id,
                           hash_same=m.output_hash == m.hash2,
                           nv1=m.n_verify_steps_1, nv2=m.n_verify_steps_2.astype(int), np1=m.proposed_total_1, np2=m.proposed_total_2.astype(int),
                           t1=m.sd_lat_med, t2=m.sd_time_s, tratio=m.sd_time_s / m.sd_lat_med,
                           sp1=m.speedup_1, lo1=m.ci_lo_1, hi1=m.ci_hi_1, sp2=m.speedup_2, verdict1=m.verdict_1,
                           exact1=m.exact_match == 1, exact2=m.identical_to_standard,
                           acc1=m.acceptance_rate_1, acc2=m.acceptance_rate_2, mem1=m.sd_mem))
    # ---- E2: standard-decoding configurations
    ps = p_sd.groupby(["target_precision", "prompt_id"])[["std_lat_med_corrected", "std_mem"]].first().reset_index()
    pa = p_all[p_all["mode"] == "STANDARD"][["target_precision", "prompt_id", "output_hash"]]
    fs = s[(s.length_mode == "fixed100")].groupby(["target_precision", "prompt_id"]).std_time_s.first().reset_index()
    fs = fs.merge(h_std[h_std.length_mode == "fixed100"], on=["target_precision", "prompt_id"])
    m2 = ps.merge(pa, on=["target_precision", "prompt_id"]).merge(fs, on=["target_precision", "prompt_id"])
    e2 = pd.DataFrame(dict(tp=m2.target_precision, pid=m2.prompt_id, hash_same=m2.output_hash == m2.hash2,
                           t1=m2.std_lat_med_corrected, t2=m2.std_time_s, ratio=m2.std_time_s / m2.std_lat_med_corrected,
                           mem1=m2.std_mem))
    order = lambda d, k: d.sort_values(k).reset_index(drop=True)
    return order(e1, ["tp", "dp", "g", "pid"]), order(e2, ["tp", "pid"])

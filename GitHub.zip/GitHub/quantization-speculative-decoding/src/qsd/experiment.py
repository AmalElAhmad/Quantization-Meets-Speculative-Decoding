"""Stage 4.1 - improved timing experiment (v2) for quantization x speculative decoding on a Tesla T4.

This module holds all experiment logic so it can be unit-tested on CPU with tiny random models.
The Colab notebook (notebooks/04_experiment_v2_colab.ipynb) embeds this exact file.

Changes relative to the Stage 1-3 notebook (each answers one known gap):
  G1 pinning          - exact package versions + Hugging Face model revisions (commit hashes) recorded/forced
  G2 warm-up          - session warm-up until three consecutive runs agree within 3 %, plus one untimed warm-up block
  G3 GPU clock        - SM/memory clock, temperature, power and throttle reasons logged for every run;
                        clock lock is attempted and its success recorded (Colab usually refuses it)
  G4 run order        - randomized complete blocks: every configuration once per block, new random order per block
  G5 prompts          - two prompts per task (6 prompts) instead of one
  G6 output length    - fixed length (min = max) AND natural stopping at EOS (max only)
  G7 quality          - answer checks for factual/reasoning prompts; decoded text saved for ROUGE-L in analysis
  G8 energy           - NVML energy counter read for every timed run, in every session
  G9 drafting         - adaptive confidence-based drafting (HF default, starts at 0.4) vs fixed-length drafting (threshold 0)
  +  step counts      - proposed/accepted draft tokens per verification round logged in the timed runs themselves

Label mapping for the report (raw values are not renamed): draft_strategy MATCHED = "Matched Draft Precision",
FIXED_FP16 = "FP16 Draft Precision".
"""
from __future__ import annotations

import gc
import hashlib
import json
import os
import random
import subprocess
import time
from dataclasses import dataclass, asdict, field
from pathlib import Path

import pandas as pd

# ---------------------------------------------------------------------------------------------- prompts
# 'check' = substring that a correct answer must contain (case-insensitive). None = no automatic check (ROUGE-L only).
PROMPTS = {
    "factual": dict(task="factual", check="tokyo",
                    text="What is the capital of Japan? Answer in one sentence."),
    "factual_2": dict(task="factual", check="au",
                      text="What is the chemical symbol for gold? Answer in one sentence."),
    "summary": dict(task="summary", check=None,
                    text="Summarize in two sentences: Large language models generate text by predicting tokens. Their inference can require substantial memory and computation. Quantization reduces numerical precision to lower memory use, while speculative decoding uses a smaller draft model to propose tokens for verification."),
    "summary_2": dict(task="summary", check=None,
                      text="Summarize in two sentences: Solar panels convert sunlight into electricity using semiconductor cells. Their output depends on sunlight, temperature and panel angle. Batteries store extra energy for use at night, while inverters convert direct current into the alternating current used in homes."),
    "reasoning": dict(task="reasoning", check="28",
                      text="A shop sells 3 notebooks for 12 dollars. If the price per notebook stays the same, what is the cost of 7 notebooks? Explain briefly."),
    "reasoning_2": dict(task="reasoning", check="160",
                        text="A train travels 60 km in 1.5 hours. At the same speed, how far does it travel in 4 hours? Explain briefly."),
}
ORIGINAL_PROMPTS = ["factual", "summary", "reasoning"]  # identical text to the Stage 1-3 Workload and Output-Length Experiment

# ---------------------------------------------------------------------------------------------- design
@dataclass
class Design:
    target_precision: str = "INT8"                     # one per session: FP16 / INT8 / INT4
    draft_precisions: tuple = ("FP16", "MATCHED")      # MATCHED -> same as target; deduplicated for FP16 targets
    gammas: tuple = (4,)
    draft_modes: tuple = ("confidence", "fixed")       # confidence = HF default adaptive threshold; fixed = threshold 0
    prompts: tuple = tuple(PROMPTS)
    length_modes: tuple = ("fixed100",)                # fixed<N>: min=max=N tokens; natural<N>: max N, stop at EOS
    blocks: int = 5                                    # timed repetitions (randomized complete blocks)
    seed: int = 742
    stable_tol: float = 0.03                           # session warm-up: 3 consecutive runs within 3 %
    max_session_warmups: int = 15
    warmup_block: bool = True                          # untimed block 0 before the timed blocks (QUICK only; FULL drops it)

    def draft_list(self):
        out = []
        for d in self.draft_precisions:
            p = self.target_precision if d == "MATCHED" else d
            strat = "MATCHED" if (d == "MATCHED" or p == self.target_precision) else f"FIXED_{p}"
            if p not in [x[1] for x in out]:
                out.append((strat, p))
        return out

    def configs(self) -> list[dict]:
        cfgs = []
        for pid in self.prompts:
            for lm in self.length_modes:
                cfgs.append(dict(mode="STANDARD", draft_strategy="NONE", draft_precision="NONE", gamma=None,
                                 draft_mode="NONE", prompt_id=pid, length_mode=lm))
                for strat, dp in self.draft_list():
                    for g in self.gammas:
                        for dm in self.draft_modes:
                            cfgs.append(dict(mode="SD", draft_strategy=strat, draft_precision=dp, gamma=int(g),
                                             draft_mode=dm, prompt_id=pid, length_mode=lm))
        for c in cfgs:
            c["key"] = config_key(c)
        return cfgs

    def schedule(self) -> list[tuple[int, int, dict]]:
        """(block, position, config). Block 0 (if any) is the untimed warm-up block; timed blocks are 1..blocks.
        Each block is a fresh random order (seeded, reproducible)."""
        cfgs = self.configs(); out = []
        for b in range(0 if self.warmup_block else 1, self.blocks + 1):
            order = cfgs[:]; random.Random(self.seed * 1000 + b).shuffle(order)
            out += [(b, i, c) for i, c in enumerate(order)]
        return out


def config_key(c: dict) -> str:
    return "|".join(str(c[k]) for k in ["mode", "draft_strategy", "draft_precision", "gamma", "draft_mode", "prompt_id", "length_mode"])


def parse_length(length_mode: str) -> tuple[int, bool]:
    if length_mode.startswith("fixed"):
        return int(length_mode[5:]), True
    if length_mode.startswith("natural"):
        return int(length_mode[7:]), False
    raise ValueError(length_mode)


# ---------------------------------------------------------------------------------------------- step logging
class StepLogger:
    """Wraps AssistedCandidateGenerator.update_candidate_strategy (called once per verification round).
    Records (proposed, accepted) per round. The library source is not modified."""

    def __init__(self):
        from transformers.generation.candidate_generator import AssistedCandidateGenerator as ACG
        self.ACG, self.steps, self.active = ACG, [], False
        if not hasattr(ACG, "_ceng742_orig"):
            ACG._ceng742_orig = ACG.update_candidate_strategy
        logger = self

        def wrapped(self_, input_ids, scores, num_matches):
            if logger.active:
                logger.steps.append((int(scores.shape[1] - 1), int(num_matches)))
            return ACG._ceng742_orig(self_, input_ids, scores, num_matches)
        ACG.update_candidate_strategy = wrapped

    def start(self):
        self.steps, self.active = [], True

    def stop(self):
        self.active = False
        return list(self.steps)


def set_draft_mode(draft, gamma: int, draft_mode: str):
    gc_ = draft.generation_config
    gc_.num_assistant_tokens = int(gamma)
    gc_.num_assistant_tokens_schedule = "constant"
    if draft_mode == "confidence":
        gc_.assistant_confidence_threshold = 0.4      # HF default start value (adaptive when scikit-learn is installed)
    elif draft_mode == "fixed":
        gc_.assistant_confidence_threshold = 0.0      # disables ConfidenceCriteria and the adaptive update
    else:
        raise ValueError(draft_mode)


# ---------------------------------------------------------------------------------------------- GPU telemetry
class GPU:
    """NVML telemetry. Works as a no-op (NaN values) when NVML/GPU is absent, so the logic can be tested on CPU."""

    def __init__(self):
        self.h = None
        try:
            import pynvml
            pynvml.nvmlInit(); self.nv = pynvml; self.h = pynvml.nvmlDeviceGetHandleByIndex(0)
            self.nv.nvmlDeviceGetTotalEnergyConsumption(self.h); self.energy_ok = True
        except Exception:
            self.energy_ok = False

    def state(self) -> dict:
        if self.h is None:
            return dict(sm_mhz=float("nan"), mem_mhz=float("nan"), temp_c=float("nan"), power_w=float("nan"), throttle=-1)
        nv, h = self.nv, self.h
        try:
            thr = int(nv.nvmlDeviceGetCurrentClocksEventReasons(h))
        except Exception:
            try:
                thr = int(nv.nvmlDeviceGetCurrentClocksThrottleReasons(h))
            except Exception:
                thr = -1
        return dict(sm_mhz=nv.nvmlDeviceGetClockInfo(h, nv.NVML_CLOCK_SM), mem_mhz=nv.nvmlDeviceGetClockInfo(h, nv.NVML_CLOCK_MEM),
                    temp_c=nv.nvmlDeviceGetTemperature(h, nv.NVML_TEMPERATURE_GPU), power_w=nv.nvmlDeviceGetPowerUsage(h) / 1000, throttle=thr)

    def energy_mj(self) -> float:
        return float(self.nv.nvmlDeviceGetTotalEnergyConsumption(self.h)) if self.energy_ok else float("nan")


def try_lock_clocks(mhz: int = 1590) -> dict:
    """Attempt to lock the SM clock (needs root on the host; Colab normally refuses). Result is recorded, not assumed."""
    try:
        r = subprocess.run(["nvidia-smi", "-lgc", f"{mhz},{mhz}"], capture_output=True, text=True, timeout=20)
        return dict(clock_lock_requested=mhz, clock_lock_returncode=r.returncode, clock_lock_msg=(r.stdout + r.stderr).strip()[:300])
    except Exception as e:  # nvidia-smi missing (CPU test)
        return dict(clock_lock_requested=mhz, clock_lock_returncode=-1, clock_lock_msg=str(e)[:300])


# ---------------------------------------------------------------------------------------------- measurement
def sync():
    import torch
    if torch.cuda.is_available():
        torch.cuda.synchronize()


def generate_once(target, inputs, length_mode, draft=None, steplog: StepLogger | None = None, gpu: GPU | None = None):
    """One timed generation with telemetry. Returns (row dict, token list)."""
    import torch
    n, fixed = parse_length(length_mode)
    args = dict(max_new_tokens=n, do_sample=False)
    if fixed:
        args["min_new_tokens"] = n
    gpu = gpu or GPU()
    cuda = torch.cuda.is_available()
    sync()
    if cuda:
        torch.cuda.reset_peak_memory_stats()
        mem_before = torch.cuda.memory_allocated()
    s0 = gpu.state(); e0 = gpu.energy_mj()
    if steplog is not None:
        steplog.start()
    t0 = time.perf_counter()
    with torch.inference_mode():
        out = target.generate(**inputs, assistant_model=draft, **args) if draft is not None else target.generate(**inputs, **args)
    sync()
    t1 = time.perf_counter()
    e1 = gpu.energy_mj(); s1 = gpu.state()
    steps = steplog.stop() if steplog is not None else []
    tokens = out[0, inputs["input_ids"].shape[1]:].detach().cpu().tolist()
    dt = t1 - t0
    body = steps[:-1]
    row = dict(time_s=dt, generated_tokens=len(tokens), tokens_per_s=len(tokens) / dt,
               peak_gpu_memory_mb=(torch.cuda.max_memory_allocated() / 1024 ** 2) if cuda else float("nan"),
               # extra memory this run needed on top of everything already loaded (KV cache, activations);
               # configuration memory = footprint(target) + footprint(draft used) + run_extra_memory_mb
               run_extra_memory_mb=((torch.cuda.max_memory_allocated() - mem_before) / 1024 ** 2) if cuda else float("nan"),
               energy_j=(e1 - e0) / 1000, avg_power_w=(e1 - e0) / 1000 / dt,
               sm_mhz_start=s0["sm_mhz"], sm_mhz_end=s1["sm_mhz"], mem_mhz_start=s0["mem_mhz"], temp_c_start=s0["temp_c"],
               temp_c_end=s1["temp_c"], throttle_start=s0["throttle"], throttle_end=s1["throttle"],
               n_verify_steps=len(steps), proposed_total=sum(p for p, _ in steps), accepted_total=sum(a for _, a in steps),
               proposed_excl_last=sum(p for p, _ in body), accepted_excl_last=sum(a for _, a in body),
               step_log=json.dumps(steps) if steps else "",
               output_hash=hashlib.sha256(str(tokens).encode()).hexdigest()[:16])
    return row, tokens


def answer_correct(text: str, prompt_id: str):
    chk = PROMPTS[prompt_id]["check"]
    if chk is None:
        return None
    t = text.lower()
    if chk == "au":  # whole-token check so that e.g. 'because' does not count
        import re
        return bool(re.search(r"\bau\b", t))
    return chk in t


def session_warmup(target, inputs, design: Design, gpu=None) -> list[float]:
    """Repeat a standard 50-token generation until 3 consecutive times are within stable_tol of their median."""
    times = []
    for _ in range(design.max_session_warmups):
        r, _ = generate_once(target, inputs, "fixed50", gpu=gpu)
        times.append(r["time_s"])
        last = times[-3:]
        if len(last) == 3:
            m = sorted(last)[1]
            if max(abs(x - m) / m for x in last) <= design.stable_tol:
                break
    return times


def run_design(design: Design, target, drafts: dict, tokenizer, prepare, out_csv: Path, session_id: str,
               max_minutes: float = 1e9, log=print, on_block_end=None) -> pd.DataFrame:
    """Run (or resume) the randomized block schedule. drafts: {draft_precision: model}.
    A row is appended to out_csv after every run; block 0 (warm-up) rows are written with timed=False.
    on_block_end(block) is called after each completed block (used in Colab to download a partial ZIP)."""
    gpu, steplog = GPU(), StepLogger()
    done = set()
    if out_csv.exists():
        prev = pd.read_csv(out_csv)
        done = set(zip(prev.key, prev.block))
    t_start = time.time()
    cache = {}
    last_block, ran_any = None, False
    for block, pos, c in design.schedule():
        if last_block is not None and block != last_block and ran_any and on_block_end is not None:
            on_block_end(last_block)
            ran_any = False
        last_block = block
        if (c["key"], block) in done:
            continue
        if (time.time() - t_start) / 60 > max_minutes:
            log(f"Clean stop after {max_minutes} min; rerun to resume."); break
        if c["prompt_id"] not in cache:
            cache[c["prompt_id"]] = prepare(PROMPTS[c["prompt_id"]]["text"])
        inputs = cache[c["prompt_id"]]
        draft = None
        if c["mode"] == "SD":
            draft = drafts[c["draft_precision"]]
            set_draft_mode(draft, c["gamma"], c["draft_mode"])
        r, tokens = generate_once(target, inputs, c["length_mode"], draft, steplog, gpu)
        text = tokenizer.decode(tokens, skip_special_tokens=True)
        n, fixed = parse_length(c["length_mode"])
        if fixed:
            assert r["generated_tokens"] == n, f"generated {r['generated_tokens']} != {n}"
        r.update(c, session_id=session_id, target_precision=design.target_precision, block=block, position=pos,
                 timed=block > 0, input_tokens=int(inputs["input_ids"].shape[1]), task=PROMPTS[c["prompt_id"]]["task"],
                 answer_correct=answer_correct(text, c["prompt_id"]), output_text=text, wall_clock=time.time())
        pd.DataFrame([r]).to_csv(out_csv, mode="a", header=not out_csv.exists(), index=False)
        ran_any = True
        log(f"b{block} #{pos:03d} {c['key']}: {r['time_s']:.2f}s  steps={r['n_verify_steps']}  SM={r['sm_mhz_start']}")
    else:
        if ran_any and on_block_end is not None:
            on_block_end(last_block)
    return pd.read_csv(out_csv)


# ---------------------------------------------------------------------------------------------- budget
# Per-token times measured in the v2 QUICK sessions (T4, clock locked at 1590 MHz, 100 tokens, gamma 4), used only to
# print a run-time estimate before a session starts. Standard and confidence drafting: ms/token (medians).
# Fixed drafting: per-round model (t_check + gamma * t_draft) / (1 + sum_{i=1..gamma} a^i), with per-token acceptance a
# fitted from the fixed-drafting runs. Natural-stop configurations are counted at their maximum length (upper bound).
STD_MS = {"FP16": 39.4, "INT8": 155.5, "INT4": 52.9}
CONF_MS = {("FP16", "FP16"): 51, ("INT8", "INT8"): 221, ("INT8", "FP16"): 107, ("INT4", "INT4"): 80, ("INT4", "FP16"): 67}
ROUND = {("FP16", "FP16"): (62, 28, 0.67), ("INT8", "INT8"): (245, 120, 0.68), ("INT8", "FP16"): (212, 23, 0.72),
         ("INT4", "INT4"): (66, 43, 0.61), ("INT4", "FP16"): (84, 26, 0.66)}   # t_check ms, t_draft ms, a


def _ms_per_token(tp, c):
    if c["mode"] == "STANDARD":
        return STD_MS[tp]
    pair = (tp, c["draft_precision"])
    if c["draft_mode"] == "confidence":
        return CONF_MS[pair]
    tc, td, a = ROUND[pair]; g = c["gamma"]
    return (tc + g * td) / (1 + sum(a ** i for i in range(1, g + 1)))


def estimate_minutes(design: Design) -> float:
    n_blocks = design.blocks + (1 if design.warmup_block else 0)
    tot = sum(parse_length(c["length_mode"])[0] * _ms_per_token(design.target_precision, c) / 1000 for c in design.configs())
    return tot * n_blocks / 60 + 3  # + model loading / session warm-up


PRESETS = {
    # ~1 h for all three precisions together (estimate printed by the notebook)
    "QUICK": dict(gammas=(4,), draft_modes=("confidence", "fixed"), length_modes=("fixed100",), blocks=5),
    # approved design (2026-11-03): gamma 2/4/8 x both drafting modes x {fixed 100, natural stop <= 200} x 6 prompts x 5 blocks;
    # no untimed warm-up block (no first-run or order effect in the QUICK sessions; the session warm-up is kept)
    "FULL": dict(gammas=(2, 4, 8), draft_modes=("confidence", "fixed"), length_modes=("fixed100", "natural200"), blocks=5,
                 warmup_block=False),
}

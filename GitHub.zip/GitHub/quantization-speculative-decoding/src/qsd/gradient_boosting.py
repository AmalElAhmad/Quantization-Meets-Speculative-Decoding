"""
Gradient-boosting comparison for the prediction model (report Section 4.2, "Option C", approved 2026-11-04).

=====================================================================================================
1. THE QUESTION IN PLAIN WORDS
=====================================================================================================
The main model M1 (src/qsd/prediction_full.py) is a simple formula built from how speculative decoding works:

        SD time = t_check * rounds + t_draft * proposed tokens

A reader may ask: "Would a flexible machine-learning model, which knows nothing about rounds, do better?"
This file answers that question with ONE standard flexible method: gradient-boosted regression trees.
We use one well-chosen method (not many) so that the comparison is not "try many models and report the best".

=====================================================================================================
2. WHY GRADIENT BOOSTING
=====================================================================================================
Gradient-boosted trees are the usual strong method for small tables with a mix of categories (precision,
drafting mode, prompt) and numbers (gamma, output length). They need no feature scaling and usually match or beat
random forests and support vector regression on this kind of data.

=====================================================================================================
3. TWO INPUT SETS (decided before any test error was computed)
=====================================================================================================
  GB1 (C1)  design factors only: target precision, draft precision, gamma, drafting mode, length mode, prompt,
            and L (number of output tokens).
  GB2 (C2)  GB1 + rounds + proposed tokens, i.e. the SAME information that M1 uses. This is the fair comparison.
Target precision and draft precision are separate inputs (not one "pair" input), so that the draft-swap test can in
principle combine a target and a draft that were never seen together, as the joint model MJ does.
Categories are one-hot encoded; a category never seen in training (e.g. the held-out prompt) becomes all zeros.

=====================================================================================================
4. FAIR TEST DESIGN
=====================================================================================================
  - Same 360 configurations, same splits, same error metrics and bootstrap CIs as M1 (reused from prediction_full).
  - One model is fitted per split fold on ALL training configurations (all pairs together, the pair being an input).
    Per-pair models would leave only 24-60 rows each, which is too little for a tree ensemble.
  - The prediction target is the measured SD time in seconds, the same quantity M1 fits.
  - Hyperparameters are tuned ONLY inside each training set by 5-fold cross-validation (shuffled, seed 742,
    lowest mean absolute error). The test configurations are never used for tuning.
  - Grid: number of trees 100 / 300 / 600, tree depth 2 / 3 / 4, learning rate 0.03 / 0.1 (18 combinations).
    Subsample 0.8 (stochastic boosting), random_state 742, so the result is reproducible.
  - The external pilot -> FULL check is not run for gradient boosting: the pilot configuration table has no
    drafting-mode or length-mode input and includes a prompt and a gamma (6) that FULL does not have, so the two input
    sets above cannot be built from it. M1 needs only rounds and proposed tokens, which both tables have.

=====================================================================================================
5. KNOWN LIMITATIONS (stated in advance)
=====================================================================================================
  - Trees cannot predict outside the range of values seen in training. In the gamma 2 -> 4, 8 split and in the
    draft swap, the test inputs are outside the training range, so failure there is expected by construction.
  - With only 6 prompts, nothing general can be learned about prompt content.
  - Gradient boosting gives no t_check or t_draft, so it cannot support the break-even analysis.
Labels: the outputs are "predicted"; errors are "calculated".
"""
from __future__ import annotations

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import GridSearchCV, KFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder

from .prediction import SEED
from . import prediction_full as pf

# The two input sets of section 3.
CATEGORICAL = ["target_precision", "draft_precision", "draft_mode", "length_mode", "prompt_id"]
NUMERIC_GB1 = ["gamma", "output_length"]
NUMERIC_GB2 = NUMERIC_GB1 + ["n_verify_steps", "proposed_total"]   # + rounds and proposed tokens (as M1)
INPUT_SETS = {"GB1": NUMERIC_GB1, "GB2": NUMERIC_GB2}

# Hyperparameter grid of section 4 (tuned inside each training set only).
GRID = {"gb__n_estimators": [100, 300, 600],
        "gb__max_depth": [2, 3, 4],
        "gb__learning_rate": [0.03, 0.1]}


def _pipeline(numeric: list) -> Pipeline:
    """One-hot encode the categories, pass the numbers through unchanged, then gradient boosting."""
    encode = ColumnTransformer([("cat", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL),
                                ("num", "passthrough", numeric)])
    model = GradientBoostingRegressor(subsample=0.8, random_state=SEED)
    return Pipeline([("encode", encode), ("gb", model)])


def fit_predict(train: pd.DataFrame, test: pd.DataFrame, numeric: list) -> tuple:
    """Tune on the training set by inner 5-fold CV, refit on the whole training set, predict the test set.
    Returns (predictions in seconds, chosen hyperparameters)."""
    search = GridSearchCV(_pipeline(numeric), GRID, scoring="neg_mean_absolute_error",
                          cv=KFold(5, shuffle=True, random_state=SEED), n_jobs=-1)
    search.fit(train[CATEGORICAL + numeric], train.sd_lat_med)
    best = {k.replace("gb__", ""): v for k, v in search.best_params_.items()}
    return search.predict(test[CATEGORICAL + numeric]), best


def run_all(d: pd.DataFrame, m1_pred: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Every gradient-boosting prediction for the six per-pair splits and the draft swap.

    m1_pred is the output of prediction_full.run_all (same splits); its B0/B0x and M1/MJ predictions are kept so that
    every table compares the models on exactly the same test configurations.
    Returns (predictions with pred_GB1 and pred_GB2 added, chosen hyperparameters per split fold).
    """
    folds = [(name, i, tr, te) for name, fs in pf.splits(d).items() for i, (tr, te) in enumerate(fs)]
    for i, (target, draft) in enumerate(pf.SWAP_TEST_PAIRS):          # draft swap: one held-out pair per fold
        is_test = (d.target_precision == target) & (d.draft_precision == draft)
        folds.append(("draft_swap", i, ~is_test, is_test))

    key = ["split", "fold", "target_precision", "draft_precision", "draft_mode", "gamma", "prompt_id", "length_mode"]
    parts, params = [], []
    for name, i, train_mask, test_mask in folds:
        test = d[test_mask].copy()
        test["split"], test["fold"] = name, i
        for model, numeric in INPUT_SETS.items():
            test[f"pred_{model}"], best = fit_predict(d[train_mask], test, numeric)
            params.append(dict(split=name, fold=i, model=model, n_train=int(train_mask.sum()), **best))
        parts.append(test[key + ["pred_GB1", "pred_GB2"]])

    gb = pd.concat(parts, ignore_index=True)
    out = m1_pred.merge(gb, on=key, how="inner", validate="one_to_one")
    assert len(out) == len(m1_pred), "every M1 test configuration must have a gradient-boosting prediction"
    return out, pd.DataFrame(params)

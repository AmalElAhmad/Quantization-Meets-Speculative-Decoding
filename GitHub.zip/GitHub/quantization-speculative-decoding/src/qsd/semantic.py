"""Quality of generated text vs a reference, at three levels (computed after the timed runs, from the saved texts):
  exact token match (output_hash), ROUGE-L (same wording), BERTScore F1 and embedding cosine (same meaning).
References: (a) standard decoding of the same target precision, same prompt and length mode (is SD lossless?);
            (b) FP16 standard decoding of the same prompt and length mode (effect of quantization).
The scorers are passed in, so the pairing logic can be tested without downloading models."""
from __future__ import annotations

import pandas as pd

from .full import rouge_l


def build_pairs(r: pd.DataFrame) -> pd.DataFrame:
    """One row per (configuration, reference). Outputs are deterministic within a configuration, so one text each."""
    t = r[r.timed].drop_duplicates(["target_precision", "key"])
    std = t[t["mode"] == "STANDARD"]
    same = std.set_index(["target_precision", "prompt_id", "length_mode"]).output_text
    fp16 = std[std.target_precision == "FP16"].set_index(["prompt_id", "length_mode"]).output_text
    rows = []
    for _, x in t.iterrows():
        refs = []
        k = (x.target_precision, x.prompt_id, x.length_mode)
        if x["mode"] == "SD" and k in same.index:
            refs.append(("same_precision_standard", same[k]))
        if (x.prompt_id, x.length_mode) in fp16.index and not (x.target_precision == "FP16" and x["mode"] == "STANDARD"):
            refs.append(("fp16_standard", fp16[(x.prompt_id, x.length_mode)]))
        for name, ref in refs:
            rows.append(dict(target_precision=x.target_precision, mode=x["mode"], draft_precision=x.draft_precision,
                             draft_mode=x.draft_mode, gamma=x.gamma, prompt_id=x.prompt_id, task=x.task, length_mode=x.length_mode,
                             key=x.key, reference=name, candidate=str(x.output_text), reference_text=str(ref)))
    return pd.DataFrame(rows)


def score(pairs: pd.DataFrame, bertscore_f1, embed) -> pd.DataFrame:
    """bertscore_f1(cands, refs) -> list[float]; embed(texts) -> 2-D array of L2-normalised embeddings."""
    import numpy as np
    p = pairs.copy()
    p["rouge_l"] = [rouge_l(a, b) for a, b in zip(p.candidate, p.reference_text)]
    p["bertscore_f1"] = list(bertscore_f1(list(p.candidate), list(p.reference_text)))
    ea, eb = np.asarray(embed(list(p.candidate))), np.asarray(embed(list(p.reference_text)))
    p["embedding_cosine"] = (ea * eb).sum(1)
    p["identical_text"] = p.candidate == p.reference_text
    return p

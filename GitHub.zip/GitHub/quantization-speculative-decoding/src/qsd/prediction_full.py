"""
Prediction model on the FULL experiment (report Section 4.2): a model that PREDICTS the time of a speculative-decoding (SD) run.

=====================================================================================================
1. THE IDEA IN PLAIN WORDS
=====================================================================================================
An SD run is a sequence of ROUNDS. In every round:
    (a) the small DRAFT model proposes a few tokens, one after the other, and
    (b) the large TARGET model CHECKS all proposed tokens in a single forward pass and keeps the accepted ones.

So the time of a run should be close to

        T_SD  =  t_check * (number of rounds)  +  t_draft * (number of proposed tokens)

    t_check  = time of one target check (seconds per round)            -> fitted from data
    t_draft  = time for the draft model to propose one token (seconds)  -> fitted from data
    rounds, proposed tokens = counted (measured) in each run's step log

Both counts are logged in every FULL run, so the model only has to learn the two per-round times. Each
precision pair (for example "INT8 target + FP16 draft") gets its own two numbers, because quantization changes
how fast each model runs.

How we judge the model: we fit t_check and t_draft on SOME configurations (the training set). We then predict
the SD time of OTHER configurations that the fit never saw (the test set) and compare the predictions with the
measured times. If the model is useful, it should beat simple baselines that ignore the round structure.

Important for interpretation: the check pass processes every proposed token, so the fitted t_draft also contains
the target's extra check time per proposed token. It is an EFFECTIVE draft time, and rho = t_draft / t_check is an
effective ratio. The predictions are not affected; only the meaning of the coefficient is.

=====================================================================================================
1b. WHY THIS METHOD (and not a black-box machine-learning model)
=====================================================================================================
Linear regression is a supervised machine-learning method. The choice made here is the MODEL CLASS: a physics-
informed linear model instead of a flexible one (random forest, gradient boosting, SVR, neural network). Reasons:
  1 Known structure. An SD run is a sum over rounds, so the form of the equation is given by the mechanism and only
    two constants per pair are unknown.
  2 Interpretable output. The coefficients are physical (ms per check, ms per draft token) and are needed for the
    break-even analysis (rho, rho*). A black-box model gives a time, not these quantities.
  3 Extrapolation. Most tests predict conditions outside the training range (new gamma, new drafting mode, new
    output length, unseen precision pair). Tree models cannot predict outside the training range; an RBF-kernel
    SVR drifts back to the training mean. The mechanistic model extrapolates by construction.
  4 Small data. 72 configurations per pair (360 in total) but only 6 prompts and 5 pairs. Two coefficients per pair
    are well determined; a flexible model would overfit.
  5 Noise floor. Run-to-run variation is about 4% (median CV). Held-out-prompt errors of M1: 66% within one CV, 90%
    within two. The two remaining systematic patterns (drafting mode about +-1.7%, gamma 2 about +1.8%) have physical
    causes and are handled by an explicit term (M1m), not by a black box.
  6 Literature. The analytical SD speedup models (Leviathan et al. 2023; Chen et al. 2023) use the same structure
    (tokens per round, draft/target time ratio), so the results stay comparable.
Where theory can add more: M1 reads rounds and proposed tokens from the run. Predicting them BEFORE the run needs a
model of acceptance; the analytical model MA (section 5, step 7) does this from theory, not from learned features.

=====================================================================================================
2. TERMS USED BELOW
=====================================================================================================
configuration  one combination of target precision, draft precision, gamma, drafting mode, prompt and output
               length mode. FULL has 360 SD configurations (5 pairs x 72). Each was run 5 times; we use the
               median time of the 5 runs (column sd_lat_med; "measured").
gamma          maximum number of draft tokens per round (2, 4 or 8).
drafting mode  "confidence" (the draft stops early when it is unsure) or "fixed" (always proposes gamma tokens).
length mode    "fixed100" (exactly 100 output tokens) or "natural200" (stop at end-of-sentence, max 200).
L              number of output tokens of the configuration (column output_length).

=====================================================================================================
3. MODELS (all approved by the user on 2026-11-04, BEFORE any test error was looked at)
=====================================================================================================
Main model
  M1   T = t_check * rounds + t_draft * proposed. One fit per precision pair. Non-negative least squares
       (NNLS): both times must be >= 0, and there is no intercept (zero rounds -> zero time).
Sensitivity variants (to check whether the main choices matter)
  M1i  M1 plus an intercept (ordinary least squares); allows a fixed time per run, e.g. for the prompt pass.
  M1m  M1 fitted separately for each drafting mode inside a pair. Confidence drafting re-tunes its threshold
       every round, so its time per round might be larger than with fixed drafting.
Baselines (what M1 has to beat)
  B0   naive per-token rate: T = r * L, with r = total time / total tokens of the pair's training configs.
  B0g  same, but r is computed per pair x gamma x drafting mode (a stronger naive baseline). If that group
       does not exist in training (e.g. gamma 8 when training has only gamma 2), it falls back to B0.
  M2   "a priori" model (pilot definition): M1's two times, but rounds and proposed tokens are not taken from
       the run. They are estimated from training ratios (tokens per round, proposed per round at the same gamma).
       It needs no SD run of the test configuration. Note that it is again a constant rate times L.
  majority direction: for the faster/slower question, always answer the pair's most common training direction.
Precision-transfer model (used only in the draft-swap split)
  MJ   one JOINT fit over several pairs: t_check depends only on the TARGET precision and t_draft only on the
       DRAFT precision, so a pair that was never seen can be assembled from parts seen in other pairs.
  B0x  its naive baseline: per-token rate of the matched pair with the same target (e.g. INT8+INT8 for INT8+FP16).

=====================================================================================================
4. TEST SPLITS (train -> test)
=====================================================================================================
  held_out_prompt      6 folds: each prompt is predicted from the other 5 prompts.
  gamma2_to_4_8        train gamma 2 only    -> test gamma 4 and 8.
  gamma24_to_8         train gamma 2 and 4   -> test gamma 8.
  fixed_to_confidence  train fixed drafting  -> test confidence drafting.
  confidence_to_fixed  the reverse.
  fixed100_to_natural  train 100-token runs  -> test natural-stop runs.
  draft_swap           hold out INT8+FP16 (or INT4+FP16) completely; predict it with MJ fitted on the other 4 pairs.
  (external check, pilot -> FULL, is computed by full.external_test and reported next to these.)

=====================================================================================================
5. A-PRIORI PREDICTION WITH THE ANALYTICAL ACCEPTANCE MODEL (MA, approved 2026-11-04)
=====================================================================================================
  MA   rounds and proposed tokens come from theory instead of the run: each draft token is accepted with the same
       probability alpha (estimated by maximum likelihood from a reference run's step log), so a round produces
       k = (1 - alpha^(gamma+1)) / (1 - alpha) tokens on average; rounds = L / k, proposed = gamma * rounds, and
       T = t_check * rounds + t_draft * proposed with regression times. Fixed drafting only.
  B0ref  naive baseline with the same information: per-token rate of the gamma-2 reference run x L.
  Tests: MA_S1_new_gamma (alpha from gamma 2 of the same prompt -> gamma 4, 8) and MA_S2_new_prompt (alpha from the
  other 5 prompts). Details in the comment block of step 7.

=====================================================================================================
6. LABELS
=====================================================================================================
measured   = times, token and round counts recorded in the runs
calculated = rates, ratios, fitted per-round times, errors, confidence intervals
predicted  = outputs of the models above (columns pred_<model>)
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.optimize import nnls

# Reused from the pilot code (same fitting routine, same bootstrap settings, same metric definitions).
from .prediction import PAIRS, SEED, B, fit_round_times, round_stats, _metrics
from . import full

# Order in which models appear in every table.
PER_PAIR_MODELS = ["B0", "B0g", "M2", "M1", "M1i", "M1m"]
SWAP_MODELS = ["B0x", "MJ"]
MA_MODELS = ["B0ref", "MA"]      # analytical acceptance test (section 6 of the docstring, step 7 below)
# Mixed pairs that the draft-swap split can test (see section 3, MJ). The three other pairs are the ONLY source
# of one of their own coefficients, so they cannot be held out.
SWAP_TEST_PAIRS = [("INT8", "FP16"), ("INT4", "FP16")]
PRECISIONS = ["FP16", "INT8", "INT4"]
GAMMAS = [2, 4, 8]
DRAFT_MODES = ["confidence", "fixed"]


# =====================================================================================================
# Step 1 - data
# =====================================================================================================
def load_configs(runs_folder: str) -> pd.DataFrame:
    """Return the 360 FULL SD configurations, one row each.

    Reuses full.speedups(), which already computes, per configuration, the median SD time, the median standard time
    (same precision, prompt and length mode), the speedup with its bootstrap CI and verdict, and the step counts.
    Adds the run-to-run coefficient of variation (run_cv) of the 5 timed runs, used as the noise floor.
    Columns are renamed to the pilot names so the pilot fitting code can be reused unchanged:
        sd_time_s -> sd_lat_med,  generated_tokens -> output_length.
    """
    runs = full.load_runs(runs_folder)
    configs = full.speedups(runs)

    # run-to-run CV (std / mean of the 5 timed runs) of every SD configuration
    sd_runs = runs[runs.timed & (runs["mode"] == "SD")]
    id_cols = ["target_precision", "draft_precision", "draft_mode", "gamma", "prompt_id", "length_mode"]
    run_cv = (sd_runs.groupby(id_cols).time_s
              .agg(lambda x: x.std() / x.mean())
              .rename("run_cv").reset_index())
    configs = configs.merge(run_cv, on=id_cols, how="left")

    # per-round step log [[proposed, accepted], ...] of the configuration. Outputs are deterministic (identical in
    # all 5 runs, checked in V1_checks.csv), so the log of the first timed run represents the configuration.
    logs = sd_runs.drop_duplicates(id_cols)[id_cols + ["step_log"]]
    configs = configs.merge(logs, on=id_cols, how="left")

    configs = configs.rename(columns={"sd_time_s": "sd_lat_med", "generated_tokens": "output_length"})
    configs["gamma"] = configs.gamma.astype(int)
    configs["pair"] = configs.target_precision + "+" + configs.draft_precision

    # sanity checks: every configuration present, with its noise and step counts
    assert len(configs) == 360, len(configs)
    assert configs.run_cv.notna().all()
    assert configs[["n_verify_steps", "proposed_total"]].notna().all().all()
    return configs.reset_index(drop=True)


# =====================================================================================================
# Step 2 - fit on the training configurations, predict the test configurations (one precision pair at a time)
# =====================================================================================================
def _per_token_rate(train: pd.DataFrame) -> float:
    """Naive rate r (seconds per output token) = total measured time / total output tokens."""
    return train.sd_lat_med.sum() / train.output_length.sum()


def _round_model(times: dict, rounds, proposed, intercept: float = 0.0):
    """The core formula: T = intercept + t_check * rounds + t_draft * proposed."""
    return intercept + times["t_verify"] * rounds + times["t_draft"] * proposed


def predict_split(d: pd.DataFrame, train_mask: pd.Series, test_mask: pd.Series) -> pd.DataFrame:
    """For every precision pair: fit all per-pair models on the training rows, predict the test rows.

    Returns the test rows with one column pred_<model> per model, plus the fitted t_check / t_draft (ms) of M1.
    """
    out = []
    for target, draft in PAIRS:
        in_pair = (d.target_precision == target) & (d.draft_precision == draft)
        train = d[in_pair & train_mask]
        test = d[in_pair & test_mask].copy()
        if test.empty:
            continue

        # ---- B0: naive per-token rate of the whole pair
        r = _per_token_rate(train)
        test["pred_B0"] = r * test.output_length

        # ---- B0g: naive per-token rate of the same gamma and drafting mode (falls back to B0's rate)
        group_rates = {key: _per_token_rate(g) for key, g in train.groupby(["gamma", "draft_mode"])}
        test["pred_B0g"] = [group_rates.get((gamma, mode), r) * L
                            for gamma, mode, L in zip(test.gamma, test.draft_mode, test.output_length)]

        # ---- M1: per-round model, NNLS, no intercept (main model)
        m1 = fit_round_times(train)  # returns {"a": 0, "t_verify": t_check, "t_draft": t_draft} in seconds
        test["pred_M1"] = _round_model(m1, test.n_verify_steps, test.proposed_total)

        # ---- M1i: same with an intercept (sensitivity)
        m1i = fit_round_times(train, intercept=True)
        test["pred_M1i"] = _round_model(m1i, test.n_verify_steps, test.proposed_total, intercept=m1i["a"])

        # ---- M2: M1's times, but rounds and proposed tokens estimated from training ratios
        #      k = tokens per round, p = proposed tokens per round (same gamma if it is in training)
        #      rounds_hat = L / k,  proposed_hat = p * rounds_hat
        k_p = np.array([round_stats(train, gamma) for gamma in test.gamma])
        rounds_hat = test.output_length / k_p[:, 0]
        proposed_hat = k_p[:, 1] * rounds_hat
        test["pred_M2"] = _round_model(m1, rounds_hat, proposed_hat)

        # ---- M1m: M1 fitted separately per drafting mode (sensitivity). Not defined when the test mode is absent
        #      from training (the two drafting-mode transfer splits); those rows stay NaN and M1m is left out there.
        test["pred_M1m"] = np.nan
        for mode in test.draft_mode.unique():
            train_mode = train[train.draft_mode == mode]
            if len(train_mode) >= 2:
                m1m = fit_round_times(train_mode)
                rows = test.draft_mode == mode
                test.loc[rows, "pred_M1m"] = _round_model(m1m, test.n_verify_steps[rows], test.proposed_total[rows])

        test["t_check_ms"] = 1000 * m1["t_verify"]
        test["t_draft_ms"] = 1000 * m1["t_draft"]
        test["n_train"] = len(train)
        out.append(test)
    return pd.concat(out, ignore_index=True)


def splits(d: pd.DataFrame) -> dict:
    """The six per-pair splits of section 4. Each entry is a list of folds; a fold is (train_mask, test_mask)."""
    return {
        "held_out_prompt": [(d.prompt_id != p, d.prompt_id == p) for p in sorted(d.prompt_id.unique())],
        "gamma2_to_4_8": [(d.gamma == 2, d.gamma > 2)],
        "gamma24_to_8": [(d.gamma < 8, d.gamma == 8)],
        "fixed_to_confidence": [(d.draft_mode == "fixed", d.draft_mode == "confidence")],
        "confidence_to_fixed": [(d.draft_mode == "confidence", d.draft_mode == "fixed")],
        "fixed100_to_natural": [(d.length_mode == "fixed100", d.length_mode == "natural200")],
    }


# =====================================================================================================
# Step 3 - precision transfer (draft swap) with the joint model MJ
# =====================================================================================================
def fit_joint(train: pd.DataFrame) -> dict:
    """Joint fit over all pairs in `train`:
        T = t_check[target precision] * rounds + t_draft[draft precision] * proposed      (NNLS, no intercept)
    Implemented as one regression with 6 columns. Column "check_INT8" holds the round count of a configuration
    if its target is INT8 and 0 otherwise, and likewise for the other precisions and for the draft columns.
    A coefficient whose column is all zero in training cannot be estimated and is returned as NaN.
    """
    names = [f"check_{p}" for p in PRECISIONS] + [f"draft_{p}" for p in PRECISIONS]
    X = np.zeros((len(train), len(names)))
    for j, p in enumerate(PRECISIONS):
        X[:, j] = np.where(train.target_precision == p, train.n_verify_steps, 0)
        X[:, len(PRECISIONS) + j] = np.where(train.draft_precision == p, train.proposed_total, 0)
    estimable = X.any(axis=0)
    coef = np.full(len(names), np.nan)
    coef[estimable], _ = nnls(X[:, estimable], train.sd_lat_med.to_numpy(float))
    return dict(zip(names, coef))


def draft_swap(d: pd.DataFrame) -> pd.DataFrame:
    """Hold out one FP16-draft mixed pair completely and predict it from the other four pairs.

    Example, test pair INT8+FP16:
        t_check[INT8] is learned from INT8+INT8 runs,
        t_draft[FP16] is learned from FP16+FP16 and INT4+FP16 runs.
    No run of INT8+FP16 is used for fitting; its rounds and proposed tokens are taken from its own logs (as in M1).
    """
    out = []
    for fold, (target, draft) in enumerate(SWAP_TEST_PAIRS):
        is_test = (d.target_precision == target) & (d.draft_precision == draft)
        train, test = d[~is_test], d[is_test].copy()

        joint = fit_joint(train)
        t_check, t_draft = joint[f"check_{target}"], joint[f"draft_{draft}"]
        test["pred_MJ"] = t_check * test.n_verify_steps + t_draft * test.proposed_total

        # B0x: per-token rate of the matched pair with the same target (e.g. INT8+INT8)
        same_target = d[(d.target_precision == target) & (d.draft_precision == target)]
        test["pred_B0x"] = _per_token_rate(same_target) * test.output_length

        test["t_check_ms"], test["t_draft_ms"], test["n_train"] = 1000 * t_check, 1000 * t_draft, len(train)
        test["split"], test["fold"] = "draft_swap", fold
        out.append(test)
    return pd.concat(out, ignore_index=True)


def run_all(d: pd.DataFrame) -> pd.DataFrame:
    """Every prediction of every split, stacked (one row per test configuration per split)."""
    parts = []
    for name, folds in splits(d).items():
        for fold, (train_mask, test_mask) in enumerate(folds):
            p = predict_split(d, train_mask, test_mask)
            p["split"], p["fold"] = name, fold
            parts.append(p)
    parts.append(draft_swap(d))
    return pd.concat(parts, ignore_index=True)


# =====================================================================================================
# Step 4 - errors
# =====================================================================================================
def models_defined(g: pd.DataFrame) -> list:
    """Models that have a prediction for EVERY row of g (e.g. M1m is absent from the drafting-mode transfer splits)."""
    order = ["B0", "B0x", "B0ref", "B0g", "M2", "MA", "M1", "M1i", "M1m", "MJ", "GB1", "GB2"]  # baselines first, then models (GB = gradient boosting, src/qsd/gradient_boosting.py)
    return [m for m in order if f"pred_{m}" in g and g[f"pred_{m}"].notna().all()]


def error_table(pred: pd.DataFrame, by=("split",), ci: bool = True) -> pd.DataFrame:
    """Prediction errors per group (default: per split).

    Point metrics (calculated, error = predicted - measured):
        MAE  = mean |error| (s);  RMSE = sqrt(mean error^2) (s);  MAPE = mean |error| / measured (%);
        bias = mean error (s; negative = model predicts too short).
    noise_cv_median_pct: median run-to-run CV of the test configurations. It is the noise floor; an error close
        to it cannot be reduced by a better model.
    With ci=True: 95% percentile bootstrap CIs (5000 resamples of the test configurations, seed 742), and the paired
        difference dMAPE = MAPE(model) - MAPE(naive baseline) on the SAME resamples (negative = better than baseline).
        The naive baseline is B0, or B0x in the draft-swap split.
    """
    rng = np.random.default_rng(SEED)
    rows = []
    for key, g in pred.groupby(list(by), sort=False):
        key = key if isinstance(key, tuple) else (key,)
        measured = g.sd_lat_med.to_numpy()
        models = models_defined(g)
        baseline = next(b for b in ["B0", "B0x", "B0ref"] if b in models)  # the naive baseline of this split
        resamples = rng.integers(0, len(g), (B, len(g))) if ci else None

        for m in models:
            predicted = g[f"pred_{m}"].to_numpy()
            row = dict(zip(by, key), model=m, n_test=len(g), **_metrics(measured, predicted),
                       noise_cv_median_pct=100 * g.run_cv.median())
            if ci:
                abs_err = np.abs(predicted - measured)
                pct_err = 100 * abs_err / measured
                boot_mae = abs_err[resamples].mean(axis=1)
                boot_rmse = np.sqrt((abs_err ** 2)[resamples].mean(axis=1))
                boot_mape = pct_err[resamples].mean(axis=1)
                for name, values in [("MAE_s", boot_mae), ("RMSE_s", boot_rmse), ("MAPE_pct", boot_mape)]:
                    row[f"{name}_lo"], row[f"{name}_hi"] = np.percentile(values, [2.5, 97.5])
                if m != baseline:
                    base_pct = 100 * np.abs(g[f"pred_{baseline}"].to_numpy() - measured) / measured
                    row["baseline"] = baseline
                    row["dMAPE_vs_baseline"] = pct_err.mean() - base_pct.mean()
                    row["dMAPE_lo"], row["dMAPE_hi"] = np.percentile(boot_mape - base_pct[resamples].mean(axis=1), [2.5, 97.5])
            rows.append(row)
    return pd.DataFrame(rows)


def direction_table(pred: pd.DataFrame, d: pd.DataFrame) -> pd.DataFrame:
    """Does the model get the direction right (SD faster or slower than standard decoding)?

    measured direction : measured standard time / measured SD time > 1  (the measured speedup)
    predicted direction: measured standard time / predicted SD time > 1  (the derived speedup)
    Counted for all test configurations and for those with a clear verdict (speedup CI excludes 1).
    Majority baseline: always answer the most common measured direction of the pair in the training configurations
    of the same fold (draft swap: of the matched pair with the same target precision).
    """
    # most common training direction, per (split, fold, pair)
    majority = {}
    for split_name, folds in splits(d).items():
        for fold, (train_mask, _) in enumerate(folds):
            for pair, g in d[train_mask].groupby("pair"):
                majority[(split_name, fold, pair)] = bool((g.speedup > 1).mean() > 0.5)
    for fold, (target, draft) in enumerate(SWAP_TEST_PAIRS):
        g = d[(d.target_precision == target) & (d.draft_precision == target)]
        majority[("draft_swap", fold, f"{target}+{draft}")] = bool((g.speedup > 1).mean() > 0.5)

    rows = []
    for split_name in pred.split.unique():
        g = pred[pred.split == split_name]
        faster_measured = (g.speedup > 1).to_numpy()
        clear = (g.verdict != "no clear difference").to_numpy()
        faster_majority = np.array([majority[(split_name, f, p)] for f, p in zip(g.fold, g.pair)])
        for m in [m for m in models_defined(g) if m.startswith("M")]:  # time models only, not the naive rates
            faster_predicted = (g.std_time_s / g[f"pred_{m}"] > 1).to_numpy()
            hit = faster_predicted == faster_measured
            hit_majority = faster_majority == faster_measured
            rows.append(dict(split=split_name, model=m, n=len(g), correct=int(hit.sum()),
                             n_clear=int(clear.sum()), correct_clear=int(hit[clear].sum()),
                             majority_correct=int(hit_majority.sum()), majority_correct_clear=int(hit_majority[clear].sum())))
    return pd.DataFrame(rows)


# =====================================================================================================
# Step 5 - fitted per-round times on all data (descriptive, table P1)
# =====================================================================================================
def _r2(measured, predicted) -> float:
    """Share of the variance of the measured times explained by the fit (in-sample)."""
    measured = np.asarray(measured)
    return 1 - ((measured - predicted) ** 2).sum() / ((measured - measured.mean()) ** 2).sum()


def coefficient_table(d: pd.DataFrame) -> pd.DataFrame:
    """t_check and t_draft (ms) fitted on ALL configurations of each pair (calculated), for M1, M1i, M1m and the
    joint model. rho = t_draft / t_check (draft time per proposed token relative to one check)."""
    rows = []
    for target, draft in PAIRS:
        g = d[(d.target_precision == target) & (d.draft_precision == draft)]
        fits = [("M1", g, False), ("M1i", g, True),
                ("M1m confidence", g[g.draft_mode == "confidence"], False), ("M1m fixed", g[g.draft_mode == "fixed"], False)]
        for name, sub, with_intercept in fits:
            c = fit_round_times(sub, intercept=with_intercept)
            fitted = _round_model(c, sub.n_verify_steps, sub.proposed_total, intercept=c["a"])
            rows.append(dict(model=name, target_precision=target, draft_precision=draft, n=len(sub), intercept_s=c["a"],
                             t_check_ms=1000 * c["t_verify"], t_draft_ms=1000 * c["t_draft"],
                             rho=c["t_draft"] / c["t_verify"], r2=_r2(sub.sd_lat_med, fitted)))
    joint = fit_joint(d)  # one fit on all 360 configurations
    for target, draft in PAIRS:
        g = d[(d.target_precision == target) & (d.draft_precision == draft)]
        tc, td = joint[f"check_{target}"], joint[f"draft_{draft}"]
        rows.append(dict(model="Joint", target_precision=target, draft_precision=draft, n=len(g), intercept_s=0.0,
                         t_check_ms=1000 * tc, t_draft_ms=1000 * td, rho=td / tc,
                         r2=_r2(g.sd_lat_med, tc * g.n_verify_steps + td * g.proposed_total)))
    return pd.DataFrame(rows)


def split_diagnostics(d: pd.DataFrame) -> pd.DataFrame:
    """For every split, fold and pair: what the training set looked like and what M1 learned from it (calculated).

    corr_rounds_proposed: correlation between rounds and proposed tokens in the TRAINING configurations.
        Close to 1 means the two counts move together, so the fit cannot tell t_check and t_draft apart well
        (only their combination is learned). Example: with gamma 2 and fixed drafting, proposed = 2 x rounds exactly.
    proposed_per_round_min/max: range of p in training. A narrow range has the same effect.
    """
    rows = []
    for split_name, folds in splits(d).items():
        for fold, (train_mask, _) in enumerate(folds):
            for target, draft in PAIRS:
                tr = d[train_mask & (d.target_precision == target) & (d.draft_precision == draft)]
                c = fit_round_times(tr)
                p = tr.proposed_total / tr.n_verify_steps
                rows.append(dict(split=split_name, fold=fold, target_precision=target, draft_precision=draft, n_train=len(tr),
                                 corr_rounds_proposed=np.corrcoef(tr.n_verify_steps, tr.proposed_total)[0, 1],
                                 proposed_per_round_min=p.min(), proposed_per_round_max=p.max(),
                                 t_check_ms=1000 * c["t_verify"], t_draft_ms=1000 * c["t_draft"]))
    return pd.DataFrame(rows)


# =====================================================================================================
# Step 6 - break-even analysis
# =====================================================================================================
# Why SD can be faster: per output token,
#     SD time       = (t_check + p * t_draft) / k        k = tokens produced per round, p = draft tokens per round
#     standard time = t_s                                (one target pass per token)
# SD is faster when (t_check + p * t_draft) / k < t_s. Dividing by t_check and writing rho = t_draft / t_check:
#     rho  <  rho* = (k * t_s / t_check - 1) / p
# rho  : how expensive one draft token is compared with one check (a property of the hardware and precisions)
# rho* : the largest rho that still gives a speedup (depends on how many tokens each round produces)
def _break_even_cell(cell: pd.DataFrame, t_check: float, t_draft: float):
    """rho, rho*, k, p, t_s for one group of configurations (calculated)."""
    t_s = cell.std_time_s.sum() / cell.std_generated_tokens.sum()  # standard time per token, same prompts/lengths
    k = cell.output_length.sum() / cell.n_verify_steps.sum()
    p = cell.proposed_total.sum() / cell.n_verify_steps.sum()
    rho = t_draft / t_check
    rho_star = (k * t_s / t_check - 1) / p
    return rho, rho_star, k, p, t_s


def break_even(d: pd.DataFrame, boot: int = B) -> pd.DataFrame:
    """Break-even table: one row per pair x gamma x drafting mode (12 configurations each) + one pooled row per pair.

    t_check and t_draft come from the M1 fit on all 72 configurations of the pair; k, p and t_s from the row's own
    configurations. 95% CIs: stratified bootstrap. Configurations are resampled within each gamma x mode cell, then
    t_check and t_draft are refitted and every row is recomputed.
    """
    rng = np.random.default_rng(SEED)
    rows = []
    for target, draft in PAIRS:
        g = d[(d.target_precision == target) & (d.draft_precision == draft)].reset_index(drop=True)
        cell_keys = [(gamma, mode) for gamma in GAMMAS for mode in DRAFT_MODES]
        cell_index = [np.flatnonzero((g.gamma == gamma) & (g.draft_mode == mode)) for gamma, mode in cell_keys]

        def all_rows(data, index):
            """Fit t_check/t_draft on `data`, then compute every cell row plus the pooled row."""
            c = fit_round_times(data)
            values = [_break_even_cell(data.iloc[ix], c["t_verify"], c["t_draft"]) for ix in index]
            values.append(_break_even_cell(data, c["t_verify"], c["t_draft"]))
            return np.array(values), c

        point, c = all_rows(g, cell_index)

        # stratified bootstrap
        boot_values = []
        sizes = [len(ix) for ix in cell_index]
        starts = np.cumsum([0] + sizes)
        new_index = [np.arange(starts[i], starts[i + 1]) for i in range(len(sizes))]
        for _ in range(boot):
            picked = np.concatenate([ix[rng.integers(0, len(ix), len(ix))] for ix in cell_index])
            boot_values.append(all_rows(g.iloc[picked].reset_index(drop=True), new_index)[0])
        boot_values = np.array(boot_values)  # shape: (boot, cells + 1, 5)

        for i, (gamma, mode) in enumerate(cell_keys + [("all", "all")]):
            sub = g if gamma == "all" else g.iloc[cell_index[i]]
            rho, rho_star, k, p, t_s = point[i]
            b_rho, b_star = boot_values[:, i, 0], boot_values[:, i, 1]
            rows.append(dict(target_precision=target, draft_precision=draft, gamma=gamma, draft_mode=mode, n=len(sub),
                             t_check_ms=1000 * c["t_verify"], t_draft_ms=1000 * c["t_draft"],
                             t_standard_ms_per_token=1000 * t_s, tokens_per_round=k, proposed_per_round=p,
                             rho=rho, rho_lo=np.percentile(b_rho, 2.5), rho_hi=np.percentile(b_rho, 97.5),
                             rho_star=rho_star, rho_star_lo=np.percentile(b_star, 2.5), rho_star_hi=np.percentile(b_star, 97.5),
                             margin=rho_star - rho, margin_lo=np.percentile(b_star - b_rho, 2.5),
                             margin_hi=np.percentile(b_star - b_rho, 97.5),
                             measured_median_speedup=sub.speedup.median(), configs_faster=int((sub.speedup > 1).sum())))
    return pd.DataFrame(rows)


# =====================================================================================================
# Step 7 - analytical acceptance model MA: predicting SD time WITHOUT a run at the target setting
# =====================================================================================================
# Why: M1 reads rounds and proposed tokens from the SD run itself, so it explains a run but cannot replace it.
# MA predicts those two counts from theory (Leviathan et al. 2023, Sec. 3.1):
#   assumption  every draft token is accepted with the same probability alpha, independently of the others
#   result      expected tokens produced per round   k = (1 - alpha^(gamma+1)) / (1 - alpha)
#               (the accepted draft tokens + the one token the target adds in every round)
# Then  rounds = L / k,  proposed = gamma * rounds,  T = t_check * rounds + t_draft * proposed  (M1's regression times).
# Scope: FIXED drafting only. The theory assumes gamma proposed tokens in every round, which holds in 97.9% of the
# fixed-drafting rounds of FULL (last rounds excluded). Confidence drafting stops at a learned threshold, for which
# no closed form exists, so it is not covered.
# L = output tokens of the STANDARD run of the same precision, prompt and length mode (known without running SD).
#
# Tests (approved 2026-11-04):
#   S1 "new gamma, same prompt": alpha from the gamma-2 fixed run of the same pair, prompt and length mode;
#      t_check, t_draft = pair calibration (M1 fitted on the OTHER 5 prompts of the pair, all gamma and modes; the test
#      prompt is never used for the times). Test rows: fixed drafting, gamma 4 and 8 (120 configurations).
#      Baselines: B0ref = per-token rate of the same gamma-2 reference run x L (same information as MA, ignores gamma);
#                 B0g  = per-token rate of the calibration configs with the same gamma and mode x L.
#   S2 "new prompt": alpha from the fixed runs of the other 5 prompts of the pair at the same gamma; times from M1 on the
#      other 5 prompts. Test rows: fixed drafting, all gamma (180 configurations, 6 folds).
#      Baselines: B0, B0g, M2 of the held-out-prompt split on the same rows.
#   In both tests M1 (step counts read from the run, same times) is shown as the reference.

def _rounds(step_log, include_last: bool = False):
    """Parse a step log '[[proposed, accepted], ...]' into a list of (proposed, accepted) rounds."""
    import json
    r = [tuple(x) for x in json.loads(step_log)]
    return r if include_last else r[:-1]   # the last round is cut short by the length limit or end of text


def alpha_mle(step_logs) -> float:
    """Maximum-likelihood acceptance probability alpha from per-round logs (last rounds excluded).

    Under the equal-probability assumption the number accepted in a round is a geometric count stopped at the number
    proposed: a round that accepts a tokens and then rejects one contributes a successes and 1 failure; a round that
    accepts everything it proposed contributes successes only. Hence  alpha = successes / (successes + failures).
    """
    successes = failures = 0
    for log in step_logs:
        for proposed, accepted in _rounds(log):
            successes += accepted
            failures += int(accepted < proposed)
    return successes / (successes + failures)


def tokens_per_round(alpha: float, gamma: int) -> float:
    """k = (1 - alpha^(gamma+1)) / (1 - alpha); equals gamma + 1 when alpha = 1."""
    return gamma + 1.0 if alpha >= 1 else (1 - alpha ** (gamma + 1)) / (1 - alpha)


def _ma_time(times: dict, alpha: float, gamma: int, L: float):
    """MA prediction: counts from theory, times from the regression. Returns (T, k, rounds, proposed)."""
    k = tokens_per_round(alpha, gamma)
    rounds = L / k
    proposed = gamma * rounds
    return times["t_verify"] * rounds + times["t_draft"] * proposed, k, rounds, proposed


def analytical_acceptance(d: pd.DataFrame, pred_held_out: pd.DataFrame) -> pd.DataFrame:
    """Run tests S1 and S2 of model MA (see the comment block above). Returns one row per test configuration with
    pred_MA, the baselines, pred_M1 (reference), alpha_hat, k_hat (predicted) and k_measured (calculated from the run)."""
    out = []
    fixed = d[d.draft_mode == "fixed"]
    for target, draft in PAIRS:
        pair = d[(d.target_precision == target) & (d.draft_precision == draft)]
        pair_fixed = fixed[(fixed.target_precision == target) & (fixed.draft_precision == draft)]
        for prompt in sorted(d.prompt_id.unique()):
            calib = pair[pair.prompt_id != prompt]           # the other 5 prompts: used for t_check, t_draft
            times = fit_round_times(calib)
            test_all = pair_fixed[pair_fixed.prompt_id == prompt]

            # ---- S1: alpha from the gamma-2 reference run of the same prompt and length mode
            for _, row in test_all[test_all.gamma > 2].iterrows():
                ref = pair_fixed[(pair_fixed.prompt_id == prompt) & (pair_fixed.gamma == 2) & (pair_fixed.length_mode == row.length_mode)].iloc[0]
                alpha = alpha_mle([ref.step_log])
                T, k, rnd, prop = _ma_time(times, alpha, row.gamma, row.std_generated_tokens)
                same_group = calib[(calib.gamma == row.gamma) & (calib.draft_mode == "fixed")]
                out.append(dict(row, split="MA_S1_new_gamma", fold=0, alpha_hat=alpha, k_hat=k,
                                pred_MA=T, pred_B0ref=ref.sd_lat_med / ref.output_length * row.std_generated_tokens,
                                pred_B0g=same_group.sd_lat_med.sum() / same_group.output_length.sum() * row.std_generated_tokens,
                                pred_M1=_round_model(times, row.n_verify_steps, row.proposed_total)))

            # ---- S2: alpha from the other 5 prompts (same pair, same gamma, fixed drafting)
            for _, row in test_all.iterrows():
                others = pair_fixed[(pair_fixed.prompt_id != prompt) & (pair_fixed.gamma == row.gamma)]
                alpha = alpha_mle(others.step_log)
                T, k, rnd, prop = _ma_time(times, alpha, row.gamma, row.std_generated_tokens)
                base = pred_held_out[(pred_held_out.pair == row.pair) & (pred_held_out.prompt_id == prompt) & (pred_held_out.gamma == row.gamma)
                                     & (pred_held_out.draft_mode == "fixed") & (pred_held_out.length_mode == row.length_mode)].iloc[0]
                out.append(dict(row, split="MA_S2_new_prompt", fold=sorted(d.prompt_id.unique()).index(prompt), alpha_hat=alpha, k_hat=k,
                                pred_MA=T, pred_B0=base.pred_B0, pred_B0g=base.pred_B0g, pred_M2=base.pred_M2, pred_M1=base.pred_M1))
    res = pd.DataFrame(out)
    # measured tokens per round of the run itself (all rounds), to compare with k_hat
    res["k_measured"] = res.output_length / res.n_verify_steps
    return res


def acceptance_diagnostics(d: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Checks of the MA assumptions on the fixed-drafting runs (calculated).
    (a) alpha (MLE) per pair and gamma, and per prompt and gamma - is alpha a property of the pair/text, not of gamma?
    (b) acceptance probability by draft position j: P(position j accepted | positions 1..j-1 accepted).
        Under the equal-probability assumption every position has the same value."""
    fixed = d[d.draft_mode == "fixed"]
    a_rows = []
    for by in ["pair", "prompt_id"]:
        for (key, gamma), g in fixed.groupby([by, "gamma"]):
            a_rows.append(dict(group_by=by, group=key, gamma=gamma, alpha_mle=alpha_mle(g.step_log),
                               share_rounds_full_gamma=np.mean([p == gamma for log in g.step_log for p, _ in _rounds(log)])))
    p_rows = []
    for gamma, g in fixed.groupby("gamma"):
        rounds = [r for log in g.step_log for r in _rounds(log) if r[0] == gamma]
        acc = np.array([a for _, a in rounds])
        for j in range(1, gamma + 1):
            reached = (acc >= j - 1).sum()
            p_rows.append(dict(gamma=gamma, position=j, rounds_reaching=int(reached), p_accept=(acc >= j).sum() / reached))
    return pd.DataFrame(a_rows), pd.DataFrame(p_rows)


# =====================================================================================================
# Step 8 - is anything left for a more flexible model to learn? (residual structure of M1, held-out prompt)
# =====================================================================================================
def residual_structure(pred: pd.DataFrame) -> pd.DataFrame:
    """Signed % error of M1 in the held-out-prompt split, summarised (calculated).

    Rows: share of configurations whose |error| is within 1x and 2x their own run-to-run CV (the noise floor), and the
    median signed error per drafting mode, gamma, length mode, prompt and pair. Systematic medians far from 0 would be
    structure a more flexible model could learn; values near 0 and errors within the noise floor leave little to learn.
    """
    h = pred[pred.split == "held_out_prompt"].copy()
    h["err_pct"] = 100 * (h.pred_M1 - h.sd_lat_med) / h.sd_lat_med
    rel = (h.err_pct.abs() / 100) / h.run_cv
    rows = [dict(factor="noise floor", level="|error| <= 1 x run CV", value=(rel <= 1).mean(), n=len(h)),
            dict(factor="noise floor", level="|error| <= 2 x run CV", value=(rel <= 2).mean(), n=len(h))]
    for factor in ["draft_mode", "gamma", "length_mode", "prompt_id", "pair"]:
        for level, g in h.groupby(factor):
            rows.append(dict(factor=factor, level=str(level), value=g.err_pct.median(), n=len(g)))
    return pd.DataFrame(rows)

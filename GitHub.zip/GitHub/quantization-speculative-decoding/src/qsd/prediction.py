"""Per-round time model for speculative decoding (SD) and its out-of-sample tests.

Unit of analysis: one SD configuration (target precision, draft precision, gamma, prompt, output length).
Measured time = median of the 10 timed runs (sd_lat_med, from Stage 3). Step counts come from the
untimed logging pass (n_verify_steps, proposed_total), whose outputs matched the timed runs (140/140 hashes).

Models (all fitted separately for each target/draft precision pair, on training configurations only):
  B0  naive per-token rate     T = r * L                       r = sum(T) / sum(L) on training configs
  M1  per-round, trace given   T = t_verify * N_verify + t_draft * N_proposed   (non-negative LS, no intercept)
  M2  per-round, a priori      as M1, but N_verify and N_proposed are themselves predicted:
                               N_verify = L / k,  N_proposed = p * N_verify
                               k = tokens per verification round, p = draft tokens proposed per round,
                               both taken from training configs of the same pair (same gamma if present
                               in training, otherwise all training gammas). M2 needs no SD run of the test config.
  M1i sensitivity variant of M1 with an intercept (ordinary least squares).

Pre-declared choices (made before looking at test errors): no intercept in M1/M2 (a run with zero rounds
takes ~zero time; Stage 3 intercepts were -0.08 to +0.002 s); ratio estimators for r, k, p; config medians;
bootstrap B = 5000, seed 742, resampling test configurations.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.optimize import nnls

PAIRS = [("FP16", "FP16"), ("INT8", "INT8"), ("INT8", "FP16"), ("INT4", "INT4"), ("INT4", "FP16")]
SEED, B = 742, 5000


# ----------------------------------------------------------------------------- data
def load_sd_configs(sd_configs_csv: str) -> pd.DataFrame:
    """Read Stage 3 sd_configs_full.csv and keep the columns the model needs."""
    d = pd.read_csv(sd_configs_csv).rename(columns={"g": "gamma"})
    need = ["stage", "target_precision", "draft_precision", "draft_strategy", "gamma", "prompt_id", "output_length",
            "sd_lat_med", "std_lat_med_corrected", "speedup", "ci_lo", "ci_hi", "verdict", "n_verify_steps", "proposed_total",
            "accepted_total", "acceptance_rate"]
    d = d[need].copy()
    d["gamma"] = d["gamma"].astype(int)
    d["pair"] = d.target_precision + "+" + d.draft_precision
    assert len(d) == 110 and d[["n_verify_steps", "proposed_total"]].notna().all().all()
    return d.reset_index(drop=True)


# ----------------------------------------------------------------------------- fitting
def fit_round_times(train: pd.DataFrame, intercept: bool = False) -> dict:
    """Per-round times (seconds) for one precision pair."""
    X = train[["n_verify_steps", "proposed_total"]].to_numpy(float)
    y = train["sd_lat_med"].to_numpy(float)
    if intercept:
        X1 = np.column_stack([np.ones(len(X)), X])
        coef, *_ = np.linalg.lstsq(X1, y, rcond=None)
        return dict(a=coef[0], t_verify=coef[1], t_draft=coef[2])
    coef, _ = nnls(X, y)
    return dict(a=0.0, t_verify=coef[0], t_draft=coef[1])


def round_stats(train: pd.DataFrame, gamma: int) -> tuple[float, float]:
    """Tokens per round (k) and draft tokens proposed per round (p); same gamma if available."""
    t = train[train.gamma == gamma]
    if t.empty:
        t = train
    k = t.output_length.sum() / t.n_verify_steps.sum()
    p = t.proposed_total.sum() / t.n_verify_steps.sum()
    return k, p


def predict_split(d: pd.DataFrame, train_mask: pd.Series, test_mask: pd.Series) -> pd.DataFrame:
    """Fit all models per pair on train rows, predict test rows."""
    out = []
    for tp, dp in PAIRS:
        pm = (d.target_precision == tp) & (d.draft_precision == dp)
        tr, te = d[pm & train_mask], d[pm & test_mask].copy()
        if te.empty:
            continue
        assert len(tr) >= 2, "need at least two training configurations per pair"
        r = tr.sd_lat_med.sum() / tr.output_length.sum()
        c = fit_round_times(tr)
        ci = fit_round_times(tr, intercept=True)
        te["pred_B0"] = r * te.output_length
        te["pred_M1"] = c["t_verify"] * te.n_verify_steps + c["t_draft"] * te.proposed_total
        te["pred_M1i"] = ci["a"] + ci["t_verify"] * te.n_verify_steps + ci["t_draft"] * te.proposed_total
        kp = np.array([round_stats(tr, g) for g in te.gamma])
        te["k_hat"], te["p_hat"] = kp[:, 0], kp[:, 1]
        te["nv_hat"] = te.output_length / te.k_hat
        te["np_hat"] = te.p_hat * te.nv_hat
        te["pred_M2"] = c["t_verify"] * te.nv_hat + c["t_draft"] * te.np_hat
        te["t_verify_ms"], te["t_draft_ms"] = 1000 * c["t_verify"], 1000 * c["t_draft"]
        te["n_train"] = len(tr)
        out.append(te)
    return pd.concat(out, ignore_index=True)


# ----------------------------------------------------------------------------- splits
def splits(d: pd.DataFrame) -> dict:
    """The three pre-declared out-of-sample tests. Each returns a list of (train_mask, test_mask) folds."""
    return {
        # every prompt is held out once (CORE prompt 'quantization' + the three WORKLOAD prompts)
        "leave_one_workload_out": [(d.prompt_id != p, d.prompt_id == p) for p in sorted(d.prompt_id.unique())],
        # fit on gamma = 2 only, predict gamma 4, 6, 8
        "gamma2_to_larger_gamma": [(d.gamma == 2, d.gamma > 2)],
        # fit on the Draft-Length Sensitivity Experiment, predict the Workload and Output-Length Experiment
        "core_to_workload": [(d.stage == "CORE", d.stage == "WORKLOAD")],
    }


def run_all_splits(d: pd.DataFrame) -> pd.DataFrame:
    res = []
    for name, folds in splits(d).items():
        for i, (trm, tem) in enumerate(folds):
            p = predict_split(d, trm, tem)
            p["split"], p["fold"] = name, i
            res.append(p)
    return pd.concat(res, ignore_index=True)


# ----------------------------------------------------------------------------- metrics
MODELS = ["B0", "M1", "M2", "M1i"]


def _metrics(y, yhat):
    e = yhat - y
    return dict(MAE_s=np.mean(np.abs(e)), RMSE_s=np.sqrt(np.mean(e ** 2)), MAPE_pct=100 * np.mean(np.abs(e) / y),
                bias_s=np.mean(e))


def error_table(pred: pd.DataFrame, by=("split",)) -> pd.DataFrame:
    """Point metrics + percentile bootstrap 95% CIs (resampling test configurations)."""
    rng = np.random.default_rng(SEED)
    rows = []
    for key, g in pred.groupby(list(by)):
        key = key if isinstance(key, tuple) else (key,)
        y = g.sd_lat_med.to_numpy()
        idx = rng.integers(0, len(g), (B, len(g)))
        for m in MODELS:
            yh = g[f"pred_{m}"].to_numpy()
            pt = _metrics(y, yh)
            ae = np.abs(yh - y)[idx]; se = ((yh - y) ** 2)[idx]; pe = (100 * np.abs(yh - y) / y)[idx]
            ci = dict(MAE_s=np.percentile(ae.mean(1), [2.5, 97.5]), RMSE_s=np.percentile(np.sqrt(se.mean(1)), [2.5, 97.5]),
                      MAPE_pct=np.percentile(pe.mean(1), [2.5, 97.5]))
            row = dict(zip(by, key), model=m, n_test=len(g), **pt)
            for k_, (lo, hi) in ci.items():
                row[f"{k_}_lo"], row[f"{k_}_hi"] = lo, hi
            if m != "B0":  # paired difference in MAPE vs the naive baseline (negative = better than naive)
                base = (100 * np.abs(g.pred_B0.to_numpy() - y) / y)[idx]
                diff = pe.mean(1) - base.mean(1)
                row["dMAPE_vs_B0"] = pt["MAPE_pct"] - _metrics(y, g.pred_B0.to_numpy())["MAPE_pct"]
                row["dMAPE_vs_B0_lo"], row["dMAPE_vs_B0_hi"] = np.percentile(diff, [2.5, 97.5])
            rows.append(row)
    return pd.DataFrame(rows)


def direction_table(pred: pd.DataFrame, d: pd.DataFrame) -> pd.DataFrame:
    """Does the model call the direction (SD faster or slower than standard) correctly?
    Uses the measured, warm-up-corrected standard time of the same prompt/length/precision.
    Baseline: predict, for every test configuration, the majority direction of its pair in the training configurations."""
    global pred_train_direction
    pred_train_direction = {}
    for s_, folds in splits(d).items():
        for f, (trm, _) in enumerate(folds):
            for pair, gp in d[trm].groupby("pair"):
                pred_train_direction[(s_, f, pair)] = bool((gp.speedup > 1).mean() > 0.5)
    rows = []
    for (s, m), g in [((s, m), pred[pred.split == s]) for s in pred.split.unique() for m in ["M1", "M2"]]:
        meas = g.std_lat_med_corrected / g.sd_lat_med > 1
        hat = g.std_lat_med_corrected / g[f"pred_{m}"] > 1
        clear = g.verdict != "no clear difference"
        # majority-class baseline: each pair's most common direction in the training data of the same split/fold
        maj = 0
        for f, gf in g.groupby("fold"):
            for pair, gp in gf.groupby("pair"):
                trm = pred_train_direction.get((s, f, pair))
                if trm is not None:
                    maj += int(((gp.std_lat_med_corrected / gp.sd_lat_med > 1) == trm).sum())
        rows.append(dict(split=s, model=m, n=len(g), correct=int((meas == hat).sum()),
                         n_clear=int(clear.sum()), correct_clear=int((meas == hat)[clear].sum()), majority_baseline_correct=maj))
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------- break-even
def break_even(d: pd.DataFrame, boot: int = B) -> pd.DataFrame:
    """Break-even draft/check time ratio per pair, from all 110 configurations (calculated).

    T_SD per token = (t_verify + p * t_draft) / k ;  T_standard per token = t_s.
    SD is faster when rho = t_draft / t_verify < rho* = (k * t_s / t_verify - 1) / p.
    t_s = sum(measured standard time, warm-up corrected) / sum(L) over the same configurations (ratio, like the
    no-intercept SD model). CIs: bootstrap over configurations within the pair (all quantities refitted).
    """
    rng = np.random.default_rng(SEED)
    rows = []
    for tp, dp in PAIRS:
        g = d[(d.target_precision == tp) & (d.draft_precision == dp)].reset_index(drop=True)
        def calc(x):
            ts = x.std_lat_med_corrected.sum() / x.output_length.sum()
            c = fit_round_times(x)
            k = x.output_length.sum() / x.n_verify_steps.sum(); p = x.proposed_total.sum() / x.n_verify_steps.sum()
            rho = c["t_draft"] / c["t_verify"]; rho_star = (k * ts / c["t_verify"] - 1) / p
            return rho, rho_star, k, p, c["t_verify"], c["t_draft"], ts

        rho, rho_s, k, p, tv, td, ts = calc(g)
        bs = np.array([calc(g.iloc[rng.integers(0, len(g), len(g))]) for _ in range(boot)])
        margin = bs[:, 1] - bs[:, 0]
        rows.append(dict(target_precision=tp, draft_precision=dp, n=len(g), t_verify_ms=1000 * tv, t_draft_ms=1000 * td,
                         t_standard_ms_per_token=1000 * ts, tokens_per_round=k, proposed_per_round=p,
                         rho=rho, rho_lo=np.percentile(bs[:, 0], 2.5), rho_hi=np.percentile(bs[:, 0], 97.5),
                         rho_star=rho_s, rho_star_lo=np.percentile(bs[:, 1], 2.5), rho_star_hi=np.percentile(bs[:, 1], 97.5),
                         margin=rho_s - rho, margin_lo=np.percentile(margin, 2.5), margin_hi=np.percentile(margin, 97.5),
                         predicted_sd_per_token_ms=1000 * (tv + p * td) / k,
                         measured_median_speedup=g.speedup.median(), configs_faster=int((g.speedup > 1).sum())))
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------- exploratory (post hoc)
def acceptance_transfer(pred: pd.DataFrame, d: pd.DataFrame) -> pd.DataFrame:
    """EXPLORATORY, added after M2 was seen to match the naive baseline.
    M3: round times from the training fit (as M1) + step counts taken from the FP16-target/FP16-draft run of the
    same prompt, length and gamma. Only quantized-target configurations are scored (88 per full pass)."""
    src = d[d.pair == "FP16+FP16"].set_index(["prompt_id", "output_length", "gamma"])[["n_verify_steps", "proposed_total"]]
    q = pred[pred.target_precision != "FP16"].copy()
    s = src.loc[list(zip(q.prompt_id, q.output_length, q.gamma))].to_numpy(float)
    q["pred_M3"] = q.t_verify_ms / 1000 * s[:, 0] + q.t_draft_ms / 1000 * s[:, 1]
    rows = []
    for sp, g in q.groupby("split"):
        y = g.sd_lat_med.to_numpy()
        for m in ["B0", "M1", "M2", "M3"]:
            rows.append(dict(split=sp, model=m, n_test=len(g), **_metrics(y, g[f"pred_{m}"].to_numpy())))
    return pd.DataFrame(rows)

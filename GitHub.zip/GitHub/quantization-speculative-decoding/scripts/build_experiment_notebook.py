"""Builds notebooks/04_full_experiment_colab.ipynb, embedding src/qsd/experiment.py verbatim.
Usage: python scripts/build_colab_notebook.py"""
import json, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
mod = (ROOT / "src/qsd/experiment.py").read_text()

def md(s): return dict(cell_type="markdown", metadata={}, source=s.strip("\n"))
def code(s): return dict(cell_type="code", metadata={}, execution_count=None, outputs=[], source=s.strip("\n"))

cells = [
md("""
# CENG 742 · Stage 4.1 — improved timing experiment (v2)
Quantization × speculative decoding, Qwen2.5-1.5B target + Qwen2.5-0.5B draft, Tesla T4.

This notebook **adds** a second, improved timing experiment. It does not change the Stage 1–3 data.

| Gap in Stage 1–3 | Change in v2 |
|---|---|
| Versions not pinned, no model revision | Exact package pins; model commit hashes resolved once and reused in every session (`revisions.json` on Drive) |
| Warm-up only per configuration | Session warm-up until 3 runs agree within 3 %, plus one untimed warm-up block |
| GPU clock not recorded | SM/memory clock, temperature, power, throttle reasons for every run; clock lock attempted and result recorded |
| Fixed run order (standard before SD) | Randomized complete blocks: every configuration once per block, new random order per block |
| One prompt per task | Two prompts per task (the three original prompts + three new ones) |
| Fixed output length only | Fixed length (`fixed100`) and natural stopping at EOS (`natural200`, at most 200 tokens) |
| Output equality only | Exact match, answer checks, ROUGE-L, BERTScore and embedding cosine (notebook 05, from the saved texts) |
| Memory included every loaded model | Per run: extra memory of that run; configuration memory = target + draft used + run extra |
| Energy from one separate session | NVML energy for every timed run, every session |
| Confidence-based drafting only | Adaptive confidence drafting (HF default, starts at 0.4) **vs** fixed-length drafting (threshold 0) |

**Design (PRESET = "FULL", approved 2026-11-03):** γ 2/4/8 × adaptive-confidence and fixed-length drafting × FP16 and matched
draft × {fixed 100 tokens, natural stop ≤ 200} × 6 prompts × 5 randomized blocks. Every metric (time, energy, memory, clock,
step counts, output text) is recorded in the same run; speedups are computed within the same session and block.

**How to run (one target precision per session; INT8 first, it carries the main result):**
1. Runtime → Change runtime type → **T4 GPU** (keep T4 even if paid units offer L4/A100: all results are T4).
2. Run cell 1 (install), then **Runtime → Restart session**.
3. Set `TARGET_PRECISION` and `PRESET` in cell 4. Run cells 2, 3, 4, 5, 6, 7 in order (**skip 4b** unless resuming).
   Allow multiple downloads in the browser when Colab asks.
4. Results are saved **locally**: on the Colab runtime disk (`/content/ceng742_v2/`) after every run, and downloaded to your
   computer as a ZIP after every completed block and at the end. Nothing is written to Google Drive.
5. If Colab disconnects, the runtime disk is wiped. To resume: start a new session, run cells 1–4, upload the latest
   `runs_v2.csv` from the most recent ZIP with cell 4b, then run cells 5–7. Finished runs are skipped.
6. Session 1 prints the model commit hashes. Paste them into `REVISIONS` in cell 3 before the next session so all sessions use the same model files.
"""),
code("""
# 1 · Pinned install (then Runtime -> Restart session)
!pip -q install "transformers==5.18.0" "bitsandbytes==0.50.2" "accelerate==1.15.0" "nvidia-ml-py==13.615.71" pandas
"""),
code("%%writefile experiment.py\n" + mod),
code("""
# 3 · Environment record and model revisions
import json, platform, uuid, subprocess, importlib.metadata
from pathlib import Path
import torch, transformers, bitsandbytes, accelerate, sklearn, pynvml
pynvml.nvmlInit()
import experiment as E
LOCAL = Path("/content/ceng742_v2"); LOCAL.mkdir(parents=True, exist_ok=True)   # Colab runtime disk (no Google Drive)

assert torch.cuda.is_available() and torch.cuda.get_device_name(0) == "Tesla T4", "Select a T4 GPU runtime"
assert transformers.__version__ == "5.18.0" and bitsandbytes.__version__ == "0.50.2", "Restart the session after cell 1"
ENV = dict(python=platform.python_version(), torch=torch.__version__, cuda=torch.version.cuda, transformers=transformers.__version__,
           bitsandbytes=bitsandbytes.__version__, accelerate=accelerate.__version__, scikit_learn=sklearn.__version__,
           nvidia_ml_py=importlib.metadata.version("nvidia-ml-py"), gpu=torch.cuda.get_device_name(0),
           driver=pynvml.nvmlSystemGetDriverVersion())
if ENV["torch"] != "2.11.0+cu130":
    print("NOTE: torch differs from Stage 1-3 (2.11.0+cu130). Colab controls torch; this is recorded, not fixed.")

TARGET_ID, DRAFT_ID = "Qwen/Qwen2.5-1.5B-Instruct", "Qwen/Qwen2.5-0.5B-Instruct"
# Paste the hashes printed by session 1 here so every session loads the same model files.
REVISIONS = {TARGET_ID: None, DRAFT_ID: None}
if None in REVISIONS.values():
    from huggingface_hub import HfApi
    REVISIONS = {m: HfApi().model_info(m).sha for m in (TARGET_ID, DRAFT_ID)}
    print("Session 1: copy this line into REVISIONS above for the next sessions:")
    print("REVISIONS =", json.dumps(REVISIONS))
(LOCAL / "revisions.json").write_text(json.dumps(REVISIONS, indent=2))
CLOCK = E.try_lock_clocks(1590)
print(json.dumps(ENV, indent=1)); print("Revisions:", REVISIONS); print("Clock lock:", CLOCK)
"""),
code("""
# 4 · Configuration
TARGET_PRECISION = "INT8"    # INT8 first, then FP16, then INT4 (one per session)
PRESET = "FULL"              # FULL (approved design) or QUICK (pilot)
MAX_MINUTES = 480            # clean stop after this many minutes; rerun / resume continues

design = E.Design(target_precision=TARGET_PRECISION, **E.PRESETS[PRESET])
OUT = LOCAL / f"{PRESET.lower()}_{TARGET_PRECISION.lower()}"; OUT.mkdir(exist_ok=True)
CSV = OUT / "runs_v2.csv"
SESSION_ID = uuid.uuid4().hex[:10]
print(f"{len(design.configs())} configurations x {design.blocks} timed blocks" + (" (+1 warm-up block)" if design.warmup_block else ""))
print(f"Estimated GPU time: {E.estimate_minutes(design):.0f} min (from the measured QUICK per-token times; natural stop counted at 200 tokens)")
for c in design.configs()[:6]: print("  ", c["key"])
"""),
code("""
# 4b · ONLY when resuming after a disconnect: upload runs_v2.csv from the last downloaded ZIP (skip otherwise)
from google.colab import files
up = files.upload()
for name, data in up.items():
    (OUT / "runs_v2.csv").write_bytes(data)
    import pandas as pd; print("Resuming from", name, "-", len(pd.read_csv(OUT / "runs_v2.csv")), "rows already done")
"""),
code("""
# 5 · Load models (target + every draft precision needed; kept loaded so runs can be interleaved)
import gc
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
tokenizer = AutoTokenizer.from_pretrained(TARGET_ID, revision=REVISIONS[TARGET_ID])
dtok = AutoTokenizer.from_pretrained(DRAFT_ID, revision=REVISIONS[DRAFT_ID])
assert tokenizer.get_vocab() == dtok.get_vocab() and tokenizer.eos_token_id == dtok.eos_token_id

def load_model(model_id, precision):
    opts = dict(device_map={"": 0}, dtype=torch.float16, revision=REVISIONS[model_id])
    if precision == "INT8":
        opts["quantization_config"] = BitsAndBytesConfig(load_in_8bit=True)
    elif precision == "INT4":
        opts["quantization_config"] = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                                                         bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=False)
    return AutoModelForCausalLM.from_pretrained(model_id, **opts).eval()   # same settings as Stage 1-3

def prepare(prompt):
    s = tokenizer.apply_chat_template([{"role": "user", "content": prompt}], tokenize=False, add_generation_prompt=True)
    return {k: v.to("cuda") for k, v in tokenizer(s, return_tensors="pt").items()}

target = load_model(TARGET_ID, TARGET_PRECISION)
drafts = {p: load_model(DRAFT_ID, p) for _, p in design.draft_list()}
FOOTPRINT_MB = {"target": target.get_memory_footprint() / 2**20, **{f"draft_{p}": m.get_memory_footprint() / 2**20 for p, m in drafts.items()}}
protocol = dict(session_id=SESSION_ID, preset=PRESET, design={k: v for k, v in design.__dict__.items()}, env=ENV, revisions=REVISIONS,
                clock=CLOCK, footprint_mb=FOOTPRINT_MB, prompts=E.PROMPTS,
                note="peak_gpu_memory_mb includes every loaded model; configuration memory = footprint_mb[target] + footprint_mb[draft used] + run_extra_memory_mb")
(OUT / f"protocol_{SESSION_ID}.json").write_text(json.dumps(protocol, indent=2, default=str))
print(FOOTPRINT_MB)
"""),
code("""
# 6 · Session warm-up, then the randomized block schedule (resumable)
wu = E.session_warmup(target, prepare(E.PROMPTS["factual"]["text"]), design)
print("Session warm-up times (s):", [round(t, 2) for t in wu])
(OUT / f"warmup_{SESSION_ID}.json").write_text(json.dumps(wu))
import shutil
from google.colab import files
def download_zip(block):
    # partial ZIP after each completed block, so a disconnect loses at most one block
    (LOCAL / "revisions.json").exists() and shutil.copy(LOCAL / "revisions.json", OUT / "revisions.json")
    z = shutil.make_archive(f"/content/v2_{PRESET.lower()}_{TARGET_PRECISION.lower()}_block{block}", "zip", root_dir=OUT)
    files.download(z)
df = E.run_design(design, target, drafts, tokenizer, prepare, CSV, SESSION_ID, max_minutes=MAX_MINUTES, on_block_end=download_zip)
print("Rows:", len(df), "of", len(design.schedule()))
"""),
code("""
# 7 · Quick summary and download (full analysis runs on CPU in the repository)
import shutil, pandas as pd
df = pd.read_csv(CSV); t = df[df.timed]
s = t.groupby(["mode", "draft_precision", "draft_mode", "gamma", "length_mode"], dropna=False).agg(
    n=("time_s", "size"), median_time_s=("time_s", "median"), median_energy_j=("energy_j", "median"),
    steps=("n_verify_steps", "median"), sm_mhz=("sm_mhz_start", "median"), correct=("answer_correct", "mean")).round(3)
display(s)
print("Distinct outputs per configuration (should be 1):", t.groupby("key").output_hash.nunique().max())
shutil.copy(LOCAL / "revisions.json", OUT / "revisions.json")
archive = shutil.make_archive(f"/content/v2_{PRESET.lower()}_{TARGET_PRECISION.lower()}_final", "zip", root_dir=OUT)
from google.colab import files; files.download(archive)
"""),
]
nb = dict(nbformat=4, nbformat_minor=5, metadata=dict(kernelspec=dict(name="python3", display_name="Python 3"),
          language_info=dict(name="python"), accelerator="GPU", colab=dict(gpuType="T4")), cells=cells)
for c in nb["cells"]:
    lines = c["source"].split("\n"); c["source"] = [l + "\n" for l in lines[:-1]] + [lines[-1]]
out = ROOT / "notebooks/04_full_experiment_colab.ipynb"
out.write_text(json.dumps(nb, indent=1)); print("wrote", out)

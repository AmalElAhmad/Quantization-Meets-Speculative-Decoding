"""Publication figures from analysis.pkl. Usage: python scripts/pilot_figures.py <out_dir>"""
import sys, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm, LogNorm
from matplotlib.lines import Line2D

OUT = sys.argv[1]
A = pd.read_pickle(f"{OUT}/analysis.pkl")
raw, cfg, sp, en, e, t2, memo, dec = (A[k] for k in ["raw", "cfg", "sp", "en", "e", "t2", "memo", "dec"])

INK, INK2, MUTED, GRID, BASE = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7"
PC = {"FP16": "#2a78d6", "INT8": "#eb6834", "INT4": "#1baf7a"}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.titlesize": 8.5, "axes.labelsize": 8,
                     "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7.5, "axes.edgecolor": BASE,
                     "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "text.color": INK,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID,
                     "grid.linewidth": 0.6, "axes.axisbelow": True, "savefig.dpi": 300, "figure.dpi": 150,
                     "axes.titleweight": "bold", "axes.titlelocation": "left"})
W2 = 7.16  # IEEE double-column width (in)

GROUPS = ["FP16 + FP16 draft", "INT8 + INT8 draft", "INT8 + FP16 draft", "INT4 + INT4 draft", "INT4 + FP16 draft"]
GLAB = {"FP16 + FP16 draft": "FP16 target · FP16 draft", "INT8 + INT8 draft": "INT8 target · INT8 draft (matched)",
        "INT8 + FP16 draft": "INT8 target · FP16 draft", "INT4 + INT4 draft": "INT4 target · INT4 draft (matched)",
        "INT4 + FP16 draft": "INT4 target · FP16 draft"}
def gprec(g): return g.split()[0]
def gmatched(g): return g in ("FP16 + FP16 draft", "INT8 + INT8 draft", "INT4 + INT4 draft")
def style(g):
    c = PC[gprec(g)]
    return dict(color=c, marker="o" if gmatched(g) else "s", markerfacecolor=c if gmatched(g) else "white",
                markeredgecolor=c, linestyle="-" if gmatched(g) else "--", linewidth=2, markersize=6, markeredgewidth=1.6)
def save(fig, name):
    fig.savefig(f"{OUT}/{name}.png", bbox_inches="tight", facecolor="white")
    fig.savefig(f"{OUT}/{name}.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)
def group_legend(ax, groups=GROUPS, **kw):
    h = [Line2D([0], [0], **style(g)) for g in groups]
    return ax.legend(h, [GLAB[g] for g in groups], frameon=False, **kw)

# ---------------------------------------------------------------- Fig 1: quantization
fig, axs = plt.subplots(1, 3, figsize=(W2, 2.25), constrained_layout=True)
x = np.arange(3); P = ["FP16", "INT8", "INT4"]; tq = t2.set_index("target_precision").loc[P]
ax = axs[0]
ax.bar(x, tq.ms_per_token_med, width=0.6, color=[PC[p] for p in P], edgecolor="white", linewidth=1)
for i, p in enumerate(P):
    ax.text(i, tq.ms_per_token_med[p] + 3, f"{tq.ms_per_token_med[p]:.0f}", ha="center", va="bottom", color=INK, fontsize=7.5)
ax.set_xticks(x, P); ax.set_ylabel("ms per generated token"); ax.set_title("(a) Standard decoding latency"); ax.grid(axis="x", visible=False)
ax = axs[1]
mm = memo.set_index(["target_precision", "draft_precision"]).mem_mb
w = 0.26
vals = [[tq.peak_mem_mb[p] for p in P], [mm.get((p, p), np.nan) for p in P], [mm.get((p, "FP16"), np.nan) if p != "FP16" else np.nan for p in P]]
hatches = [None, "////", "...."]; labs = ["Standard", "SD, matched draft", "SD, FP16 draft"]
for k in range(3):
    ax.bar(x + (k - 1) * w, np.array(vals[k]) / 1024, width=w - 0.03, color=[PC[p] for p in P], hatch=hatches[k], edgecolor="white", linewidth=0.8)
ax.set_xticks(x, P); ax.set_ylabel("Peak allocated GPU memory (GB)"); ax.set_title("(b) Peak GPU memory"); ax.grid(axis="x", visible=False)
from matplotlib.patches import Patch
ax.legend([Patch(facecolor="#9a9994", hatch=h, edgecolor="white") for h in hatches], labs, frameon=False, loc="upper right", fontsize=6.5)
ax.set_ylim(0, 4.6)
ax = axs[2]
ax.bar(x, tq.j_per_token, width=0.6, color=[PC[p] for p in P], edgecolor="white", linewidth=1)
for i, p in enumerate(P):
    ax.text(i, tq.j_per_token[p] + 0.08, f"{tq.j_per_token[p]:.2f}", ha="center", va="bottom", color=INK, fontsize=7.5)
ax.set_xticks(x, P); ax.set_ylabel("GPU energy per token (J)"); ax.set_title("(c) Standard decoding energy"); ax.grid(axis="x", visible=False)
save(fig, "Fig1_quantization")

# ---------------------------------------------------------------- Fig 2: draft-length sensitivity (CORE)
c = sp[sp.stage == "CORE"]
fig, axs = plt.subplots(1, 3, figsize=(W2, 3.0), layout="constrained")
for g in GROUPS:
    d = c[c.group == g].sort_values("g"); s = style(g)
    axs[0].errorbar(d.g, d.speedup, yerr=[d.speedup - d.ci_lo, d.ci_hi - d.speedup], capsize=2, elinewidth=1, **s)
    axs[1].plot(d.g, d.mean_proposed_per_step, **s)
    axs[2].plot(d.g, d.acceptance_rate, **s)
axs[0].axhline(1, color=INK2, linewidth=1); axs[0].set_ylabel("Speedup vs. standard (median ratio)")
axs[0].set_title("(a) SD speedup")
axs[1].plot([2, 8], [2, 8], color=MUTED, linewidth=1, linestyle=":"); axs[1].text(5.6, 6.2, "draft = γ", color=MUTED, fontsize=6.5, rotation=0)
axs[1].set_ylabel("Mean draft tokens proposed per step"); axs[1].set_title("(b) Effective draft length"); axs[1].set_ylim(0, 8.5)
axs[2].set_ylabel("Acceptance rate (accepted / proposed)"); axs[2].set_title("(c) Acceptance rate"); axs[2].set_ylim(0.3, 0.8)
for ax in axs: ax.set_xticks([2, 4, 6, 8]); ax.set_xlabel("Maximum draft length γ")
fig.legend([Line2D([0], [0], **style(g)) for g in GROUPS], [GLAB[g] for g in GROUPS], loc="outside lower center", ncol=3, frameon=False)
save(fig, "Fig3_draft_length")

# ---------------------------------------------------------------- heatmap helper (WORKLOAD)
w_ = sp[sp.stage == "WORKLOAD"].copy()
ROWS = [(g, gm) for g in GROUPS for gm in (2, 4)]
COLS = [(p, L) for p in ["factual", "summary", "reasoning"] for L in (50, 100, 200)]
def matrix(col):
    M = np.full((len(ROWS), len(COLS)), np.nan)
    for i, (g, gm) in enumerate(ROWS):
        for j, (p, L) in enumerate(COLS):
            d = w_[(w_.group == g) & (w_.g == gm) & (w_.prompt_id == p) & (w_.output_length == L)]
            if len(d): M[i, j] = d[col].iloc[0]
    return M
def heat(ax, M, cmap, norm, fmt, txt=None, dark_thresh=None):
    im = ax.imshow(M, cmap=cmap, norm=norm, aspect="auto")
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            t = txt[i][j] if txt is not None else fmt.format(M[i, j])
            rgba = im.cmap(im.norm(M[i, j])); lum = 0.2126 * rgba[0] + 0.7152 * rgba[1] + 0.0722 * rgba[2]
            ax.text(j, i, t, ha="center", va="center", fontsize=6.6, color="white" if lum < 0.5 else INK)
    ax.set_xticks(range(len(COLS)), [str(L) for _, L in COLS])
    for k, p in enumerate(["Factual", "Summarization", "Reasoning"]):
        ax.text(3 * k + 1, -0.9, p, ha="center", va="bottom", fontsize=7.5, color=INK, fontweight="bold")
    ax.set_yticks(range(len(ROWS)), [f"{GLAB[g].replace(' (matched)','')}  γ≤{gm}" for g, gm in ROWS])
    for k in range(1, 3): ax.axvline(3 * k - 0.5, color="white", linewidth=3)
    for k in range(1, 5): ax.axhline(2 * k - 0.5, color="white", linewidth=3)
    ax.grid(False); ax.set_xlabel("Output length (tokens)")
    for s in ax.spines.values(): s.set_visible(False)
    ax.tick_params(length=0)
    return im

# ---------------------------------------------------------------- Fig 3: speedup heatmap
M = matrix("speedup"); V = matrix("ci_lo"); H = matrix("ci_hi")
txt = [[(f"{M[i,j]:.2f}" if (V[i, j] > 1 or H[i, j] < 1) else f"({M[i,j]:.2f})") for j in range(M.shape[1])] for i in range(M.shape[0])]
div = LinearSegmentedColormap.from_list("div", ["#a82f2f", "#e34948", "#f3b3b2", "#f0efec", "#9ec5f4", "#3987e5", "#184f95"])
fig, ax = plt.subplots(figsize=(W2, 3.3), constrained_layout=True)
im = heat(ax, M, div, TwoSlopeNorm(vcenter=1.0, vmin=0.5, vmax=2.0), "{:.2f}", txt)
cb = fig.colorbar(im, ax=ax, shrink=0.8, pad=0.01); cb.set_label("Speedup (standard / SD median latency)"); cb.outline.set_visible(False)
cb.set_ticks([0.5, 0.75, 1, 1.5, 2])
save(fig, "Fig2_speedup_heatmap")

# ---------------------------------------------------------------- Fig 4: acceptance heatmap
seq = LinearSegmentedColormap.from_list("seq", ["#cde2fb", "#86b6ef", "#3987e5", "#1c5cab", "#0d366b"])
fig, ax = plt.subplots(figsize=(W2, 3.3), constrained_layout=True)
im = heat(ax, matrix("acceptance_rate"), seq, plt.Normalize(0.3, 0.95), "{:.2f}")
cb = fig.colorbar(im, ax=ax, shrink=0.8, pad=0.01); cb.set_label("Acceptance rate (accepted / proposed draft tokens)"); cb.outline.set_visible(False)
save(fig, "Fig4_acceptance_heatmap")

# ---------------------------------------------------------------- Fig 5: mechanism
fig, axs = plt.subplots(1, 2, figsize=(W2, 2.7), constrained_layout=True, gridspec_kw=dict(width_ratios=[1.25, 1]))
ax = axs[0]
for g in GROUPS:
    d = sp[sp.group == g]; s = style(g)
    ax.plot(d.acceptance_rate, d.speedup, linestyle="none", marker=s["marker"], markerfacecolor=s["markerfacecolor"],
            markeredgecolor="white" if gmatched(g) else s["color"], color=s["color"], markersize=5.5, markeredgewidth=0.8 if gmatched(g) else 1.3, alpha=0.95)
ax.axhline(1, color=INK2, linewidth=1)
ax.set_xlabel("Acceptance rate"); ax.set_ylabel("Speedup vs. standard"); ax.set_title("(a) Acceptance vs. speedup (110 SD configurations)")
group_legend(ax, loc="upper left", fontsize=6.3, handlelength=2.2)
ax.set_ylim(0.5, 2.05)
ax = axs[1]
dd = dec.copy(); dd["group"] = dd.apply(lambda r: f"{r.target_precision} + {r.draft_precision} draft", axis=1)
dd = dd.set_index("group").loc[GROUPS]
y = np.arange(len(GROUPS))[::-1]
for k, g in enumerate(GROUPS):
    s = style(g)
    ax.barh(y[k], dd.draft_to_verify_cost_ratio[g], height=0.6, color=s["color"] if gmatched(g) else "white", edgecolor=s["color"], linewidth=1.6, hatch=None if gmatched(g) else "////")
    ax.text(dd.draft_to_verify_cost_ratio[g] + 0.02, y[k], f"{dd.draft_to_verify_cost_ratio[g]:.2f}", va="center", fontsize=7, color=INK)
ax.set_yticks(y, [GLAB[g].replace(" (matched)", "").replace(" · ", "\n") for g in GROUPS], fontsize=6.8)
ax.set_xlim(0, 1.1); ax.set_xlabel("Draft cost per token / verification cost per step")
ax.set_title("(b) Relative draft cost (fitted)"); ax.grid(axis="y", visible=False)
save(fig, "Fig5_mechanism")

# ---------------------------------------------------------------- Fig 6: energy
ee = e.copy()
ee["row"] = ee.apply(lambda r: f"{r.target_precision} standard" if r["mode"] == "STANDARD" else r.group, axis=1)
ROW6 = ["FP16 standard", "FP16 + FP16 draft", "INT8 standard", "INT8 + FP16 draft", "INT8 + INT8 draft", "INT4 standard", "INT4 + FP16 draft", "INT4 + INT4 draft"]
RLAB = {"FP16 standard": "FP16 standard", "FP16 + FP16 draft": "FP16 · SD, FP16 draft", "INT8 standard": "INT8 standard",
        "INT8 + FP16 draft": "INT8 · SD, FP16 draft", "INT8 + INT8 draft": "INT8 · SD, INT8 draft", "INT4 standard": "INT4 standard",
        "INT4 + FP16 draft": "INT4 · SD, FP16 draft", "INT4 + INT4 draft": "INT4 · SD, INT4 draft"}
fig, axs = plt.subplots(1, 2, figsize=(W2, 2.7), constrained_layout=True)
yy = np.arange(len(ROW6))[::-1]
for ax, col, xl, ttl in [(axs[0], "j_per_token", "GPU energy per token (J)", "(a) Energy per generated token"),
                         (axs[1], "energy_ratio_sd_over_std", "SD energy / standard energy (same prompt and length)", "(b) Energy relative to standard decoding")]:
    for k, r in enumerate(ROW6):
        d = ee[ee.row == r]
        if col == "energy_ratio_sd_over_std" and "standard" in r: continue
        prec = r.split()[0]; std_ = "standard" in r; fixed = "FP16 draft" in r and prec != "FP16"
        jit = (np.linspace(-0.18, 0.18, len(d)) if len(d) > 1 else np.zeros(1))
        ax.plot(d[col], yy[k] + jit, linestyle="none", marker="s" if fixed else ("D" if std_ else "o"),
                markerfacecolor="white" if fixed else PC[prec], markeredgecolor=PC[prec], markersize=4.5, markeredgewidth=1.2, alpha=0.9)
        ax.plot([d[col].median()] * 2, [yy[k] - 0.32, yy[k] + 0.32], color=INK, linewidth=1.6)
    ax.set_yticks(yy, [RLAB[r] for r in ROW6]); ax.set_xlabel(xl); ax.set_title(ttl); ax.grid(axis="y", visible=False)
axs[1].axvline(1, color=INK2, linewidth=1); axs[1].set_yticklabels([])
save(fig, "Fig6_energy")

# ---------------------------------------------------------------- Fig 7: output equivalence
Mt = matrix("matched_tokens"); Lm = np.array([[L for _, L in COLS]] * len(ROWS))
txt = [[("=" if Mt[i, j] == Lm[i, j] else f"{int(Mt[i,j])}") for j in range(Mt.shape[1])] for i in range(Mt.shape[0])]
gseq = LinearSegmentedColormap.from_list("g", ["#f0efec", "#9ec5f4", "#2a78d6", "#104281"])
fig, ax = plt.subplots(figsize=(W2, 3.3), constrained_layout=True)
im = heat(ax, Mt / Lm, gseq, plt.Normalize(0, 1), "{:.2f}", txt)
cb = fig.colorbar(im, ax=ax, shrink=0.8, pad=0.01); cb.set_label("Fraction of SD tokens identical to standard output"); cb.outline.set_visible(False)
save(fig, "Fig7_output_equivalence")
print("figures done")
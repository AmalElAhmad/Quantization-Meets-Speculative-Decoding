"""Gradient-boosting comparison for the prediction model (report Section 4.2, Option C) - see src/qsd/gradient_boosting.py.

Usage:  python scripts/full_gradient_boosting.py <FULL runs folder> <output folder>
        (make full_gradient_boosting  ->  data/raw/full  results/full/prediction)

Outputs (predicted / calculated values, see the module docstring):
  G1_gb_predictions.csv     every test prediction of B0/B0x, M1/MJ and GB1, GB2 (one row per configuration per split)
  G2_gb_errors.csv          errors per split with 95% bootstrap CIs (same code and seed as P2_errors.csv)
  G3_gb_by_length.csv       errors per split x length mode (point values) with the noise floor
  G4_gb_hyperparameters.csv hyperparameters chosen by inner cross-validation in every training set
Runs in about 10-20 minutes on a laptop CPU (grid search). The other prediction outputs are not touched.
"""
import os
import sys
import warnings

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from qsd import prediction_full as pf, gradient_boosting as gb

warnings.simplefilter("ignore", FutureWarning)
RUNS, OUT = sys.argv[1:3]
os.makedirs(OUT, exist_ok=True)

d = pf.load_configs(RUNS)                        # the same 360 SD configurations as M1
m1_pred = pf.run_all(d)                          # M1, MJ and the baselines on the same splits
pred, params = gb.run_all(d, m1_pred)

keep = ["split", "fold", "pair", "target_precision", "draft_precision", "draft_mode", "gamma", "prompt_id", "length_mode",
        "output_length", "n_verify_steps", "proposed_total", "sd_lat_med", "run_cv",
        "pred_B0", "pred_B0x", "pred_M1", "pred_MJ", "pred_GB1", "pred_GB2"]
pred[keep].to_csv(f"{OUT}/G1_gb_predictions.csv", index=False)

# Only the naive baseline, M1 (MJ in the draft swap) and the two gradient-boosting models are compared here.
compared = pred.drop(columns=[c for c in pred if c.startswith("pred_") and c not in keep])
pf.error_table(compared).to_csv(f"{OUT}/G2_gb_errors.csv", index=False)
pf.error_table(compared, by=("split", "length_mode"), ci=False).to_csv(f"{OUT}/G3_gb_by_length.csv", index=False)
params.to_csv(f"{OUT}/G4_gb_hyperparameters.csv", index=False)
print("gradient-boosting comparison written to", OUT)

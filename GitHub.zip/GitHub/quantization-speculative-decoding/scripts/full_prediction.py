"""Prediction model on the FULL experiment (report Section 4.2) - runs the model in src/qsd/prediction_full.py and writes every table and figure.

Usage:  python scripts/full_prediction.py <FULL runs folder> <pilot results folder> <output folder>
        (make full_prediction  ->  data/raw/full  results/pilot  results/full/prediction)

Outputs (all CSV values are measured / calculated / predicted, see the module docstring):
  predictions_all_splits.csv   every test prediction of every split (one row per configuration per split)
  P1_round_times.csv           fitted t_check, t_draft on all data (M1, M1i, M1m, joint)
  P1b_split_diagnostics.csv    per split and pair: training size, rounds-proposed correlation, fitted times
  P2_errors.csv                errors per split, all models, 95% bootstrap CIs, + external check (pilot -> FULL)
  P3a_errors_by_length.csv     MAPE etc. per split x length mode (point values) with noise floor
  P3b_errors_by_pair.csv       MAPE etc. per split x precision pair (point values) with noise floor
  P2c_residual_structure.csv   M1 held-out errors vs noise floor, median signed error per factor (is anything left to learn?)
  P4_direction.csv             faster/slower agreement
  P5_break_even.csv            rho vs rho* per pair x gamma x drafting mode + pooled row
  P6_ma_predictions.csv        analytical acceptance model MA (tests S1 new gamma, S2 new prompt; fixed drafting)
  P6a_ma_errors.csv            MA errors with 95% bootstrap CIs; P6b by gamma and length mode (point values)
  P6c_alpha.csv                alpha (MLE) per pair x gamma and per prompt x gamma
  P6d_position_acceptance.csv  acceptance probability by draft position (equal-probability check)
  P6e_ma_components.csv        where MA's error comes from: error of tokens per round k, and standard vs SD length L
  F3_acceptance_model.png/.pdf
  F1_predicted_vs_measured.png/.pdf, F2_break_even.png/.pdf, tables_4_2_full.tex, facts_4_2_full.json
The pilot 4.2 results in results/pilot/prediction are not touched.
"""
import json
import os
import sys
import warnings

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

from qsd import prediction_full as pf, full
from qsd.prediction import load_sd_configs, PAIRS

warnings.simplefilter("ignore", FutureWarning)
RUNS, S3, OUT = sys.argv[1:4]
os.makedirs(OUT, exist_ok=True)

# ----------------------------------------------------------------------------------------- 1. data and predictions
d = pf.load_configs(RUNS)                       # 360 SD configurations
pred = pf.run_all(d)                            # all splits
pred.to_csv(f"{OUT}/predictions_all_splits.csv", index=False)

# ----------------------------------------------------------------------------------------- 2. tables
coef = pf.coefficient_table(d); coef.to_csv(f"{OUT}/P1_round_times.csv", index=False)
diag = pf.split_diagnostics(d); diag.to_csv(f"{OUT}/P1b_split_diagnostics.csv", index=False)

err = pf.error_table(pred)
# external check: round times fitted on the pilot (Stage 1-3) predict FULL SD times (existing qsd.full code, unchanged)
ext_pred, _ = full.external_test(load_sd_configs(f"{S3}/sd_configs_full.csv"), full.speedups(full.load_runs(RUNS)))
ext_pred = ext_pred.rename(columns={"sd_time_s": "sd_lat_med"}).merge(
    d[["target_precision", "draft_precision", "draft_mode", "gamma", "prompt_id", "length_mode", "run_cv"]],
    on=["target_precision", "draft_precision", "draft_mode", "gamma", "prompt_id", "length_mode"])
ext_pred["split"] = "external_pilot_to_full"
ext = pf.error_table(ext_pred)
err = pd.concat([err, ext], ignore_index=True)
err.to_csv(f"{OUT}/P2_errors.csv", index=False)

by_len = pf.error_table(pred, by=("split", "length_mode"), ci=False); by_len.to_csv(f"{OUT}/P3a_errors_by_length.csv", index=False)
by_pair = pf.error_table(pred, by=("split", "pair"), ci=False); by_pair.to_csv(f"{OUT}/P3b_errors_by_pair.csv", index=False)
pf.residual_structure(pred).to_csv(f"{OUT}/P2c_residual_structure.csv", index=False)
direc = pf.direction_table(pred, d); direc.to_csv(f"{OUT}/P4_direction.csv", index=False)
be = pf.break_even(d); be.to_csv(f"{OUT}/P5_break_even.csv", index=False)

# analytical acceptance model MA (a priori) - fixed drafting only
ma = pf.analytical_acceptance(d, pred[pred.split == "held_out_prompt"]); ma.drop(columns="step_log").to_csv(f"{OUT}/P6_ma_predictions.csv", index=False)
ma_err = pf.error_table(ma); ma_err.to_csv(f"{OUT}/P6a_ma_errors.csv", index=False)
ma_by = pd.concat([pf.error_table(ma, by=("split", "gamma"), ci=False), pf.error_table(ma, by=("split", "length_mode"), ci=False)],
                  ignore_index=True); ma_by.to_csv(f"{OUT}/P6b_ma_errors_by_group.csv", index=False)
alpha_t, pos_t = pf.acceptance_diagnostics(d); alpha_t.to_csv(f"{OUT}/P6c_alpha.csv", index=False); pos_t.to_csv(f"{OUT}/P6d_position_acceptance.csv", index=False)
ma["k_error_pct"] = 100 * (ma.k_hat - ma.k_measured) / ma.k_measured
ma["L_differs"] = ma.std_generated_tokens != ma.output_length
comp = ma.groupby(["split", "gamma"]).agg(n=("k_error_pct", "size"), k_error_median_pct=("k_error_pct", "median"),
                                          k_abs_error_mean_pct=("k_error_pct", lambda x: x.abs().mean()),
                                          configs_L_differs=("L_differs", "sum")).reset_index()
comp.to_csv(f"{OUT}/P6e_ma_components.csv", index=False)

json.dump(dict(n_configs=len(d), run_cv_median_pct=100 * d.run_cv.median(),
               mape={f"{r.split}|{r.model}": round(r.MAPE_pct, 3) for r in err.itertuples()}),
          open(f"{OUT}/facts_4_2_full.json", "w", encoding="utf-8"), indent=1)

# ----------------------------------------------------------------------------------------- 3. figures (pilot style)
INK, INK2, MUTED, GRID, BASE = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7"
PC = {"FP16": "#2a78d6", "INT8": "#eb6834", "INT4": "#1baf7a"}   # same colours as the pilot figures
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.titlesize": 8, "axes.labelsize": 8,
                     "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7, "axes.edgecolor": BASE,
                     "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "text.color": INK,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID,
                     "grid.linewidth": 0.6, "axes.axisbelow": True, "savefig.dpi": 300, "figure.dpi": 150,
                     "axes.titleweight": "bold", "axes.titlelocation": "left"})
W2 = 7.16  # two-column width (inches)
PLAB = {("FP16", "FP16"): "FP16 target · FP16 draft", ("INT8", "INT8"): "INT8 target · INT8 draft",
        ("INT8", "FP16"): "INT8 target · FP16 draft", ("INT4", "INT4"): "INT4 target · INT4 draft",
        ("INT4", "FP16"): "INT4 target · FP16 draft"}


def marker(tp, dp, size=3.5):
    """Filled circle = matched draft precision, open square = FP16 draft; colour = target precision."""
    c = PC[tp]; matched = tp == dp
    return dict(color=c, marker="o" if matched else "s", markerfacecolor=c if matched else "white", markeredgecolor=c,
                linestyle="none", markersize=size, markeredgewidth=1.0)


def save(fig, name):
    for ext_ in ("png", "pdf"):
        fig.savefig(f"{OUT}/{name}.{ext_}", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def mape(split, model):
    return float(err[(err.split == split) & (err.model == model)].MAPE_pct.iloc[0])


# F1: predicted vs measured SD time, one panel per split (main model of the split)
PANELS = [("held_out_prompt", "M1", "B0", "(a) Held-out prompt"), ("gamma2_to_4_8", "M1", "B0", "(b) γ 2 → γ 4, 8"),
          ("gamma24_to_8", "M1", "B0", "(c) γ 2, 4 → γ 8"), ("fixed_to_confidence", "M1", "B0", "(d) Fixed → confidence"),
          ("confidence_to_fixed", "M1", "B0", "(e) Confidence → fixed"), ("fixed100_to_natural", "M1", "B0", "(f) 100 tokens → natural"),
          ("draft_swap", "MJ", "B0x", "(g) Draft swap (joint)"), ("external_pilot_to_full", "M1", "B0", "(h) Pilot → FULL")]
fig, axs = plt.subplots(2, 4, figsize=(W2, 3.9), constrained_layout=True)
lim = [0.15, 60]
for ax, (split, model, base, title) in zip(axs.flat, PANELS):
    g = ext_pred if split == "external_pilot_to_full" else pred[pred.split == split]
    for tp, dp in PAIRS:
        gp = g[(g.target_precision == tp) & (g.draft_precision == dp)]
        ax.plot(gp.sd_lat_med, gp[f"pred_{model}"], **marker(tp, dp), alpha=0.85)
    ax.plot(lim, lim, color=INK2, linewidth=0.9)
    ax.fill_between(lim, [v * 0.9 for v in lim], [v * 1.1 for v in lim], color=GRID, alpha=0.6, linewidth=0)
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(lim); ax.set_ylim(lim)
    for a in (ax.xaxis, ax.yaxis):
        a.set_major_locator(matplotlib.ticker.FixedLocator([0.2, 1, 5, 20]))
        a.set_major_formatter(matplotlib.ticker.FormatStrFormatter("%g"))
        a.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.set_title(title)
    ax.text(0.04, 0.97, f"{model} MAPE {mape(split, model):.1f}%\n{base} MAPE {mape(split, base):.1f}%",
            transform=ax.transAxes, va="top", fontsize=6.5, color=INK)
for ax in axs[1]:
    ax.set_xlabel("Measured SD time (s)")
for ax in axs[:, 0]:
    ax.set_ylabel("Predicted SD time (s)")
fig.legend([Line2D([0], [0], **marker(*p, size=5)) for p in PAIRS], [PLAB[p] for p in PAIRS], frameon=False,
           loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.09))
save(fig, "F1_predicted_vs_measured")

# F2: rho (draft/check time ratio) vs rho* (break-even ratio), one panel per pair
fig, axs = plt.subplots(1, 5, figsize=(W2, 2.6), sharey=True, constrained_layout=True)
ROWS = [(g_, m_) for g_ in (2, 4, 8) for m_ in ("confidence", "fixed")] + [("all", "all")]
ylab = [f"γ {g_} · {m_}" for g_, m_ in ROWS[:-1]] + ["pooled"]
for ax, (tp, dp) in zip(axs, PAIRS):
    b = be[(be.target_precision == tp) & (be.draft_precision == dp)]
    for y, (g_, m_) in zip(range(len(ROWS))[::-1], ROWS):
        r = b[(b.gamma.astype(str) == str(g_)) & (b.draft_mode == m_)].iloc[0]
        ax.plot([r.rho_star_lo, r.rho_star_hi], [y, y], color=GRID, linewidth=6, solid_capstyle="butt")
        ax.plot([r.rho_star] * 2, [y - 0.3, y + 0.3], color=INK2, linewidth=1.2)
        ax.errorbar(r.rho, y, xerr=[[r.rho - r.rho_lo], [r.rho_hi - r.rho]], fmt="none", ecolor=PC[tp], elinewidth=1, capsize=1.5)
        ax.plot(r.rho, y, **marker(tp, dp, size=4.5))
    ax.set_title(PLAB[(tp, dp)].replace(" · ", "\n"), fontsize=7)
    ax.set_xlim(0, 1.05); ax.grid(axis="y", visible=False); ax.set_xlabel("ratio")
axs[0].set_yticks(range(len(ROWS))[::-1], ylab)
fig.legend([Line2D([0], [0], color=MUTED, marker="o", linestyle="none"), Line2D([0], [0], color=GRID, linewidth=6)],
           ["ρ = t_draft / t_check (95% CI)", "break-even ρ* (95% CI); SD faster when ρ is left of it"],
           frameon=False, loc="lower center", ncol=2, bbox_to_anchor=(0.5, -0.1))
save(fig, "F2_break_even")

# F3: assumptions and accuracy of the analytical acceptance model
fig, axs = plt.subplots(1, 2, figsize=(W2, 2.5), constrained_layout=True)
ax = axs[0]
for gamma, mk_, col in [(2, "o", INK2), (4, "s", "#7a6fbf"), (8, "^", INK)]:
    g = pos_t[pos_t.gamma == gamma]
    ax.plot(g.position, g.p_accept, marker=mk_, color=col, linewidth=1.2, markersize=4.5, label=f"γ = {gamma}")
ax.set_xlabel("Draft position j"); ax.set_ylabel("P(accept j | 1..j−1 accepted)"); ax.set_ylim(0.6, 0.95)
ax.set_title("(a) Acceptance by draft position (fixed drafting)"); ax.legend(frameon=False, loc="lower right")
ax = axs[1]
for (tp, dp) in PAIRS:
    g = ma[(ma.split == "MA_S1_new_gamma") & (ma.target_precision == tp) & (ma.draft_precision == dp)]
    ax.plot(g.k_measured, g.k_hat, **marker(tp, dp), alpha=0.85)
ax.plot([1, 9.5], [1, 9.5], color=INK2, linewidth=0.9)
ax.set_xlim(1, 9.5); ax.set_ylim(1, 9.5)
ax.set_xlabel("Tokens per round, from the run"); ax.set_ylabel("Tokens per round, model MA")
ax.set_title("(b) S1: α from γ 2 → k at γ 4, 8")
fig.legend([Line2D([0], [0], **marker(*p, size=5)) for p in PAIRS], [PLAB[p] for p in PAIRS], frameon=False,
           loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.17))
save(fig, "F3_acceptance_model")

# ----------------------------------------------------------------------------------------- 4. LaTeX tables (booktabs)
SPLAB = {"held_out_prompt": "Held-out prompt", "gamma2_to_4_8": r"$\gamma$ 2 $\rightarrow$ 4, 8",
         "gamma24_to_8": r"$\gamma$ 2, 4 $\rightarrow$ 8", "fixed_to_confidence": r"Fixed $\rightarrow$ confidence",
         "confidence_to_fixed": r"Confidence $\rightarrow$ fixed", "fixed100_to_natural": r"100 tokens $\rightarrow$ natural",
         "draft_swap": "Draft swap", "external_pilot_to_full": r"Pilot $\rightarrow$ FULL"}
TP = {p: f"{p[0]} / {p[1]}" for p in PAIRS}
L = [r"% Generated by scripts/full_prediction.py - requires \usepackage{booktabs}",
     r"\begin{table}[t]", r"\centering",
     r"\caption{Per-round times fitted on all FULL configurations of each pair (calculated).}",
     r"\label{tab:round_times_full}", r"\small", r"\begin{tabular}{llrrrrr}", r"\toprule",
     r"Model & Target / draft & $n$ & $t_{\mathrm{check}}$ (ms) & $t_{\mathrm{draft}}$ (ms) & $\rho$ & $R^2$ \\", r"\midrule"]
for _, r in coef.iterrows():
    L.append(f"{r.model} & {TP[(r.target_precision, r.draft_precision)]} & {r.n} & {r.t_check_ms:.1f} & {r.t_draft_ms:.1f} & {r.rho:.3f} & {r.r2:.3f} \\\\")
L += [r"\bottomrule", r"\end{tabular}", r"\end{table}", "",
      r"\begin{table}[t]", r"\centering",
      r"\caption{Out-of-sample error of the predicted SD time (FULL). 95\% bootstrap CIs in brackets.}",
      r"\label{tab:prediction_error_full}", r"\small", r"\begin{tabular}{llrrrr}", r"\toprule",
      r"Test split & Model & $n$ & MAE (s) & MAPE (\%) & Bias (s) \\", r"\midrule"]
for s in SPLAB:
    g = err[err.split == s]
    for j, (_, r) in enumerate(g.iterrows()):
        L.append(f"{SPLAB[s] if j == 0 else ''} & {r.model} & {r.n_test} & {r.MAE_s:.2f} [{r.MAE_s_lo:.2f}, {r.MAE_s_hi:.2f}] & "
                 f"{r.MAPE_pct:.1f} [{r.MAPE_pct_lo:.1f}, {r.MAPE_pct_hi:.1f}] & {r.bias_s:+.2f} \\\\")
    L.append(r"\midrule" if s != "external_pilot_to_full" else r"\bottomrule")
L += [r"\end{tabular}", r"\end{table}", "",
      r"\begin{table}[t]", r"\centering",
      r"\caption{Direction (SD faster or slower) from the predicted SD time: correct / total.}",
      r"\label{tab:direction_full}", r"\small", r"\begin{tabular}{llrrrr}", r"\toprule",
      r"Test split & Model & All & Clear verdict & Majority (all) & Majority (clear) \\", r"\midrule"]
for s in [k for k in SPLAB if k in set(direc.split)]:
    g = direc[direc.split == s]
    for j, (_, r) in enumerate(g.iterrows()):
        L.append(f"{SPLAB[s] if j == 0 else ''} & {r.model} & {r.correct}/{r.n} & {r.correct_clear}/{r.n_clear} & "
                 f"{r.majority_correct}/{r.n} & {r.majority_correct_clear}/{r.n_clear} \\\\")
L += [r"\bottomrule", r"\end{tabular}", r"\end{table}", "",
      r"\begin{table}[t]", r"\centering",
      r"\caption{Draft/check time ratio $\rho$ and break-even ratio $\rho^{*}$ (calculated). SD is faster when $\rho<\rho^{*}$.}",
      r"\label{tab:break_even_full}", r"\small", r"\begin{tabular}{llrrrrrr}", r"\toprule",
      r"Target / draft & $\gamma$ / mode & $k$ & $p$ & $\rho$ [95\% CI] & $\rho^{*}$ [95\% CI] & Median speedup & Faster \\", r"\midrule"]
for i, (_, r) in enumerate(be.iterrows()):
    lab = "pooled" if r.gamma == "all" else f"{r.gamma} / {r.draft_mode}"
    L.append(f"{TP[(r.target_precision, r.draft_precision)] if str(r.gamma) == '2' and r.draft_mode == 'confidence' else ''} & {lab} & "
             f"{r.tokens_per_round:.2f} & {r.proposed_per_round:.2f} & {r.rho:.2f} [{r.rho_lo:.2f}, {r.rho_hi:.2f}] & "
             f"{r.rho_star:.2f} [{r.rho_star_lo:.2f}, {r.rho_star_hi:.2f}] & {r.measured_median_speedup:.2f} & {r.configs_faster}/{r.n} \\\\")
    if r.gamma == "all":
        L.append(r"\midrule" if i < len(be) - 1 else r"\bottomrule")
L += [r"\end{tabular}", r"\end{table}", "",
      r"\begin{table}[t]", r"\centering",
      r"\caption{A-priori prediction with the analytical acceptance model (MA, fixed drafting). 95\% bootstrap CIs in brackets.}",
      r"\label{tab:ma_full}", r"\small", r"\begin{tabular}{llrrrr}", r"\toprule",
      r"Test & Model & $n$ & MAE (s) & MAPE (\%) & Bias (s) \\", r"\midrule"]
MALAB = {"MA_S1_new_gamma": r"S1 new $\gamma$", "MA_S2_new_prompt": "S2 new prompt"}
for s_ in MALAB:
    g = ma_err[ma_err.split == s_]
    for j, (_, r) in enumerate(g.iterrows()):
        L.append(f"{MALAB[s_] if j == 0 else ''} & {r.model} & {r.n_test} & {r.MAE_s:.2f} [{r.MAE_s_lo:.2f}, {r.MAE_s_hi:.2f}] & "
                 f"{r.MAPE_pct:.1f} [{r.MAPE_pct_lo:.1f}, {r.MAPE_pct_hi:.1f}] & {r.bias_s:+.2f} \\\\")
    L.append(r"\midrule" if s_ == "MA_S1_new_gamma" else r"\bottomrule")
L += [r"\end{tabular}", r"\end{table}"]
open(f"{OUT}/tables_4_2_full.tex", "w", encoding="utf-8").write("\n".join(L) + "\n")

print(err[["split", "model", "n_test", "MAPE_pct", "MAPE_pct_lo", "MAPE_pct_hi"]].round(2).to_string())
print(ma_err[["split", "model", "n_test", "MAPE_pct", "MAPE_pct_lo", "MAPE_pct_hi"]].round(2).to_string())

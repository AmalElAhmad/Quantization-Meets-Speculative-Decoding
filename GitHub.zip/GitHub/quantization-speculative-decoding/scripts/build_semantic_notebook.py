"""Builds notebooks/05_full_semantic_similarity_colab.ipynb (embeds src/qsd/{prediction,full,semantic}.py verbatim)."""
import json, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
def md(s): return dict(cell_type="markdown", metadata={}, source=s.strip("\n"))
def code(s): return dict(cell_type="code", metadata={}, execution_count=None, outputs=[], source=s.strip("\n"))
mods = {m: (ROOT / f"src/qsd/{m}.py").read_text() for m in ["prediction", "full", "semantic"]}
cells = [
md("""
# CENG 742 · Text-quality scores (run once, after all timed sessions)
Scores every configuration's output text against (a) standard decoding of the same precision and (b) FP16 standard decoding:
exact match, **ROUGE-L** (same wording), **BERTScore F1** (roberta-large, layer 17 — the bert-score default for English) and
**embedding cosine** (sentence-transformers all-MiniLM-L6-v2). Texts come from the timed runs themselves, so no generation happens here.
Model files are pinned to the commit hashes printed below. A T4 or CPU runtime both work (GPU is faster).

1. Run cell 1, then **Runtime → Restart session**. 2. Run cells 2–5; cell 3 asks you to upload the final ZIP of each precision.
"""),
code('!pip -q install "transformers==5.18.0" "bert-score==0.3.13" "sentence-transformers==6.2.0" pandas scipy'),
code("import os\nos.makedirs('qsd', exist_ok=True)\nopen('qsd/__init__.py', 'w').write('')\n" +
     "\n".join(f"open('qsd/{m}.py', 'w').write({src!r})" for m, src in mods.items())),
code("""
# 3 · Upload the final ZIP of each precision (FP16, INT8, INT4)
import zipfile, io, pathlib, pandas as pd
from google.colab import files
up = files.upload()
RUNS = pathlib.Path("/content/runs"); RUNS.mkdir(exist_ok=True)
for name, data in up.items():
    d = RUNS / pathlib.Path(name).stem; d.mkdir(exist_ok=True); zipfile.ZipFile(io.BytesIO(data)).extractall(d)
from qsd import full, semantic
r = full.load_runs(str(RUNS))
pairs = semantic.build_pairs(r)
print(r.groupby("target_precision").size().to_dict(), "->", len(pairs), "text pairs")
"""),
code("""
# 4 · Pinned scorers and scoring
import torch, numpy as np, bert_score, sentence_transformers, transformers, json
from huggingface_hub import HfApi, snapshot_download
REV = {m: HfApi().model_info(m).sha for m in ("FacebookAI/roberta-large", "sentence-transformers/all-MiniLM-L6-v2")}
print("Scorer model revisions:", REV)
rob = snapshot_download("FacebookAI/roberta-large", revision=REV["FacebookAI/roberta-large"])
dev = "cuda" if torch.cuda.is_available() else "cpu"
def bs(c, r):
    return bert_score.score(c, r, model_type=rob, num_layers=17, lang="en", device=dev, batch_size=32, verbose=False)[2].tolist()
st = sentence_transformers.SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2",
                                               revision=REV["sentence-transformers/all-MiniLM-L6-v2"], device=dev)
emb = lambda xs: st.encode(xs, normalize_embeddings=True, batch_size=64)
scores = semantic.score(pairs, bs, emb)
meta = dict(transformers=transformers.__version__, bert_score="0.3.13", sentence_transformers=sentence_transformers.__version__,
            revisions=REV, bertscore="roberta-large layer 17, F1, no baseline rescaling", embedding="all-MiniLM-L6-v2, cosine of normalised mean-pooled embeddings")
display(scores.groupby(["target_precision", "mode", "draft_precision", "reference"])[["rouge_l", "bertscore_f1", "embedding_cosine"]].median().round(3))
"""),
code("""
# 5 · Save and download (put semantic_scores.csv next to the runs in data/raw/full/ of the repository)
scores.drop(columns=["candidate", "reference_text"]).to_csv("semantic_scores.csv", index=False)
json.dump(meta, open("semantic_scores_meta.json", "w"), indent=2)
files.download("semantic_scores.csv"); files.download("semantic_scores_meta.json")
"""),
]
nb = dict(nbformat=4, nbformat_minor=5, metadata=dict(kernelspec=dict(name="python3", display_name="Python 3"), language_info=dict(name="python")), cells=cells)
for c in nb["cells"]:
    lines = c["source"].split("\n"); c["source"] = [l + "\n" for l in lines[:-1]] + [lines[-1]]
(ROOT / "notebooks/05_full_semantic_similarity_colab.ipynb").write_text(json.dumps(nb, indent=1)); print("wrote notebook 05")

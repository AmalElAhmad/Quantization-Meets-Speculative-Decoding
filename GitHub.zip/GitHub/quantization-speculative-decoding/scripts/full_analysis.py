"""Analysis of the FULL experiment runs (report Section 4.1) + external test of the pilot prediction model.
Usage: python scripts/full_analysis.py <folder with runs_v2.csv files> <pilot_out_dir> <out_dir>"""
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import pandas as pd
from qsd import full
from qsd.prediction import load_sd_configs

RUNS, S3, OUT = sys.argv[1:4]
os.makedirs(OUT, exist_ok=True)
r = full.load_runs(RUNS)
ck = full.checks(r); ck.to_csv(f"{OUT}/V1_checks.csv", index=False)
s = full.speedups(r); s.to_csv(f"{OUT}/V2_speedup_configs.csv", index=False)
ss = full.speedup_summary(s); ss.to_csv(f"{OUT}/V3_speedup_summary.csv", index=False)
q = full.quality(r); q.to_csv(f"{OUT}/V4_quality_configs.csv", index=False)
qs = q.groupby(["target_precision", "mode", "draft_precision", "draft_mode", "task"], dropna=False).agg(
    configs=("prompt_id", "size"), answer_correct=("answer_correct", lambda x: x.dropna().astype(float).mean() if x.notna().any() else float("nan")),
    rouge_l_same=("rouge_l_vs_same_precision_standard", "median"), rouge_l_fp16=("rouge_l_vs_fp16_standard", "median")).reset_index()
qs.to_csv(f"{OUT}/V4b_quality_summary.csv", index=False)
oe = full.order_effect(r); oe.to_csv(f"{OUT}/V5_order_effect.csv", index=False)
mem = full.memory_table(RUNS, r)
if len(mem):
    mem.to_csv(f"{OUT}/V7_memory_configs.csv", index=False)
sem = sorted(__import__("glob").glob(os.path.join(RUNS, "**", "semantic_scores.csv"), recursive=True))
if sem:  # produced by notebooks/05_full_semantic_similarity_colab.ipynb
    sm = pd.concat([pd.read_csv(f) for f in sem], ignore_index=True)
    sm.groupby(["target_precision", "mode", "draft_precision", "draft_mode", "length_mode", "reference"], dropna=False)[
        ["rouge_l", "bertscore_f1", "embedding_cosine"]].median().reset_index().to_csv(f"{OUT}/V8_semantic_summary.csv", index=False)
pred, ext = full.external_test(load_sd_configs(f"{S3}/sd_configs_full.csv"), s)
pred.to_csv(f"{OUT}/V6_external_predictions.csv", index=False); ext.to_csv(f"{OUT}/V6b_external_test.csv", index=False)
# reproducibility check: pilot vs FULL on the 39 configurations both experiments ran (E1: 30 SD, E2: 9 standard)
e1, e2 = full.pilot_equivalence(S3, r, s)
e1.to_csv(f"{OUT}/E1_equivalence_sd_shared_configs.csv", index=False); e2.to_csv(f"{OUT}/E2_equivalence_standard_shared_configs.csv", index=False)
print(ck.to_string()); print(ss.round(3).to_string()); print(qs.round(3).to_string()); print(ext.round(3).to_string())

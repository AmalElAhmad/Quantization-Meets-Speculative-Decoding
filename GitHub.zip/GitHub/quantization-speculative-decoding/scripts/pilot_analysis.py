"""CENG 742 - Efficient LLM Inference: reproducible analysis of raw results.
Usage: python scripts/pilot_analysis.py <original_results_dir> <new_logging_dir> <out_dir>
original_results_dir: contains the six extracted llm_final_* folders (all_results.csv)
new_logging_dir: contains fp16/, int4/, int8/ folders (validation_acceptance.csv, energy.csv)
No raw value is modified; corrections are applied only as documented filters.
"""
import sys, glob, os, json
import numpy as np, pandas as pd

ORIG, NEW, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(742)
B = 5000
PRECS = ["FP16", "INT8", "INT4"]
LABEL_STRAT = {"MATCHED": "Matched draft", "FIXED_FP16": "FP16 draft", "NONE": "-"}
LABEL_STAGE = {"CORE": "Draft-Length Sensitivity", "WORKLOAD": "Workload and Output-Length"}

# ---------------------------------------------------------------- load
fr = []
for f in sorted(glob.glob(os.path.join(ORIG, "*", "all_results.csv"))):
    d = pd.read_csv(f); d["batch"] = os.path.basename(os.path.dirname(f)); fr.append(d)
raw = pd.concat(fr, ignore_index=True)
raw["g"] = raw["gamma"].fillna(0).astype(int)
raw["exact_match"] = raw["exact_match"].map({True: True, False: False, "True": True, "False": False})
# group = target precision + draft strategy (FP16 target has a single FP16 draft)
def group(r):
    if r["mode"] == "STANDARD": return f"{r.target_precision} standard"
    if r.target_precision == "FP16": return "FP16 + FP16 draft"
    return f"{r.target_precision} + {'FP16' if r.draft_strategy=='FIXED_FP16' else r.target_precision} draft"
raw["group"] = raw.apply(group, axis=1)

val = pd.concat([pd.read_csv(os.path.join(NEW, p, "validation_acceptance.csv")) for p in ["fp16", "int4", "int8"]], ignore_index=True)
en = pd.concat([pd.read_csv(os.path.join(NEW, p, "energy.csv")) for p in ["fp16", "int4", "int8"]], ignore_index=True)
for d in (val, en):
    d["g"] = d["gamma"].fillna(0).astype(int)
    d["group"] = d.apply(group, axis=1)

KEYS = ["stage", "target_precision", "mode", "draft_strategy", "g", "prompt_id", "output_length"]

# ---------------------------------------------------------------- documented corrections
# (1) Peak memory inflated in the resumed INT8 WORKLOAD session for MATCHED rows (leftover models after
#     the KeyboardInterrupt in the same runtime). Excluded from memory analysis only.
MEM_EXCL = (raw.session_id == "46a79b1049") & (raw.draft_strategy == "MATCHED")
assert MEM_EXCL.sum() == 140
raw["mem_valid"] = ~MEM_EXCL
# (2) First configuration of a fresh session showed a slow start (GPU clock ramp). Pre-declared affected
#     baselines (first config measured in their session). Corrected baseline = runs <= 1.25 x min run.
FIRST_CFG = [("CORE", "FP16", "quantization", 50), ("WORKLOAD", "FP16", "factual", 50), ("CORE", "INT4", "quantization", 50)]
raw["warmup_flag"] = False
for st, p, pr, L in FIRST_CFG:
    m = (raw.stage == st) & (raw.target_precision == p) & (raw["mode"] == "STANDARD") & (raw.prompt_id == pr) & (raw.output_length == L)
    raw.loc[m, "warmup_flag"] = True
raw["steady"] = True
for _, d in raw[raw.warmup_flag].groupby(KEYS):
    raw.loc[d.index, "steady"] = d.time_s <= 1.25 * d.time_s.min()

# ---------------------------------------------------------------- T1 design & completeness
t1 = raw.groupby(["stage", "target_precision"]).agg(
    configurations=("group", lambda s: raw.loc[s.index].groupby(KEYS).ngroups),
    rows=("time_s", "size"), runs_per_config=("run", "max"),
    sessions=("session_id", "nunique"), duplicates=("time_s", lambda s: int(raw.loc[s.index].duplicated(KEYS + ["run"]).sum())),
    excluded_memory_rows=("mem_valid", lambda s: int((~s).sum()))).reset_index()
t1["validation_hash_match"] = t1.apply(lambda r: f"{int(val[(val.stage==r.stage)&(val.target_precision==r.target_precision)].hash_matches_original.sum())}/{len(val[(val.stage==r.stage)&(val.target_precision==r.target_precision)])}", axis=1)
t1.to_csv(f"{OUT}/T1_design_completeness.csv", index=False)

# ---------------------------------------------------------------- per-config summary
def boot_ratio_median(a, b):
    a, b = np.asarray(a), np.asarray(b)
    ia = rng.integers(0, len(a), (B, len(a))); ib = rng.integers(0, len(b), (B, len(b)))
    r = np.median(a[ia], axis=1) / np.median(b[ib], axis=1)
    return np.percentile(r, [2.5, 97.5])

cfg = raw.groupby(KEYS + ["group", "draft_precision"]).agg(
    n=("time_s", "size"), lat_med=("time_s", "median"), lat_mean=("time_s", "mean"), lat_sd=("time_s", "std"),
    lat_min=("time_s", "min"), lat_max=("time_s", "max"),
    mem_mb=("peak_gpu_memory_mb", lambda s: s[raw.loc[s.index, "mem_valid"]].mean() if raw.loc[s.index, "mem_valid"].any() else np.nan),
    exact_match=("exact_match", lambda s: s.dropna().astype(float).mean() if s.notna().any() else np.nan),
    token_agreement=("token_agreement", "mean"), output_hash=("output_hash", "first"),
    warmup_flag=("warmup_flag", "any"), input_tokens=("input_tokens", "first")).reset_index()
cfg["cv"] = cfg.lat_sd / cfg.lat_mean
cfg["tok_per_s"] = cfg.output_length / cfg.lat_med
steady_med = raw[raw.steady].groupby(KEYS).time_s.median().rename("lat_med_steady")
cfg = cfg.merge(steady_med, on=KEYS, how="left")

# speedup vs matched STANDARD (same batch/precision/prompt/length)
rows = []
for _, s in cfg[cfg["mode"] == "SD"].iterrows():
    m = (raw.stage == s.stage) & (raw.target_precision == s.target_precision) & (raw["mode"] == "STANDARD") & (raw.prompt_id == s.prompt_id) & (raw.output_length == s.output_length)
    base = raw[m]; sd = raw[(raw[KEYS] == s[KEYS].values).all(axis=1)]
    lo, hi = boot_ratio_median(base.time_s, sd.time_s)
    flagged = base.warmup_flag.any()
    base_c = base[base.steady].time_s
    sp_c = base_c.median() / sd.time_s.median()
    lo_c, hi_c = boot_ratio_median(base_c, sd.time_s) if flagged else (lo, hi)
    rows.append(dict(**{k: s[k] for k in KEYS}, group=s.group, draft_precision=s.draft_precision, std_lat_med=base.time_s.median(), sd_lat_med=sd.time_s.median(),
                     speedup_raw=base.time_s.median() / sd.time_s.median(), ci_lo_raw=lo, ci_hi_raw=hi,
                     baseline_warmup_flag=flagged, std_lat_med_corrected=base_c.median(),
                     speedup=sp_c, ci_lo=lo_c, ci_hi=hi_c,
                     std_mem=cfg[(cfg.stage == s.stage) & (cfg.target_precision == s.target_precision) & (cfg["mode"] == "STANDARD") & (cfg.prompt_id == s.prompt_id) & (cfg.output_length == s.output_length)].mem_mb.iloc[0],
                     sd_mem=s.mem_mb, exact_match=s.exact_match, matched_tokens=round(s.token_agreement * s.output_length)))
sp = pd.DataFrame(rows)
sp["verdict"] = np.where(sp.ci_lo > 1, "speedup", np.where(sp.ci_hi < 1, "slowdown", "no clear difference"))

# acceptance
v = val.copy()
v["steps"] = v.step_log.apply(lambda s: json.loads(s) if isinstance(s, str) else [])
v["proposed_total"] = v.steps.apply(lambda s: sum(p for p, _ in s))
v["accepted_total"] = v.steps.apply(lambda s: sum(a for _, a in s))
acc = v[v["mode"] == "SD"][KEYS + ["group", "acceptance_rate", "mean_proposed_per_step", "mean_accepted_per_step", "n_verify_steps", "proposed_total", "accepted_total", "hash_matches_original"]]
sp = sp.merge(acc.drop(columns="group"), on=KEYS, how="left")
sp.to_csv(f"{OUT}/sd_configs_full.csv", index=False)
cfg.to_csv(f"{OUT}/all_configs_summary.csv", index=False)

# ---------------------------------------------------------------- T2 quantization (STANDARD)
std = cfg[cfg["mode"] == "STANDARD"].copy()
std["ms_per_token"] = 1000 * np.where(std.warmup_flag, std.lat_med_steady, std.lat_med) / std.output_length
e_std = en[en["mode"] == "STANDARD"].groupby(["target_precision"]).agg(j_per_token=("energy_per_token_j", "median"), power_w=("avg_power_w", "median")).reset_index()
t2 = std.groupby("target_precision").agg(ms_per_token_med=("ms_per_token", "median"), ms_per_token_min=("ms_per_token", "min"), ms_per_token_max=("ms_per_token", "max"),
                                         peak_mem_mb=("mem_mb", "mean")).reset_index().merge(e_std, on="target_precision")
fp = t2.set_index("target_precision")
t2["latency_vs_fp16"] = t2.ms_per_token_med / fp.loc["FP16", "ms_per_token_med"]
t2["memory_vs_fp16"] = t2.peak_mem_mb / fp.loc["FP16", "peak_mem_mb"] - 1
t2["energy_vs_fp16"] = t2.j_per_token / fp.loc["FP16", "j_per_token"]
t2 = t2.set_index("target_precision").loc[PRECS].reset_index()
t2.to_csv(f"{OUT}/T2_quantization.csv", index=False)

# draft memory overhead
memo = cfg[(cfg["mode"] == "SD") & cfg.mem_mb.notna()].groupby(["target_precision", "draft_precision"]).mem_mb.mean().reset_index()
memo = memo.merge(t2[["target_precision", "peak_mem_mb"]], on="target_precision")
memo["draft_overhead_mb"] = memo.mem_mb - memo.peak_mem_mb
memo.to_csv(f"{OUT}/T2b_sd_memory.csv", index=False)

# ---------------------------------------------------------------- T3 speedup summary
def summ(d):
    return pd.Series(dict(configs=len(d), speedup_median=d.speedup.median(), speedup_min=d.speedup.min(), speedup_max=d.speedup.max(),
                          n_speedup=(d.verdict == "speedup").sum(), n_slowdown=(d.verdict == "slowdown").sum(), n_unclear=(d.verdict == "no clear difference").sum()))
t3 = sp.groupby(["stage", "group", "g"]).apply(summ, include_groups=False).reset_index()
t3.to_csv(f"{OUT}/T3_speedup_summary.csv", index=False)

# ---------------------------------------------------------------- T4 acceptance summary
def asumm(d):
    return pd.Series(dict(configs=len(d), acceptance_pooled=d.accepted_total.sum() / d.proposed_total.sum(), acceptance_min=d.acceptance_rate.min(),
                          acceptance_max=d.acceptance_rate.max(), mean_proposed_per_step=d.mean_proposed_per_step.mean(),
                          mean_accepted_per_step=d.mean_accepted_per_step.mean()))
t4 = sp.groupby(["stage", "group", "g"]).apply(asumm, include_groups=False).reset_index()
t4.to_csv(f"{OUT}/T4_acceptance_summary.csv", index=False)
t4w = sp[sp.stage == "WORKLOAD"].groupby(["group", "prompt_id"]).apply(asumm, include_groups=False).reset_index()
t4w.to_csv(f"{OUT}/T4b_acceptance_by_workload.csv", index=False)
# matched vs fixed acceptance difference (same precision, gamma, prompt, length)
mf = sp[sp.target_precision != "FP16"].pivot_table(index=["stage", "target_precision", "g", "prompt_id", "output_length"], columns="draft_strategy", values=["acceptance_rate", "speedup"]).dropna()
mf.columns = [f"{a}_{b}" for a, b in mf.columns]
mf["acc_diff_fixed_minus_matched"] = mf.acceptance_rate_FIXED_FP16 - mf.acceptance_rate_MATCHED
mf["speedup_ratio_fixed_over_matched"] = mf.speedup_FIXED_FP16 / mf.speedup_MATCHED
mf.reset_index().to_csv(f"{OUT}/T4c_matched_vs_fp16draft.csv", index=False)

# correlation acceptance vs speedup (Spearman, descriptive)
from scipy.stats import spearmanr
corr = []
for gname, d in sp.groupby("group"):
    r, p = spearmanr(d.acceptance_rate, d.speedup); corr.append(dict(group=gname, n=len(d), spearman_rho=r, p_value=p))
r, p = spearmanr(sp.acceptance_rate, sp.speedup); corr.append(dict(group="ALL", n=len(sp), spearman_rho=r, p_value=p))
pd.DataFrame(corr).to_csv(f"{OUT}/T4d_acceptance_speedup_correlation.csv", index=False)

# ---------------------------------------------------------------- cost decomposition (descriptive regression)
# SD latency ~ a + c_verify * (verification steps) + c_draft * (draft tokens proposed); fitted per target/draft precision pair
dec = []
for (tp, dp), d in sp.groupby(["target_precision", "draft_precision"]):
    X = np.column_stack([np.ones(len(d)), d.n_verify_steps, d.proposed_total]); y = d.sd_lat_med.values
    coef, *_ = np.linalg.lstsq(X, y, rcond=None); pred = X @ coef
    r2 = 1 - ((y - pred) ** 2).sum() / ((y - y.mean()) ** 2).sum()
    s = std[(std.target_precision == tp) & (std.stage == "WORKLOAD")]
    b = np.polyfit(s.output_length, np.where(s.warmup_flag, s.lat_med_steady, s.lat_med), 1)[0]  # corrected baselines
    dec.append(dict(target_precision=tp, draft_precision=dp, n=len(d), intercept_s=coef[0], c_verify_ms=1000 * coef[1], c_draft_ms=1000 * coef[2],
                    r2=r2, standard_ms_per_token_slope=1000 * b, draft_to_verify_cost_ratio=coef[2] / coef[1]))
pd.DataFrame(dec).to_csv(f"{OUT}/T4e_cost_decomposition.csv", index=False)

# ---------------------------------------------------------------- T5 energy
e = en.groupby(KEYS + ["group"]).agg(n=("run", "size"), energy_j=("energy_j", "median"), energy_sd=("energy_j", "std"),
                                    j_per_token=("energy_per_token_j", "median"), net_j=("net_energy_j", "median"),
                                    power_w=("avg_power_w", "median"), time_s=("time_s", "median"),
                                    orig_time_s=("original_median_latency_s", "first"), sm_clock=("sm_clock_start", "median"),
                                    temp_c=("temp_start_c", "median"), idle_w=("idle_power_w", "first"),
                                    hash_ok=("hash_matches_original", "all")).reset_index()
eb = e[e["mode"] == "STANDARD"][["stage", "target_precision", "prompt_id", "output_length", "energy_j", "time_s", "sm_clock"]].rename(
    columns={"energy_j": "std_energy_j", "time_s": "std_time_s", "sm_clock": "std_sm_clock"})
e = e.merge(eb, on=["stage", "target_precision", "prompt_id", "output_length"], how="left")
e["energy_ratio_sd_over_std"] = np.where(e["mode"] == "SD", e.energy_j / e.std_energy_j, np.nan)
e["time_ratio_sd_over_std"] = np.where(e["mode"] == "SD", e.time_s / e.std_time_s, np.nan)
e["session_time_vs_original"] = e.time_s / e.orig_time_s
e.to_csv(f"{OUT}/T5_energy_configs.csv", index=False)
t5 = e.groupby(["group"]).agg(configs=("n", "size"), j_per_token_med=("j_per_token", "median"), j_per_token_min=("j_per_token", "min"),
                               j_per_token_max=("j_per_token", "max"), power_w_med=("power_w", "median"),
                               energy_ratio_med=("energy_ratio_sd_over_std", "median"), energy_ratio_min=("energy_ratio_sd_over_std", "min"),
                               energy_ratio_max=("energy_ratio_sd_over_std", "max"), time_ratio_med=("time_ratio_sd_over_std", "median"),
                               sm_clock_med=("sm_clock", "median"), temp_c_med=("temp_c", "median"),
                               session_time_vs_original_med=("session_time_vs_original", "median")).reset_index()
t5.to_csv(f"{OUT}/T5_energy_summary.csv", index=False)

# ---------------------------------------------------------------- T6 output equivalence
t6 = sp.groupby(["stage", "group"]).agg(configs=("speedup", "size"), exact_match_configs=("exact_match", lambda s: int((s == 1).sum())),
                                        min_matched_tokens=("matched_tokens", "min"), median_matched_tokens=("matched_tokens", "median")).reset_index()
t6.to_csv(f"{OUT}/T6_output_equivalence.csv", index=False)
deterministic = raw.groupby(KEYS).output_hash.nunique().max() == 1
cross_prec = raw[raw["mode"] == "STANDARD"].groupby(["stage", "prompt_id", "output_length"]).output_hash.nunique()

# ---------------------------------------------------------------- latency-memory trade-off (workload cells)
tr = []
for (p, L), d in cfg[cfg.stage == "WORKLOAD"].groupby(["prompt_id", "output_length"]):
    d = d.copy(); d["lat"] = np.where(d.warmup_flag, d.lat_med_steady, d.lat_med)
    core_mem = cfg[(cfg.stage == "CORE")].groupby(["target_precision", "draft_strategy"]).mem_mb.mean()
    d["mem"] = d.mem_mb.fillna(pd.Series(core_mem.reindex(list(zip(d.target_precision, d.draft_strategy))).values, index=d.index))
    d = d.sort_values(["lat", "mem"]); best = np.inf
    for _, r in d.iterrows():
        on = r.mem < best
        if on: best = r.mem
        tr.append(dict(prompt_id=p, output_length=L, config=f"{r.group}" + (f" g={r.g}" if r["mode"] == "SD" else ""), latency_s=r.lat, mem_mb=r.mem, pareto=on))
pd.DataFrame(tr).to_csv(f"{OUT}/T7_tradeoff.csv", index=False)

facts = dict(rows=len(raw), configs=raw.groupby(KEYS).ngroups, deterministic_outputs_within_config=bool(deterministic),
             standard_outputs_distinct_across_precisions=int(cross_prec.min()), validation_hash_match=f"{int(val.hash_matches_original.sum())}/{len(val)}",
             energy_hash_match=f"{int(en.hash_matches_original.sum())}/{len(en)}", median_cv=float(cfg.cv.median()),
             configs_cv_over_10pct=int((cfg.cv > 0.10).sum()), energy_method=sorted(en.energy_method.unique().tolist()),
             idle_power_w={p: float(en[en.target_precision == p].idle_power_w.iloc[0]) for p in PRECS},
             mem_excluded_rows=int(MEM_EXCL.sum()))
json.dump(facts, open(f"{OUT}/facts.json", "w"), indent=2)
pd.to_pickle(dict(raw=raw, cfg=cfg, sp=sp, val=v, en=en, e=e, t2=t2, memo=memo, dec=pd.DataFrame(dec)), f"{OUT}/analysis.pkl")
print(json.dumps(facts, indent=1))

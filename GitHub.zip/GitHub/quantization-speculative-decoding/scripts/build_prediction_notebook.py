"""Builds notebooks/06_full_prediction_model.ipynb - the 4.2 FULL prediction model, step by step (CPU; Colab or local).
The notebook imports the model from src/qsd/prediction_full.py (no copy), so notebook and `make full_prediction` always agree."""
import json, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
def md(s): return dict(cell_type="markdown", metadata={}, source=s.strip("\n"))
def code(s): return dict(cell_type="code", metadata={}, execution_count=None, outputs=[], source=s.strip("\n"))

cells = [
md("""
# Prediction model on the FULL experiment

**What this notebook does.** It predicts the time of every speculative-decoding (SD) configuration of the FULL experiment
from its round counts, using

$$T_{SD} = t_{check}\\times \\text{rounds} + t_{draft}\\times \\text{proposed tokens}$$

It then tests the predictions on configurations the fit never saw and writes all tables, figures and LaTeX tables
into a results folder and also packs that folder into one ZIP file.

**What it does not do.** It runs no new GPU experiment. It uses only the FULL runs already recorded in the repository
(`data/raw/full/`). **No GPU is needed** (in Colab, the default CPU runtime is enough). Run time is about 2 minutes.

---
### How to run: choose ONE of the options

**Option 1 · Google Colab with the repository ZIP on Google Drive (recommended in Colab)**
1. Upload `quantization-speculative-decoding.zip` to the top level of your Google Drive (*My Drive*).
2. Open this notebook in Colab (File → Upload notebook, or open it from Drive).
3. Choose **Runtime → Run all**. When asked, allow access to Google Drive.
4. At the end, the ZIP file with the results downloads automatically, and a copy is saved in *My Drive*.

**Option 2 · Google Colab with an upload**
Same as Option 1, but with `REPO_SOURCE = "upload"` in the setup cell. Colab then shows an upload button; choose
`quantization-speculative-decoding.zip` (about 16 MB).

**Option 3 · Google Colab from GitHub (after the repository is published)**
Set `REPO_SOURCE = "github"` and `GITHUB_URL` in the setup cell. For a private repository, use a URL with an access token.

**Option 4 · Your own computer**
1. Unzip `quantization-speculative-decoding.zip` and open a terminal in the `quantization-speculative-decoding` folder.
2. Install once: `pip install -r requirements.txt jupyter`
3. Start `jupyter notebook` (or VS Code), open `notebooks/06_full_prediction_model.ipynb` and choose **Run All**.
4. The results are saved in `results/full/prediction_local_<date-time>/` and as a ZIP file with the same name.
   The last cell prints the exact location.

**Package versions.** The results stored in the repository were produced with the versions in `requirements.txt`.
Colab uses its own versions, and the notebook does not change them. The last cell compares your numbers with the stored
results and saves your package versions with your results, so any difference is visible.

Where the model lives: `src/qsd/prediction_full.py`. Every step below calls a function from that file.
To see the code of a step, run `show(<function>)`.
"""),
code("""
# 0 · Setup: get the repository, import the model, record versions
REPO_SOURCE = "drive"          # Colab only: "drive" (Option 1), "upload" (Option 2) or "github" (Option 3)
DRIVE_ZIP = "/content/drive/MyDrive/quantization-speculative-decoding.zip"   # Option 1: where the repository ZIP is on Drive
GITHUB_URL = ""                # Option 3: e.g. "https://github.com/<user>/<repo>.git"

import sys, os, pathlib, inspect, platform, datetime, json, zipfile, subprocess
IN_COLAB = "google.colab" in sys.modules

def find_repo(start):
    \"\"\"Walk up from `start` until a folder containing src/qsd is found (None if there is none).\"\"\"
    p = pathlib.Path(start).resolve()
    for q in [p, *p.parents]:
        if (q / "src" / "qsd").exists():
            return q
    for q in pathlib.Path(start).glob("*/"):        # also look one level down (e.g. /content/quantization-speculative-decoding)
        if (q / "src" / "qsd").exists():
            return q.resolve()
    return None

ROOT = find_repo(pathlib.Path.cwd())
if ROOT is None and IN_COLAB:
    os.chdir("/content")
    if REPO_SOURCE == "drive":
        from google.colab import drive
        drive.mount("/content/drive")
        assert os.path.exists(DRIVE_ZIP), f"Repository ZIP not found at {DRIVE_ZIP}. Upload it to My Drive or change DRIVE_ZIP."
        zipfile.ZipFile(DRIVE_ZIP).extractall("/content")
    elif REPO_SOURCE == "upload":
        from google.colab import files
        up = files.upload()                          # choose quantization-speculative-decoding.zip
        zipfile.ZipFile(next(iter(up))).extractall("/content")
    elif REPO_SOURCE == "github":
        assert GITHUB_URL, "Set GITHUB_URL first"
        subprocess.run(["git", "clone", "--depth", "1", GITHUB_URL, "/content/repo"], check=True)
    ROOT = find_repo("/content")
assert ROOT is not None, "Repository not found. Run this notebook inside the unzipped quantization-speculative-decoding folder (see Option 4)."
sys.path.insert(0, str(ROOT / "src"))

import numpy as np, pandas as pd, scipy, matplotlib
from IPython.display import display, Image, Markdown
from qsd import prediction_full as pf
from qsd.prediction import fit_round_times

pd.set_option("display.width", 200, "display.max_columns", 30)
def show(fn):
    \"\"\"Print the source code of a model function.\"\"\"
    print(inspect.getsource(fn))

STAMP = datetime.datetime.now().strftime("%Y%m%d_%H%M")
OUT = ROOT / "results" / "full" / f"prediction_local_{STAMP}"
ENV = dict(where="colab" if IN_COLAB else "local", python=platform.python_version(), platform=platform.platform(),
           numpy=np.__version__, pandas=pd.__version__, scipy=scipy.__version__, matplotlib=matplotlib.__version__, run_at=STAMP)
print("Repository:", ROOT); print("Output folder:", OUT); print(ENV)
"""),
md("""
## Step 1 · Data: one row per SD configuration
A configuration = target precision × draft precision × γ × drafting mode × prompt × length mode. FULL has
**360 SD configurations** (5 precision pairs × 72), each run 5 times. Per configuration we use:

| column | meaning | label |
|---|---|---|
| `sd_lat_med` | median SD time of the 5 runs (s) | measured |
| `n_verify_steps` | rounds (target checks) | measured |
| `proposed_total` | draft tokens proposed | measured |
| `output_length` | output tokens | measured |
| `std_time_s` | median standard (non-SD) time, same prompt and length | measured |
| `speedup` | `std_time_s / sd_lat_med` | calculated |
| `run_cv` | run-to-run variation of the 5 runs (noise floor) | calculated |
"""),
code("""
d = pf.load_configs(str(ROOT / "data" / "raw" / "full"))
print(len(d), "SD configurations")
display(d.groupby("pair").size().rename("configurations").to_frame())
cols = ["pair", "gamma", "draft_mode", "prompt_id", "length_mode", "output_length", "n_verify_steps", "proposed_total",
        "sd_lat_med", "std_time_s", "speedup", "run_cv"]
display(d[cols].head(8).round(3))
"""),
md("""
## Step 2 · The fit: how t_check and t_draft are calculated
For one precision pair we choose the two times so that `t_check × rounds + t_draft × proposed` is as close as possible
to the measured times (least squares). Both times must be ≥ 0 (non-negative least squares, NNLS), and there is no constant
term. The next cell does this **by hand** with `scipy.optimize.nnls` for INT8 target + FP16 draft on all 72 configurations.
It then checks that the model function `fit_round_times` gives the same numbers.
"""),
code("""
from scipy.optimize import nnls
g = d[d.pair == "INT8+FP16"]
X = g[["n_verify_steps", "proposed_total"]].to_numpy(float)   # one row per configuration: [rounds, proposed]
y = g["sd_lat_med"].to_numpy(float)                           # measured SD time (s)
(t_check, t_draft), _ = nnls(X, y)
print(f"By hand:             t_check = {1000*t_check:.1f} ms   t_draft = {1000*t_draft:.1f} ms")
c = fit_round_times(g)
print(f"fit_round_times():   t_check = {1000*c['t_verify']:.1f} ms   t_draft = {1000*c['t_draft']:.1f} ms")
"""),
md("""
## Step 3 · Worked example: one prediction the fit never saw
Held-out-prompt test. Fit on the 60 INT8+FP16 configurations of the other five prompts, then predict
γ = 4, fixed drafting, prompt `factual`, 100 tokens.
"""),
code("""
train = d[(d.pair == "INT8+FP16") & (d.prompt_id != "factual")]
row = d[(d.pair == "INT8+FP16") & (d.prompt_id == "factual") & (d.gamma == 4) & (d.draft_mode == "fixed")
        & (d.length_mode == "fixed100")].iloc[0]
c = fit_round_times(train)
pred = c["t_verify"] * row.n_verify_steps + c["t_draft"] * row.proposed_total
rate = train.sd_lat_med.sum() / train.output_length.sum()                       # naive baseline B0
print(f"training configurations: {len(train)}")
print(f"t_check = {1000*c['t_verify']:.1f} ms, t_draft = {1000*c['t_draft']:.1f} ms (calculated)")
print(f"predicted = {c['t_verify']:.4f} x {row.n_verify_steps:.0f} + {c['t_draft']:.4f} x {row.proposed_total:.0f} = {pred:.2f} s")
print(f"measured  = {row.sd_lat_med:.2f} s   error = {100*(pred-row.sd_lat_med)/row.sd_lat_med:+.1f}%")
print(f"B0 naive  = {rate*row.output_length:.2f} s   error = {100*(rate*row.output_length-row.sd_lat_med)/row.sd_lat_med:+.1f}%")
print(f"derived speedup = {row.std_time_s:.2f} / {pred:.2f} = {row.std_time_s/pred:.2f}  (measured {row.speedup:.2f})")
"""),
md("""
## Step 4 · All models on all test splits
`run_all` fits every model on the training part of every split and predicts the test part. Models: **M1** (main),
**M1i** (with intercept), **M1m** (per drafting mode), **MJ** (joint, draft swap only); baselines **B0**, **B0g**, **M2**, **B0x**.
Splits: held-out prompt · γ 2→4,8 · γ 2,4→8 · fixed→confidence · confidence→fixed · 100 tokens→natural · draft swap.
Run `show(pf.predict_split)` or `show(pf.draft_swap)` to read the code.
"""),
code("""
pred = pf.run_all(d)
display(pred.groupby("split").size().rename("test predictions").to_frame())
"""),
md("""
## Step 5 · Errors on the test configurations (quick view, point values)
MAPE = mean |predicted − measured| / measured (%). Bias < 0 means predicted too short. The noise floor is the median
run-to-run CV of the test configurations. The full table with 95% bootstrap CIs is written in Step 7 (`P2_errors.csv`).
"""),
code("""
quick = pf.error_table(pred, ci=False)
display(quick.pivot(index="split", columns="model", values="MAPE_pct").round(1)
        .reindex(columns=[m for m in pf.PER_PAIR_MODELS + pf.SWAP_MODELS]))
display(quick[["split", "model", "n_test", "MAE_s", "bias_s", "noise_cv_median_pct"]].round(2))
"""),
md("""
## Step 6 · Why some splits are harder: what each training set looks like
If rounds and proposed tokens are almost perfectly correlated in training (correlation near 1), the fit cannot separate
t_check from t_draft. That happens, for example, with γ = 2 only, where proposed tokens ≈ 2 × rounds.
"""),
code("""
diag = pf.split_diagnostics(d)
display(diag.round(3))
"""),
md("""
## Step 6b · Predicting SD time BEFORE running SD: analytical acceptance model (MA)
M1 reads rounds and proposed tokens from the run. MA predicts them from theory (Leviathan et al. 2023). The assumption
is that each draft token is accepted with the same probability α, independently of the others. Then one round produces
on average

$$k = \\frac{1-\\alpha^{\\gamma+1}}{1-\\alpha}\\ \\text{tokens},\\qquad \\text{rounds} = L/k,\\qquad \\text{proposed} = \\gamma\\cdot\\text{rounds}$$

and the time follows from the same regression times as M1. L is the output length of the **standard** run, which is known
without SD. MA covers fixed drafting only, because the theory assumes γ tokens in every round (true in 97.9% of rounds).

**How α is estimated (maximum likelihood).** A round that accepts *a* tokens and then rejects one counts *a* successes and 1 failure.
A round that accepts all it proposed counts only successes. Then α = successes / (successes + failures), with the last round
excluded because the length limit cuts it short. The next cell works this out for one real step log.
"""),
code("""
import json
ex = d[(d.pair == "INT8+FP16") & (d.prompt_id == "factual") & (d.gamma == 2) & (d.draft_mode == "fixed") & (d.length_mode == "fixed100")].iloc[0]
rounds = json.loads(ex.step_log)[:-1]
succ = sum(a for p, a in rounds); fail = sum(a < p for p, a in rounds)
print("first rounds [proposed, accepted]:", rounds[:8], "...")
print(f"successes = {succ}, failures = {fail}, alpha = {succ}/{succ + fail} = {succ/(succ+fail):.3f}  (pf.alpha_mle: {pf.alpha_mle([ex.step_log]):.3f})")
for g_ in (2, 4, 8):
    print(f"gamma {g_}: k = (1 - alpha^{g_+1}) / (1 - alpha) = {pf.tokens_per_round(succ/(succ+fail), g_):.2f} tokens per round")
"""),
code("""
# Tests S1 (alpha from gamma 2 of the same prompt -> gamma 4, 8) and S2 (alpha from the other 5 prompts) - point values
ma = pf.analytical_acceptance(d, pred[pred.split == "held_out_prompt"])
display(pf.error_table(ma, ci=False)[["split", "model", "n_test", "MAPE_pct", "MAE_s", "bias_s"]].round(2))
alpha_t, pos_t = pf.acceptance_diagnostics(d)
display(Markdown("Assumption check: acceptance probability by draft position (equal values = assumption holds)"))
display(pos_t.pivot(index="position", columns="gamma", values="p_accept").round(3))
"""),
md("""
## Step 7 · Write every table, figure and LaTeX table (same script as `make full_prediction`)
This runs `scripts/full_prediction.py` into the output folder, including the bootstrap CIs and the
break-even analysis (about 1.5 min). The results stored in the repository are not overwritten.
"""),
code("""
import subprocess
r = subprocess.run([sys.executable, str(ROOT / "scripts" / "full_prediction.py"), str(ROOT / "data" / "raw" / "full"),
                    str(ROOT / "results" / "pilot"), str(OUT)], capture_output=True, text=True)
print(r.stdout[-3000:]); print(r.stderr[-2000:])
assert r.returncode == 0, "script failed - see the message above"
print(sorted(p.name for p in OUT.iterdir()))
"""),
code("""
display(Markdown("**Figure 1 · Predicted vs measured SD time**")); display(Image(str(OUT / "F1_predicted_vs_measured.png"), width=900))
display(Markdown("**Figure 2 · Break-even: ρ vs ρ\\\\***")); display(Image(str(OUT / "F2_break_even.png"), width=900))
display(Markdown("**Figure 3 · Analytical acceptance model**")); display(Image(str(OUT / "F3_acceptance_model.png"), width=900))
be = pd.read_csv(OUT / "P5_break_even.csv")
display(be[be.gamma == "all"][["target_precision", "draft_precision", "t_check_ms", "t_draft_ms", "tokens_per_round",
                               "proposed_per_round", "rho", "rho_star", "measured_median_speedup"]].round(3))
"""),
md("""
## Step 8 · Compare with the stored results and save a ZIP file
Compares your MAPE values with the stored `results/full/prediction/P2_errors.csv`, then packs the output folder,
together with your package versions, into one ZIP file.
"""),
code("""
import zipfile
mine = pd.read_csv(OUT / "P2_errors.csv")
ref_file = ROOT / "results" / "full" / "prediction" / "P2_errors.csv"
if ref_file.exists():
    ref = pd.read_csv(ref_file)
    cmp_ = ref[["split", "model", "MAPE_pct"]].merge(mine[["split", "model", "MAPE_pct"]], on=["split", "model"], suffixes=("_stored", "_this_run"))
    cmp_["abs_diff"] = (cmp_.MAPE_pct_stored - cmp_.MAPE_pct_this_run).abs()
    print(f"Max |difference| in MAPE vs the stored results: {cmp_.abs_diff.max():.2e} percentage points")
    ENV["max_mape_diff_vs_stored"] = float(cmp_.abs_diff.max())
json.dump(ENV, open(OUT / "environment.json", "w", encoding="utf-8"), indent=1)
zip_path = OUT.with_suffix(".zip")
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.iterdir()):
        z.write(p, arcname=f"{OUT.name}/{p.name}")
zip_msg = f"### Results saved\\n`{zip_path}` ({zip_path.stat().st_size/1e6:.1f} MB)"
if not IN_COLAB:
    zip_msg += "\\n\\nIt is inside the repository folder, under `results/full/`."
display(Markdown(zip_msg))
print("Results saved as:", zip_path)
if IN_COLAB:
    if os.path.isdir("/content/drive/MyDrive"):                     # Option 1: keep a copy next to the repository ZIP
        import shutil; shutil.copy(zip_path, "/content/drive/MyDrive/"); print("Copy saved to My Drive:", zip_path.name)
    from google.colab import files
    files.download(str(zip_path))
"""),
]
nb = dict(cells=cells, metadata=dict(kernelspec=dict(display_name="Python 3", language="python", name="python3"),
                                     language_info=dict(name="python")), nbformat=4, nbformat_minor=5)
for i, c in enumerate(nb["cells"]):
    c["id"] = f"c{i:02d}"
out = ROOT / "notebooks" / "06_full_prediction_model.ipynb"
out.write_text(json.dumps(nb, indent=1))
print("wrote", out)

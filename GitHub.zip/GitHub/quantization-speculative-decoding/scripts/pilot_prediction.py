"""Prediction model fitted on the PILOT study (report Section 4.2). Usage: python scripts/pilot_prediction.py <pilot_out_dir> <out_dir>
Reads <pilot_out_dir>/sd_configs_full.csv (produced by pilot_analysis.py from the raw CSVs)."""
import sys, os, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from qsd.prediction import (load_sd_configs, run_all_splits, error_table, direction_table, break_even,
                             acceptance_transfer, fit_round_times, PAIRS)

S3, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
d = load_sd_configs(f"{S3}/sd_configs_full.csv")
pred = run_all_splits(d)
pred.to_csv(f"{OUT}/predictions_all_splits.csv", index=False)

err = error_table(pred); err.to_csv(f"{OUT}/T8_prediction_errors.csv", index=False)
errp = error_table(pred, by=("split", "target_precision", "draft_precision")); errp.to_csv(f"{OUT}/T8b_prediction_errors_by_pair.csv", index=False)
dirt = direction_table(pred, d); dirt.to_csv(f"{OUT}/T9_direction_agreement.csv", index=False)
be = break_even(d); be.to_csv(f"{OUT}/T10_break_even_ratio.csv", index=False)
at = acceptance_transfer(pred, d); at.to_csv(f"{OUT}/T8c_exploratory_acceptance_transfer.csv", index=False)
# held-out prompt restricted to the 90 WORKLOAD configurations (the 'quantization' fold is the whole CORE stage)
ew = error_table(pred[(pred.split == "leave_one_workload_out") & (pred.stage == "WORKLOAD")]); ew["split"] = "held_out_prompt_workload_only"
ew.to_csv(f"{OUT}/T8e_held_out_prompt_workload_only.csv", index=False)

# per-round times fitted on all 110 configurations (no intercept) - replaces nothing; Stage 3 T4e keeps its intercept fit
full = []
for tp, dp in PAIRS:
    g = d[(d.target_precision == tp) & (d.draft_precision == dp)]
    c = fit_round_times(g); y = g.sd_lat_med.to_numpy(); yh = c["t_verify"] * g.n_verify_steps + c["t_draft"] * g.proposed_total
    full.append(dict(target_precision=tp, draft_precision=dp, n=len(g), t_verify_ms=1000 * c["t_verify"], t_draft_ms=1000 * c["t_draft"],
                     ratio=c["t_draft"] / c["t_verify"], r2=1 - ((y - yh) ** 2).sum() / ((y - y.mean()) ** 2).sum()))
pd.DataFrame(full).to_csv(f"{OUT}/T8d_round_times_full_fit.csv", index=False)

# within-configuration noise floor (timed runs): median CV of the 10 runs, for context
cfg = pd.read_csv(f"{S3}/all_configs_summary.csv")
noise = float(cfg[cfg["mode"] == "SD"].cv.median())

def g_(s, m, col):
    return float(err[(err.split == s) & (err.model == m)][col].iloc[0])
facts = {s: {m: {k: round(g_(s, m, k), 4) for k in ["MAE_s", "MAE_s_lo", "MAE_s_hi", "RMSE_s", "RMSE_s_lo", "RMSE_s_hi", "MAPE_pct", "MAPE_pct_lo", "MAPE_pct_hi", "bias_s"]}
             | {"n_test": int(g_(s, m, "n_test"))} for m in ["B0", "M1", "M2", "M1i"]} for s in err.split.unique()}
facts["sd_run_median_cv"] = noise
facts["direction"] = dirt.to_dict("records")
facts["break_even"] = be.round(4).to_dict("records")
json.dump(facts, open(f"{OUT}/facts_4_2.json", "w"), indent=1, default=float)

# ------------------------------------------------------------------------------------------- figures (Stage 3 style)
INK, INK2, MUTED, GRID, BASE = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7"
PC = {"FP16": "#2a78d6", "INT8": "#eb6834", "INT4": "#1baf7a"}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.titlesize": 8.5, "axes.labelsize": 8,
                     "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7.5, "axes.edgecolor": BASE,
                     "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2, "text.color": INK,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID,
                     "grid.linewidth": 0.6, "axes.axisbelow": True, "savefig.dpi": 300, "figure.dpi": 150,
                     "axes.titleweight": "bold", "axes.titlelocation": "left"})
W2 = 7.16
PLAB = {("FP16", "FP16"): "FP16 target · FP16 draft", ("INT8", "INT8"): "INT8 target · INT8 draft (matched)",
        ("INT8", "FP16"): "INT8 target · FP16 draft", ("INT4", "INT4"): "INT4 target · INT4 draft (matched)",
        ("INT4", "FP16"): "INT4 target · FP16 draft"}
def mk(tp, dp):
    c = PC[tp]; matched = tp == dp
    return dict(color=c, marker="o" if matched else "s", markerfacecolor=c if matched else "white", markeredgecolor=c,
                linestyle="none", markersize=4.5, markeredgewidth=1.2)
def save(fig, name):
    fig.savefig(f"{OUT}/{name}.png", bbox_inches="tight", facecolor="white"); fig.savefig(f"{OUT}/{name}.pdf", bbox_inches="tight", facecolor="white"); plt.close(fig)

# Fig 8: predicted vs measured (leave-one-workload-out), M1 and M2, + MAPE across splits
lo = pred[pred.split == "leave_one_workload_out"]
fig, axs = plt.subplots(1, 3, figsize=(W2, 2.5), constrained_layout=True)
for ax, m, ttl in [(axs[0], "M1", "(a) Step counts known (M1)"), (axs[1], "M2", "(b) Step counts predicted (M2)")]:
    for tp, dp in PAIRS:
        g = lo[(lo.target_precision == tp) & (lo.draft_precision == dp)]
        ax.plot(g.sd_lat_med, g[f"pred_{m}"], **mk(tp, dp), alpha=0.9)
    lim = [1.5, 60]; ax.plot(lim, lim, color=INK2, linewidth=1)
    ax.fill_between(lim, [v * 0.9 for v in lim], [v * 1.1 for v in lim], color=GRID, alpha=0.6, linewidth=0)
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(lim); ax.set_ylim(lim)
    for a in (ax.xaxis, ax.yaxis):
        a.set_major_locator(matplotlib.ticker.FixedLocator([2, 5, 10, 20, 50])); a.set_major_formatter(matplotlib.ticker.FormatStrFormatter("%g"))
        a.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.set_xlabel("Measured SD time (s)"); ax.set_title(ttl)
    ax.text(0.04, 0.96, f"MAPE {g_('leave_one_workload_out', m, 'MAPE_pct'):.1f}%", transform=ax.transAxes, va="top", color=INK)
axs[0].set_ylabel("Predicted SD time (s)")
ax = axs[2]
SPL = [("leave_one_workload_out", "Held-out\nprompt"), ("gamma2_to_larger_gamma", "γ=2 →\nγ≥4"), ("core_to_workload", "CORE →\nWORKLOAD")]
MC = {"B0": MUTED, "M2": "#7a6fbf", "M1": INK}
for j, (m, lab) in enumerate([("B0", "B0 naive per-token"), ("M2", "M2 a priori"), ("M1", "M1 step counts known")]):
    x = np.arange(3) + (j - 1) * 0.24
    v = [g_(s, m, "MAPE_pct") for s, _ in SPL]; l = [g_(s, m, "MAPE_pct_lo") for s, _ in SPL]; h = [g_(s, m, "MAPE_pct_hi") for s, _ in SPL]
    ax.bar(x, v, width=0.22, color=MC[m], label=lab, edgecolor="white", linewidth=1)
    ax.errorbar(x, v, yerr=[np.subtract(v, l), np.subtract(h, v)], fmt="none", ecolor=INK2, elinewidth=0.9, capsize=2)
ax.set_xticks(np.arange(3), [s[1] for s in SPL]); ax.set_ylabel("Mean absolute % error"); ax.set_title("(c) Error by test split (95% CI)")
ax.grid(axis="x", visible=False); ax.set_ylim(0, 20); ax.legend(frameon=False, loc="upper left", fontsize=6.5, ncol=1, handlelength=1)
h = [Line2D([0], [0], **mk(*p)) for p in PAIRS]
fig.legend(h, [PLAB[p] for p in PAIRS], frameon=False, loc="lower center", ncol=3, bbox_to_anchor=(0.5, -0.17), fontsize=7)
save(fig, "Fig8_prediction")

# Fig 9: draft/check time ratio vs break-even ratio
fig, ax = plt.subplots(figsize=(W2 * 0.62, 2.3), constrained_layout=True)
yy = np.arange(len(be))[::-1]
for y, (_, r) in zip(yy, be.iterrows()):
    tp, dp = r.target_precision, r.draft_precision
    ax.plot([r.rho_star_lo, r.rho_star_hi], [y, y], color=GRID, linewidth=7, solid_capstyle="butt")
    ax.plot([r.rho_star] * 2, [y - 0.25, y + 0.25], color=INK2, linewidth=1.4)
    ax.errorbar(r.rho, y, xerr=[[r.rho - r.rho_lo], [r.rho_hi - r.rho]], fmt="none", ecolor=PC[tp], elinewidth=1.2, capsize=2)
    ax.plot(r.rho, y, **(mk(tp, dp) | dict(markersize=6)))
ax.set_yticks(yy, [PLAB[(r.target_precision, r.draft_precision)] for _, r in be.iterrows()])
ax.set_xlabel("Draft time / check time per round"); ax.set_xlim(0, 1.2); ax.grid(axis="y", visible=False)
ax.set_title("Draft/check time ratio vs break-even ratio")
ax.legend([Line2D([0], [0], color=MUTED, marker="o", linestyle="none"), Line2D([0], [0], color=GRID, linewidth=7)],
          ["Calculated ratio (95% CI); SD faster when left of band", "Break-even ratio (95% CI)"], frameon=False, loc="upper center", bbox_to_anchor=(0.35, -0.22), ncol=2, fontsize=6.8)
save(fig, "Fig9_break_even")
print(json.dumps({s: {m: round(facts[s][m]["MAPE_pct"], 2) for m in ["B0", "M1", "M2", "M1i"]} for s in err.split.unique()}, indent=1))

# ------------------------------------------------------------------------------------------- LaTeX tables (booktabs) for Overleaf
SPLAB = {"leave_one_workload_out": "Held-out prompt", "gamma2_to_larger_gamma": r"$\gamma=2 \rightarrow \gamma\geq4$",
         "core_to_workload": r"CORE $\rightarrow$ WORKLOAD"}
MLAB = {"B0": "B0 naive per-token rate", "M2": "M2 a priori (step counts predicted)", "M1": "M1 step counts known",
        "M1i": "M1 with intercept (sensitivity)"}
L = [r"\begin{table}[t]", r"\centering", r"\caption{Out-of-sample error of the predicted SD time (configuration medians). 95\% bootstrap CIs in brackets.}",
     r"\label{tab:prediction_error}", r"\small", r"\begin{tabular}{llrrr}", r"\toprule",
     r"Test split & Model & $n$ & MAE (s) & MAPE (\%) \\", r"\midrule"]
for s in ["leave_one_workload_out", "gamma2_to_larger_gamma", "core_to_workload"]:
    for j, m in enumerate(["B0", "M2", "M1", "M1i"]):
        row = err[(err.split == s) & (err.model == m)].iloc[0]
        L.append(f"{SPLAB[s] if j == 0 else ''} & {MLAB[m]} & {int(row.n_test)} & {row.MAE_s:.2f} [{row.MAE_s_lo:.2f}, {row.MAE_s_hi:.2f}] & "
                 f"{row.MAPE_pct:.1f} [{row.MAPE_pct_lo:.1f}, {row.MAPE_pct_hi:.1f}] \\\\")
    L.append(r"\midrule" if s != "core_to_workload" else r"\bottomrule")
L += [r"\end{tabular}", r"\end{table}", ""]
TP = {("FP16", "FP16"): "FP16 / FP16", ("INT8", "INT8"): "INT8 / INT8", ("INT8", "FP16"): "INT8 / FP16", ("INT4", "INT4"): "INT4 / INT4", ("INT4", "FP16"): "INT4 / FP16"}
L += [r"\begin{table}[t]", r"\centering",
      r"\caption{Calculated draft/check time ratio $\rho$ and break-even ratio $\rho^{*}$ (all 110 SD configurations). SD is faster when $\rho<\rho^{*}$.}",
      r"\label{tab:break_even}", r"\small", r"\begin{tabular}{lrrrrrr}", r"\toprule",
      r"Target / draft & $t_{\mathrm{check}}$ (ms) & $t_{\mathrm{draft}}$ (ms) & $k$ & $\rho$ [95\% CI] & $\rho^{*}$ [95\% CI] & Faster \\", r"\midrule"]
for _, r in be.iterrows():
    L.append(f"{TP[(r.target_precision, r.draft_precision)]} & {r.t_verify_ms:.1f} & {r.t_draft_ms:.1f} & {r.tokens_per_round:.2f} & "
             f"{r.rho:.2f} [{r.rho_lo:.2f}, {r.rho_hi:.2f}] & {r.rho_star:.2f} [{r.rho_star_lo:.2f}, {r.rho_star_hi:.2f}] & {int(r.configs_faster)}/{int(r.n)} \\\\")
L += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
open(f"{OUT}/tables_4_2.tex", "w").write("\n".join(L))
